Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports ActualMap
Imports ActualMap.Windows

Namespace SampleApps
	Partial Public Class StreetMap
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub

		Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
			AddMapLayers()

			legend1.Populate(map1)
		End Sub

		Private Sub AddMapLayers()
			Dim layer As Layer
			Dim feature As Feature
			Dim renderer As FeatureRenderer

			Dim LayerFolder As String = Application.StartupPath & "\..\..\MAPS\STREETS\"
			Dim SymbolFolder As String = Application.StartupPath & "\..\..\SYMBOLS\"

			'- COUNTY -------------------------------------------
			layer = map1.AddLayer(LayerFolder & "County.shp")

			layer.LabelField = "NAME"
			layer.Symbol.Size = 2
			layer.Symbol.LineColor = Color.FromArgb(199, 172, 116)
			layer.Symbol.FillColor = Color.FromArgb(242, 236, 223)

			'- PARKS --------------------------------------------
			layer = map1.AddLayer(LayerFolder & "Park.shp")

			layer.LabelField = "NAME"
			layer.ShowLabels = True
			layer.LabelFont.Outline = True
			layer.LabelFont.Size = 11
			layer.LabelFont.Bold = True
			layer.Symbol.FillColor = Color.FromArgb(143, 175, 47)
			layer.Symbol.LineColor = layer.Symbol.FillColor

			'- WATER AREAS --------------------------------------
			layer = map1.AddLayer(LayerFolder & "WaterArea.shp")
			layer.MaxScale = 300000

			layer.LabelField = "NAME"
			layer.ShowLabels = True
			layer.LabelFont.Outline = True
			layer.LabelFont.Size = 12
			layer.Symbol.FillColor = Color.FromArgb(159, 159, 223)
			layer.Symbol.LineColor = layer.Symbol.FillColor

			'- RIVERS -------------------------------------------
			layer = map1.AddLayer(LayerFolder & "Water.shp")
			layer.MaxScale = 300000

			layer.LabelField = "NAME"
			layer.ShowLabels = True
			layer.LabelFont.Size = 9
			layer.Symbol.FillColor = Color.FromArgb(159, 159, 223)
			layer.Symbol.LineColor = layer.Symbol.FillColor
			layer.LabelFont.Color = Color.FromArgb(0, 0, 128)

			'- AIRPORTS -----------------------------------------
			layer = map1.AddLayer(LayerFolder & "Airport.shp")

			layer.LabelField = "NAME"
			layer.ShowLabels = True
			layer.LabelFont.Outline = True
			layer.LabelFont.Size = 11
			layer.Symbol.FillColor = Color.FromArgb(43, 147, 43)

			'- STREETS ------------------------------------------
			layer = map1.AddLayer(LayerFolder & "Street.shp")
			layer.MaxScale = 150000

			layer.LabelField = "NAME"
			layer.LabelFont.Size = 10
			layer.ShowLabels = True
            layer.Symbol.LineStyle = ActualMap.LineStyle.Road
			layer.Symbol.LineColor = Color.FromArgb(171, 158, 137)
			layer.Symbol.InnerColor = Color.White

			' set different line width of the streets for different scales
			feature = New ActualMap.Feature()
			feature.MaxScale = 75000
			feature.MinScale = 37000
            feature.Symbol.LineStyle = ActualMap.LineStyle.Road
			feature.Symbol.LineColor = Color.FromArgb(171, 158, 137)
			feature.Symbol.InnerColor = Color.White
			feature.Symbol.Size = 3
			layer.Renderer.Add(feature)

			feature = feature.Clone()
			feature.MaxScale = 37000
			feature.MinScale = 16000
			feature.Symbol.Size = 4
			feature.LabelFont.Outline = True
			layer.Renderer.Add(feature)

			feature = feature.Clone()
			feature.MaxScale = 16000
			feature.MinScale = -1 ' no minimum scale
			feature.Symbol.Size = 6
			layer.Renderer.Add(feature)

			'- RAILROADS ----------------------------------------
			layer = map1.AddLayer(LayerFolder & "Railroad.shp")
			layer.MaxScale = 200000

			layer.LabelField = "NAME"
			layer.ShowLabels = True
			layer.LabelFont.Outline = True
			layer.LabelFont.Size = 10
            layer.Symbol.LineStyle = ActualMap.LineStyle.Railroad

			'- INSTITUTIONS -------------------------------------
			layer = map1.AddLayer(LayerFolder & "Institution.shp")

			layer.LabelField = "NAME"
			layer.ShowLabels = True
			layer.LabelFont.Name = "Times New Roman"
			layer.LabelFont.Outline = True
			layer.LabelFont.Size = 12
			layer.UseDefaultSymbol = False

			renderer = layer.Renderer
			renderer.Field = "FCC"

			' cemetery symbol
			feature = renderer.Add()
			feature.Value = "D82"
            feature.Symbol.PointStyle = ActualMap.PointStyle.Bitmap
			feature.Symbol.Bitmap = SymbolFolder & "cemetery.bmp"
			feature.Symbol.Size = 16
			feature.Symbol.TransparentColor = Color.White
			feature.Description = "Cemetery"

			' school symbol
			feature = renderer.Add()
			feature.Value = "D43"
            feature.Symbol.PointStyle = ActualMap.PointStyle.Bitmap
			feature.Symbol.Bitmap = SymbolFolder & "school.bmp"
			feature.Symbol.Size = 16
			feature.Symbol.TransparentColor = Color.White
			feature.Description = "School"

			' church symbol
			feature = renderer.Add()
			feature.Value = "D44"
            feature.Symbol.PointStyle = ActualMap.PointStyle.Bitmap
			feature.Symbol.Bitmap = SymbolFolder & "church.bmp"
			feature.Symbol.Size = 16
			feature.Symbol.TransparentColor = Color.White
			feature.Description = "Church"

			' hospital symbol
			feature = renderer.Add()
			feature.Value = "D31"
            feature.Symbol.PointStyle = ActualMap.PointStyle.Bitmap
			feature.Symbol.Bitmap = SymbolFolder & "hospital.bmp"
			feature.Symbol.Size = 16
			feature.Symbol.TransparentColor = Color.White
			feature.Description = "Hospital"
		End Sub

		Private Sub map1_MapScaleChanged(ByVal sender As Object, ByVal e As MapScaleChangedEventArgs) Handles map1.MapScaleChanged
			legend1.Populate(map1)
		End Sub

		Private Sub toolBar_ButtonClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles toolBar.ButtonClick
			If e.Button.Style = ToolBarButtonStyle.ToggleButton Then
				For Each b As ToolBarButton In toolBar.Buttons
				b.Pushed = False
				Next b
				e.Button.Pushed = True
			End If

			map1.Cursor = Cursors.Default

			If e.Button Is zoomFull Then
				map1.ZoomFull()
				map1.Refresh()
			End If
			If e.Button Is clearShapes Then
				map1.MapShapes.Clear()
				map1.Callouts.Clear()
				dataGrid.DataSource = Nothing
				dataGrid.CaptionText = String.Empty
				map1.Refresh()
			ElseIf e.Button Is zoomInTool Then
			map1.MapTool = MapTool.ZoomIn
			ElseIf e.Button Is zoomOutTool Then
			map1.MapTool = MapTool.ZoomOut
			ElseIf e.Button Is panTool Then
				map1.MapTool = MapTool.Pan
				map1.Cursor = Cursors.SizeAll
			ElseIf e.Button Is centerTool Then
			map1.MapTool = MapTool.Center
			ElseIf e.Button Is distanceTool Then
			map1.MapTool = MapTool.Distance
			ElseIf e.Button Is infoTool Then
			map1.MapTool = MapTool.Info
			End If

		End Sub

		Private Sub map1_InfoTool(ByVal sender As Object, ByVal e As ActualMap.Windows.InfoToolEventArgs) Handles map1.InfoTool
			map1.Callouts.Clear()

			Dim records As ActualMap.Recordset = map1.Identify(e.InfoPoint, 5)

			If (Not records.EOF) Then
				dataGrid.DataSource = records
				dataGrid.CaptionText = records.Layer.Name

				Dim callout As Callout = map1.Callouts.Add()
				callout.X = e.InfoPoint.X
				callout.Y = e.InfoPoint.Y
				callout.Text = GetCalloutText(records)
				callout.Font.Size = 16

				map1.Refresh()
			End If
		End Sub

		Private Sub menuItem2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles menuItem2.Click
			printPreview.ShowDialog()
		End Sub

		Private Sub printDocument_PrintPage(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles printDocument.PrintPage
			Dim mapImage As Bitmap = map1.GetBitmap(700, 600)
			e.Graphics.DrawImageUnscaled(mapImage, 50, 50)
		End Sub

		Private Function GetCalloutText(ByVal rs As ActualMap.Recordset) As String
			Dim index As Integer = rs.Fields.GetFieldIndex("NAME")
			If index < 0 Then
			index = rs.Fields.GetFieldIndex(rs.Layer.LabelField)
			End If
			If index < 0 Then
			index = 0
			End If
			Return rs(index).ToString()
		End Function

		Private Sub map1_DistanceToolMove(ByVal sender As Object, ByVal e As DistanceToolEventArgs) Handles map1.DistanceToolMove
			Dim distanceInMapUnits As Double = e.Distance
            Dim distanceInMiles As Double = Math.Round(map1.ConvertDistance(distanceInMapUnits, map1.MapUnit, ActualMap.MeasureUnit.Mile), 3)
            Dim distanceInKilometers As Double = Math.Round(map1.ConvertDistance(distanceInMapUnits, map1.MapUnit, ActualMap.MeasureUnit.Kilometer), 3)

			statusBar1.Text = distanceInMiles.ToString() & " mi  |  " & distanceInKilometers.ToString() & " km"
		End Sub

		Private Sub map1_DistanceToolFinished(ByVal sender As Object, ByVal e As DistanceToolEventArgs) Handles map1.DistanceToolFinished
			statusBar1.Text = String.Empty
		End Sub
	End Class
End Namespace