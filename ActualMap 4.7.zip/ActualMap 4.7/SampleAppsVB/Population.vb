Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports ActualMap
Imports ActualMap.Windows

Namespace SampleApps
	Partial Public Class Population
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub

		Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
			AddMapLayers()

			DoThematicMapping()

			' fill the states combobox
			Dim layer As Layer = map1.FindLayer("states")
			If layer IsNot Nothing Then
				Dim records As Recordset = layer.Recordset
				Do While Not records.EOF
					statesList.Items.Add(records("STATE_NAME"))
					records.MoveNext()
				Loop
			End If
		End Sub

		Private Sub DoThematicMapping()
			legend1.IconWidth = 30
			legend1.IconHeight = 28

			Dim feature As ActualMap.Feature
			Dim layer As ActualMap.Layer = map1("cities")
			Dim renderer As ActualMap.FeatureRenderer = layer.Renderer

			'*******************************
			feature = renderer.Add()
			feature.Expression = "POP <= 5000"
			feature.Symbol.FillColor = Color.White
			feature.Symbol.Size = 4

			legend1.Add("0 - 5000", layer.LayerType, feature.Symbol)

			'*******************************
			feature = renderer.Add()
			feature.Expression = "POP <= 50000"
			feature.Symbol.FillColor = Color.FromArgb(255, 255, 0)
			feature.Symbol.Size = 8

			legend1.Add("5000 - 50000", layer.LayerType, feature.Symbol)

			'*******************************
			feature = renderer.Add()
			feature.Expression = "POP <= 250000"
			feature.Symbol.FillColor = Color.FromArgb(255, 0, 255)
			feature.Symbol.Size = 12

			legend1.Add("50000 - 250000", layer.LayerType, feature.Symbol)

			'*******************************
			feature = renderer.Add()
			feature.Expression = "POP <= 500000"
			feature.Symbol.FillColor = Color.Blue
			feature.Symbol.Size = 16

			legend1.Add("250000 - 500000", layer.LayerType, feature.Symbol)

			'*******************************
			feature = renderer.Add()
			feature.Expression = "POP <= 1000000"
			feature.Symbol.FillColor = Color.FromArgb(0, 255, 255)
			feature.Symbol.Size = 20

			legend1.Add("500000 - 1000000", layer.LayerType, feature.Symbol)

			'*******************************
			feature = renderer.Add()
			feature.Expression = "POP <= 5000000"
			feature.Symbol.FillColor = Color.Green
			feature.Symbol.Size = 24

			legend1.Add("1000000 - 5000000", layer.LayerType, feature.Symbol)

			'*******************************
			feature = renderer.Add()
			feature.Expression = "POP > 5000000"
			feature.Symbol.FillColor = Color.Red
			feature.Symbol.Size = 28

			legend1.Add("5000000 +", layer.LayerType, feature.Symbol)
		End Sub

		Private Sub AddMapLayers()
			Dim layer As Layer

			Dim LayerFolder As String = Application.StartupPath & "\..\..\MAPS\USA\"

			'- STATES -------------------------------------------
			layer = map1.AddLayer(LayerFolder & "states.shp")

			layer.LabelField = "STATE_ABBR"
			layer.ShowLabels = True
			layer.LabelFont.Name = "Verdana"
			layer.LabelFont.Size = 12
			layer.LabelFont.Bold = True
            layer.LabelStyle = ActualMap.LabelStyle.PolygonCenter

			'- CITIES --------------------------------------------
			layer = map1.AddLayer(LayerFolder & "cities.shp")

			layer.LabelField = "CITY_NAME"
			layer.ShowLabels = True
			layer.UseDefaultSymbol = False
		End Sub

		Private Sub map1_MapScaleChanged(ByVal sender As Object, ByVal e As MapScaleChangedEventArgs) Handles map1.MapScaleChanged
			Dim layer As ActualMap.Layer = map1("cities")
            layer.ShowLabels = map1.ConvertDistance(map1.Extent.Width, map1.MapUnit, ActualMap.MeasureUnit.Mile) <= 500
		End Sub

		Private Sub toolBar_ButtonClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles toolBar.ButtonClick
			If e.Button.Style = ToolBarButtonStyle.ToggleButton Then
				For Each b As ToolBarButton In toolBar.Buttons
				b.Pushed = False
				Next b
				e.Button.Pushed = True
			End If

			If e.Button Is zoomFull Then
				map1.ZoomFull()
				map1.Refresh()
			ElseIf e.Button Is zoomInTool Then
			map1.MapTool = MapTool.ZoomIn
			ElseIf e.Button Is zoomOutTool Then
			map1.MapTool = MapTool.ZoomOut
			ElseIf e.Button Is panTool Then
			map1.MapTool = MapTool.Pan
			ElseIf e.Button Is infoTool Then
			map1.MapTool = MapTool.Info
			End If
		End Sub

		Private Sub map1_InfoTool(ByVal sender As Object, ByVal e As ActualMap.Windows.InfoToolEventArgs) Handles map1.InfoTool
			map1.Callouts.Clear()

			Dim records As ActualMap.Recordset = map1.Identify(e.InfoPoint, 5)

			If (Not records.EOF) Then
				dataGrid.DataSource = records
				dataGrid.CaptionText = records.Layer.Name

				Dim callout As Callout = map1.Callouts.Add()
				callout.X = e.InfoPoint.X
				callout.Y = e.InfoPoint.Y
				callout.Text = GetCalloutText(records)
				callout.Font.Size = 16

				map1.Refresh()
			End If
		End Sub

		Private Function GetCalloutText(ByVal rs As ActualMap.Recordset) As String
			Dim index As Integer = rs.Fields.GetFieldIndex("NAME")
			If index < 0 Then
			index = rs.Fields.GetFieldIndex(rs.Layer.LabelField)
			End If
			If index < 0 Then
			index = 0
			End If
			Return rs(index).ToString()
		End Function

		Private Sub statesList_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles statesList.SelectedIndexChanged
			Dim state As Recordset
			state = map1("states").SearchExpression("STATE_NAME = """ & statesList.SelectedItem & """")
			If (Not state.EOF) Then
				map1.Extent = state.RecordExtent

				' select the state shape with a red outline
				map1.MapShapes.Clear()
				Dim shape As MapShape = map1.MapShapes.Add(state.Shape)
				Dim s As Symbol = New Symbol()
                s.FillStyle = ActualMap.FillStyle.Invisible
				s.LineColor = Color.Red
				s.Size = 3
				shape.Symbol = s

				map1.Refresh()
			End If
		End Sub
	End Class
End Namespace