Imports Microsoft.VisualBasic
Imports System
Namespace SampleApps
	Partial Public Class MainForm
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(ByVal disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.groupBox1 = New System.Windows.Forms.GroupBox()
			Me.linkLabel4 = New System.Windows.Forms.LinkLabel()
			Me.linkLabel3 = New System.Windows.Forms.LinkLabel()
			Me.linkLabel2 = New System.Windows.Forms.LinkLabel()
			Me.linkLabel1 = New System.Windows.Forms.LinkLabel()
			Me.groupBox2 = New System.Windows.Forms.GroupBox()
			Me.linkLabel16 = New System.Windows.Forms.LinkLabel()
			Me.linkLabel15 = New System.Windows.Forms.LinkLabel()
			Me.linkLabel7 = New System.Windows.Forms.LinkLabel()
			Me.linkLabel8 = New System.Windows.Forms.LinkLabel()
			Me.groupBox3 = New System.Windows.Forms.GroupBox()
			Me.linkLabel5 = New System.Windows.Forms.LinkLabel()
			Me.linkLabel6 = New System.Windows.Forms.LinkLabel()
			Me.groupBox4 = New System.Windows.Forms.GroupBox()
			Me.linkLabel17 = New System.Windows.Forms.LinkLabel()
			Me.linkLabel9 = New System.Windows.Forms.LinkLabel()
			Me.linkLabel10 = New System.Windows.Forms.LinkLabel()
			Me.groupBox5 = New System.Windows.Forms.GroupBox()
			Me.linkLabel11 = New System.Windows.Forms.LinkLabel()
			Me.linkLabel12 = New System.Windows.Forms.LinkLabel()
			Me.linkLabel13 = New System.Windows.Forms.LinkLabel()
			Me.linkLabel14 = New System.Windows.Forms.LinkLabel()
			Me.groupBox6 = New System.Windows.Forms.GroupBox()
			Me.linkLabel18 = New System.Windows.Forms.LinkLabel()
			Me.linkLabel19 = New System.Windows.Forms.LinkLabel()
			Me.groupBox7 = New System.Windows.Forms.GroupBox()
			Me.linkLabel20 = New System.Windows.Forms.LinkLabel()
			Me.linkLabel21 = New System.Windows.Forms.LinkLabel()
			Me.groupBox1.SuspendLayout()
			Me.groupBox2.SuspendLayout()
			Me.groupBox3.SuspendLayout()
			Me.groupBox4.SuspendLayout()
			Me.groupBox5.SuspendLayout()
			Me.groupBox6.SuspendLayout()
			Me.groupBox7.SuspendLayout()
			Me.SuspendLayout()
			' 
			' groupBox1
			' 
			Me.groupBox1.BackColor = System.Drawing.SystemColors.Menu
			Me.groupBox1.Controls.Add(Me.linkLabel4)
			Me.groupBox1.Controls.Add(Me.linkLabel3)
			Me.groupBox1.Controls.Add(Me.linkLabel2)
			Me.groupBox1.Controls.Add(Me.linkLabel1)
			Me.groupBox1.Location = New System.Drawing.Point(11, 15)
			Me.groupBox1.Margin = New System.Windows.Forms.Padding(4)
			Me.groupBox1.Name = "groupBox1"
			Me.groupBox1.Padding = New System.Windows.Forms.Padding(4)
			Me.groupBox1.Size = New System.Drawing.Size(161, 176)
			Me.groupBox1.TabIndex = 0
			Me.groupBox1.TabStop = False
			Me.groupBox1.Text = "Mapping"
			' 
			' linkLabel4
			' 
			Me.linkLabel4.AutoSize = True
			Me.linkLabel4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.linkLabel4.Location = New System.Drawing.Point(8, 143)
			Me.linkLabel4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
			Me.linkLabel4.Name = "linkLabel4"
			Me.linkLabel4.Size = New System.Drawing.Size(96, 22)
			Me.linkLabel4.TabIndex = 3
			Me.linkLabel4.TabStop = True
			Me.linkLabel4.Text = "World Map"
'			Me.linkLabel4.LinkClicked += New System.Windows.Forms.LinkLabelLinkClickedEventHandler(Me.linkLabel4_LinkClicked);
			' 
			' linkLabel3
			' 
			Me.linkLabel3.AutoSize = True
			Me.linkLabel3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.linkLabel3.Location = New System.Drawing.Point(8, 106)
			Me.linkLabel3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
			Me.linkLabel3.Name = "linkLabel3"
			Me.linkLabel3.Size = New System.Drawing.Size(86, 22)
			Me.linkLabel3.TabIndex = 2
			Me.linkLabel3.TabStop = True
			Me.linkLabel3.Text = "USA Map"
'			Me.linkLabel3.LinkClicked += New System.Windows.Forms.LinkLabelLinkClickedEventHandler(Me.linkLabel3_LinkClicked);
			' 
			' linkLabel2
			' 
			Me.linkLabel2.AutoSize = True
			Me.linkLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.linkLabel2.Location = New System.Drawing.Point(8, 68)
			Me.linkLabel2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
			Me.linkLabel2.Name = "linkLabel2"
			Me.linkLabel2.Size = New System.Drawing.Size(94, 22)
			Me.linkLabel2.TabIndex = 1
			Me.linkLabel2.TabStop = True
			Me.linkLabel2.Text = "Map Tools"
'			Me.linkLabel2.LinkClicked += New System.Windows.Forms.LinkLabelLinkClickedEventHandler(Me.linkLabel2_LinkClicked);
			' 
			' linkLabel1
			' 
			Me.linkLabel1.AutoSize = True
			Me.linkLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.linkLabel1.Location = New System.Drawing.Point(8, 32)
			Me.linkLabel1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
			Me.linkLabel1.Name = "linkLabel1"
			Me.linkLabel1.Size = New System.Drawing.Size(97, 22)
			Me.linkLabel1.TabIndex = 0
			Me.linkLabel1.TabStop = True
			Me.linkLabel1.Text = "Street Map"
'			Me.linkLabel1.LinkClicked += New System.Windows.Forms.LinkLabelLinkClickedEventHandler(Me.linkLabel1_LinkClicked);
			' 
			' groupBox2
			' 
			Me.groupBox2.BackColor = System.Drawing.SystemColors.Menu
			Me.groupBox2.Controls.Add(Me.linkLabel16)
			Me.groupBox2.Controls.Add(Me.linkLabel15)
			Me.groupBox2.Controls.Add(Me.linkLabel7)
			Me.groupBox2.Controls.Add(Me.linkLabel8)
			Me.groupBox2.Location = New System.Drawing.Point(184, 15)
			Me.groupBox2.Margin = New System.Windows.Forms.Padding(4)
			Me.groupBox2.Name = "groupBox2"
			Me.groupBox2.Padding = New System.Windows.Forms.Padding(4)
			Me.groupBox2.Size = New System.Drawing.Size(168, 176)
			Me.groupBox2.TabIndex = 1
			Me.groupBox2.TabStop = False
			Me.groupBox2.Text = "Databases"
			' 
			' linkLabel16
			' 
			Me.linkLabel16.AutoSize = True
			Me.linkLabel16.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.linkLabel16.Location = New System.Drawing.Point(11, 143)
			Me.linkLabel16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
			Me.linkLabel16.Name = "linkLabel16"
			Me.linkLabel16.Size = New System.Drawing.Size(114, 22)
			Me.linkLabel16.TabIndex = 3
			Me.linkLabel16.TabStop = True
			Me.linkLabel16.Text = "Shape Editor"
'			Me.linkLabel16.LinkClicked += New System.Windows.Forms.LinkLabelLinkClickedEventHandler(Me.linkLabel16_LinkClicked_1);
			' 
			' linkLabel15
			' 
			Me.linkLabel15.AutoSize = True
			Me.linkLabel15.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.linkLabel15.Location = New System.Drawing.Point(11, 106)
			Me.linkLabel15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
			Me.linkLabel15.Name = "linkLabel15"
			Me.linkLabel15.Size = New System.Drawing.Size(130, 22)
			Me.linkLabel15.TabIndex = 2
			Me.linkLabel15.TabStop = True
			Me.linkLabel15.Text = "Location Editor"
'			Me.linkLabel15.LinkClicked += New System.Windows.Forms.LinkLabelLinkClickedEventHandler(Me.linkLabel15_LinkClicked_1);
			' 
			' linkLabel7
			' 
			Me.linkLabel7.AutoSize = True
			Me.linkLabel7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.linkLabel7.Location = New System.Drawing.Point(11, 68)
			Me.linkLabel7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
			Me.linkLabel7.Name = "linkLabel7"
			Me.linkLabel7.Size = New System.Drawing.Size(100, 22)
			Me.linkLabel7.TabIndex = 1
			Me.linkLabel7.TabStop = True
			Me.linkLabel7.Text = "Parcel Map"
'			Me.linkLabel7.LinkClicked += New System.Windows.Forms.LinkLabelLinkClickedEventHandler(Me.linkLabel7_LinkClicked);
			' 
			' linkLabel8
			' 
			Me.linkLabel8.AutoSize = True
			Me.linkLabel8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.linkLabel8.Location = New System.Drawing.Point(11, 32)
			Me.linkLabel8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
			Me.linkLabel8.Name = "linkLabel8"
			Me.linkLabel8.Size = New System.Drawing.Size(72, 22)
			Me.linkLabel8.TabIndex = 0
			Me.linkLabel8.TabStop = True
			Me.linkLabel8.Text = "Airports"
'			Me.linkLabel8.LinkClicked += New System.Windows.Forms.LinkLabelLinkClickedEventHandler(Me.linkLabel8_LinkClicked);
			' 
			' groupBox3
			' 
			Me.groupBox3.BackColor = System.Drawing.SystemColors.Menu
			Me.groupBox3.Controls.Add(Me.linkLabel5)
			Me.groupBox3.Controls.Add(Me.linkLabel6)
			Me.groupBox3.Location = New System.Drawing.Point(11, 209)
			Me.groupBox3.Margin = New System.Windows.Forms.Padding(4)
			Me.groupBox3.Name = "groupBox3"
			Me.groupBox3.Padding = New System.Windows.Forms.Padding(4)
			Me.groupBox3.Size = New System.Drawing.Size(161, 176)
			Me.groupBox3.TabIndex = 2
			Me.groupBox3.TabStop = False
			Me.groupBox3.Text = "Tracking/Routing"
			' 
			' linkLabel5
			' 
			Me.linkLabel5.AutoSize = True
			Me.linkLabel5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.linkLabel5.Location = New System.Drawing.Point(8, 68)
			Me.linkLabel5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
			Me.linkLabel5.Name = "linkLabel5"
			Me.linkLabel5.Size = New System.Drawing.Size(58, 22)
			Me.linkLabel5.TabIndex = 1
			Me.linkLabel5.TabStop = True
			Me.linkLabel5.Text = "Route"
'			Me.linkLabel5.LinkClicked += New System.Windows.Forms.LinkLabelLinkClickedEventHandler(Me.linkLabel5_LinkClicked);
			' 
			' linkLabel6
			' 
			Me.linkLabel6.AutoSize = True
			Me.linkLabel6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.linkLabel6.Location = New System.Drawing.Point(8, 32)
			Me.linkLabel6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
			Me.linkLabel6.Name = "linkLabel6"
			Me.linkLabel6.Size = New System.Drawing.Size(144, 22)
			Me.linkLabel6.TabIndex = 0
			Me.linkLabel6.TabStop = True
			Me.linkLabel6.Text = "Vehicle Tracking"
'			Me.linkLabel6.LinkClicked += New System.Windows.Forms.LinkLabelLinkClickedEventHandler(Me.linkLabel6_LinkClicked);
			' 
			' groupBox4
			' 
			Me.groupBox4.BackColor = System.Drawing.SystemColors.Menu
			Me.groupBox4.Controls.Add(Me.linkLabel17)
			Me.groupBox4.Controls.Add(Me.linkLabel9)
			Me.groupBox4.Controls.Add(Me.linkLabel10)
			Me.groupBox4.Location = New System.Drawing.Point(184, 209)
			Me.groupBox4.Margin = New System.Windows.Forms.Padding(4)
			Me.groupBox4.Name = "groupBox4"
			Me.groupBox4.Padding = New System.Windows.Forms.Padding(4)
			Me.groupBox4.Size = New System.Drawing.Size(168, 176)
			Me.groupBox4.TabIndex = 3
			Me.groupBox4.TabStop = False
			Me.groupBox4.Text = "Thematic Mapping"
			' 
			' linkLabel17
			' 
			Me.linkLabel17.AutoSize = True
			Me.linkLabel17.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.linkLabel17.Location = New System.Drawing.Point(8, 106)
			Me.linkLabel17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
			Me.linkLabel17.Name = "linkLabel17"
			Me.linkLabel17.Size = New System.Drawing.Size(63, 22)
			Me.linkLabel17.TabIndex = 2
			Me.linkLabel17.TabStop = True
			Me.linkLabel17.Text = "Charts"
'			Me.linkLabel17.LinkClicked += New System.Windows.Forms.LinkLabelLinkClickedEventHandler(Me.linkLabel17_LinkClicked);
			' 
			' linkLabel9
			' 
			Me.linkLabel9.AutoSize = True
			Me.linkLabel9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.linkLabel9.Location = New System.Drawing.Point(8, 68)
			Me.linkLabel9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
			Me.linkLabel9.Name = "linkLabel9"
			Me.linkLabel9.Size = New System.Drawing.Size(95, 22)
			Me.linkLabel9.TabIndex = 1
			Me.linkLabel9.TabStop = True
			Me.linkLabel9.Text = "Population"
'			Me.linkLabel9.LinkClicked += New System.Windows.Forms.LinkLabelLinkClickedEventHandler(Me.linkLabel9_LinkClicked);
			' 
			' linkLabel10
			' 
			Me.linkLabel10.AutoSize = True
			Me.linkLabel10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.linkLabel10.Location = New System.Drawing.Point(8, 32)
			Me.linkLabel10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
			Me.linkLabel10.Name = "linkLabel10"
			Me.linkLabel10.Size = New System.Drawing.Size(155, 22)
			Me.linkLabel10.TabIndex = 0
			Me.linkLabel10.TabStop = True
			Me.linkLabel10.Text = "Demographic Map"
'			Me.linkLabel10.LinkClicked += New System.Windows.Forms.LinkLabelLinkClickedEventHandler(Me.linkLabel10_LinkClicked);
			' 
			' groupBox5
			' 
			Me.groupBox5.BackColor = System.Drawing.SystemColors.Menu
			Me.groupBox5.Controls.Add(Me.linkLabel11)
			Me.groupBox5.Controls.Add(Me.linkLabel12)
			Me.groupBox5.Location = New System.Drawing.Point(364, 15)
			Me.groupBox5.Margin = New System.Windows.Forms.Padding(4)
			Me.groupBox5.Name = "groupBox5"
			Me.groupBox5.Padding = New System.Windows.Forms.Padding(4)
			Me.groupBox5.Size = New System.Drawing.Size(195, 176)
			Me.groupBox5.TabIndex = 4
			Me.groupBox5.TabStop = False
			Me.groupBox5.Text = "Projections"
			' 
			' linkLabel11
			' 
			Me.linkLabel11.AutoSize = True
			Me.linkLabel11.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.linkLabel11.Location = New System.Drawing.Point(8, 68)
			Me.linkLabel11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
			Me.linkLabel11.Name = "linkLabel11"
			Me.linkLabel11.Size = New System.Drawing.Size(171, 22)
			Me.linkLabel11.TabIndex = 1
			Me.linkLabel11.TabStop = True
			Me.linkLabel11.Text = "Coordinate Systems"
'			Me.linkLabel11.LinkClicked += New System.Windows.Forms.LinkLabelLinkClickedEventHandler(Me.linkLabel11_LinkClicked);
			' 
			' linkLabel12
			' 
			Me.linkLabel12.AutoSize = True
			Me.linkLabel12.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.linkLabel12.Location = New System.Drawing.Point(8, 30)
			Me.linkLabel12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
			Me.linkLabel12.Name = "linkLabel12"
			Me.linkLabel12.Size = New System.Drawing.Size(125, 22)
			Me.linkLabel12.TabIndex = 0
			Me.linkLabel12.TabStop = True
			Me.linkLabel12.Text = "Projected Map"
'			Me.linkLabel12.LinkClicked += New System.Windows.Forms.LinkLabelLinkClickedEventHandler(Me.linkLabel12_LinkClicked);
			' 
			' linkLabel13
			' 
			Me.linkLabel13.AutoSize = True
			Me.linkLabel13.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.linkLabel13.Location = New System.Drawing.Point(7, 407)
			Me.linkLabel13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
			Me.linkLabel13.Name = "linkLabel13"
			Me.linkLabel13.Size = New System.Drawing.Size(165, 22)
			Me.linkLabel13.TabIndex = 5
			Me.linkLabel13.TabStop = True
			Me.linkLabel13.Text = "Product Information"
'			Me.linkLabel13.LinkClicked += New System.Windows.Forms.LinkLabelLinkClickedEventHandler(Me.linkLabel13_LinkClicked);
			' 
			' linkLabel14
			' 
			Me.linkLabel14.AutoSize = True
			Me.linkLabel14.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.linkLabel14.Location = New System.Drawing.Point(179, 407)
			Me.linkLabel14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
			Me.linkLabel14.Name = "linkLabel14"
			Me.linkLabel14.Size = New System.Drawing.Size(156, 22)
			Me.linkLabel14.TabIndex = 6
			Me.linkLabel14.TabStop = True
			Me.linkLabel14.Text = "Technical Support"
'			Me.linkLabel14.LinkClicked += New System.Windows.Forms.LinkLabelLinkClickedEventHandler(Me.linkLabel14_LinkClicked);
			' 
			' groupBox6
			' 
			Me.groupBox6.BackColor = System.Drawing.SystemColors.Menu
			Me.groupBox6.Controls.Add(Me.linkLabel18)
			Me.groupBox6.Controls.Add(Me.linkLabel19)
			Me.groupBox6.Location = New System.Drawing.Point(364, 209)
			Me.groupBox6.Margin = New System.Windows.Forms.Padding(4)
			Me.groupBox6.Name = "groupBox6"
			Me.groupBox6.Padding = New System.Windows.Forms.Padding(4)
			Me.groupBox6.Size = New System.Drawing.Size(195, 176)
			Me.groupBox6.TabIndex = 7
			Me.groupBox6.TabStop = False
			Me.groupBox6.Text = "Tutorials"
			' 
			' linkLabel18
			' 
			Me.linkLabel18.AutoSize = True
			Me.linkLabel18.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.linkLabel18.Location = New System.Drawing.Point(11, 68)
			Me.linkLabel18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
			Me.linkLabel18.Name = "linkLabel18"
			Me.linkLabel18.Size = New System.Drawing.Size(124, 22)
			Me.linkLabel18.TabIndex = 3
			Me.linkLabel18.TabStop = True
			Me.linkLabel18.Text = "Route Tutorial"
'			Me.linkLabel18.LinkClicked += New System.Windows.Forms.LinkLabelLinkClickedEventHandler(Me.linkLabel16_LinkClicked);
			' 
			' linkLabel19
			' 
			Me.linkLabel19.AutoSize = True
			Me.linkLabel19.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.linkLabel19.Location = New System.Drawing.Point(8, 32)
			Me.linkLabel19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
			Me.linkLabel19.Name = "linkLabel19"
			Me.linkLabel19.Size = New System.Drawing.Size(110, 22)
			Me.linkLabel19.TabIndex = 2
			Me.linkLabel19.TabStop = True
			Me.linkLabel19.Text = "Map Tutorial"
'			Me.linkLabel19.LinkClicked += New System.Windows.Forms.LinkLabelLinkClickedEventHandler(Me.linkLabel15_LinkClicked);
			' 
			' groupBox7
			' 
			Me.groupBox7.BackColor = System.Drawing.SystemColors.Menu
			Me.groupBox7.Controls.Add(Me.linkLabel20)
			Me.groupBox7.Controls.Add(Me.linkLabel21)
			Me.groupBox7.Location = New System.Drawing.Point(572, 15)
			Me.groupBox7.Margin = New System.Windows.Forms.Padding(4)
			Me.groupBox7.Name = "groupBox7"
			Me.groupBox7.Padding = New System.Windows.Forms.Padding(4)
			Me.groupBox7.Size = New System.Drawing.Size(147, 176)
			Me.groupBox7.TabIndex = 5
			Me.groupBox7.TabStop = False
			Me.groupBox7.Text = "Web Map Services"
			' 
			' linkLabel20
			' 
			Me.linkLabel20.AutoSize = True
			Me.linkLabel20.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.linkLabel20.Location = New System.Drawing.Point(8, 68)
			Me.linkLabel20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
			Me.linkLabel20.Name = "linkLabel20"
			Me.linkLabel20.Size = New System.Drawing.Size(124, 22)
			Me.linkLabel20.TabIndex = 1
			Me.linkLabel20.TabStop = True
			Me.linkLabel20.Text = "WMS Browser"
'			Me.linkLabel20.LinkClicked += New System.Windows.Forms.LinkLabelLinkClickedEventHandler(Me.linkLabel20_LinkClicked);
			' 
			' linkLabel21
			' 
			Me.linkLabel21.AutoSize = True
			Me.linkLabel21.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.linkLabel21.Location = New System.Drawing.Point(8, 30)
			Me.linkLabel21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
			Me.linkLabel21.Name = "linkLabel21"
			Me.linkLabel21.Size = New System.Drawing.Size(103, 22)
			Me.linkLabel21.TabIndex = 0
			Me.linkLabel21.TabStop = True
			Me.linkLabel21.Text = "WMS Layer"
'			Me.linkLabel21.LinkClicked += New System.Windows.Forms.LinkLabelLinkClickedEventHandler(Me.linkLabel21_LinkClicked);
			' 
			' MainForm
			' 
			Me.AutoScaleDimensions = New System.Drawing.SizeF(8F, 16F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.ClientSize = New System.Drawing.Size(733, 438)
			Me.Controls.Add(Me.groupBox7)
			Me.Controls.Add(Me.groupBox6)
			Me.Controls.Add(Me.linkLabel14)
			Me.Controls.Add(Me.linkLabel13)
			Me.Controls.Add(Me.groupBox5)
			Me.Controls.Add(Me.groupBox4)
			Me.Controls.Add(Me.groupBox3)
			Me.Controls.Add(Me.groupBox2)
			Me.Controls.Add(Me.groupBox1)
			Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
			Me.Margin = New System.Windows.Forms.Padding(4)
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "MainForm"
			Me.ShowIcon = False
			Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "ActualMap - Sample Applications"
			Me.groupBox1.ResumeLayout(False)
			Me.groupBox1.PerformLayout()
			Me.groupBox2.ResumeLayout(False)
			Me.groupBox2.PerformLayout()
			Me.groupBox3.ResumeLayout(False)
			Me.groupBox3.PerformLayout()
			Me.groupBox4.ResumeLayout(False)
			Me.groupBox4.PerformLayout()
			Me.groupBox5.ResumeLayout(False)
			Me.groupBox5.PerformLayout()
			Me.groupBox6.ResumeLayout(False)
			Me.groupBox6.PerformLayout()
			Me.groupBox7.ResumeLayout(False)
			Me.groupBox7.PerformLayout()
			Me.ResumeLayout(False)
			Me.PerformLayout()

		End Sub

		#End Region

		Private groupBox1 As System.Windows.Forms.GroupBox
		Private WithEvents linkLabel1 As System.Windows.Forms.LinkLabel
		Private WithEvents linkLabel4 As System.Windows.Forms.LinkLabel
		Private WithEvents linkLabel3 As System.Windows.Forms.LinkLabel
		Private WithEvents linkLabel2 As System.Windows.Forms.LinkLabel
		Private groupBox2 As System.Windows.Forms.GroupBox
		Private WithEvents linkLabel7 As System.Windows.Forms.LinkLabel
		Private WithEvents linkLabel8 As System.Windows.Forms.LinkLabel
		Private groupBox3 As System.Windows.Forms.GroupBox
		Private WithEvents linkLabel5 As System.Windows.Forms.LinkLabel
		Private WithEvents linkLabel6 As System.Windows.Forms.LinkLabel
		Private groupBox4 As System.Windows.Forms.GroupBox
		Private WithEvents linkLabel9 As System.Windows.Forms.LinkLabel
		Private WithEvents linkLabel10 As System.Windows.Forms.LinkLabel
		Private groupBox5 As System.Windows.Forms.GroupBox
		Private WithEvents linkLabel11 As System.Windows.Forms.LinkLabel
		Private WithEvents linkLabel12 As System.Windows.Forms.LinkLabel
		Private WithEvents linkLabel13 As System.Windows.Forms.LinkLabel
		Private WithEvents linkLabel14 As System.Windows.Forms.LinkLabel
		Private WithEvents linkLabel17 As System.Windows.Forms.LinkLabel
		Private groupBox6 As System.Windows.Forms.GroupBox
		Private WithEvents linkLabel18 As System.Windows.Forms.LinkLabel
		Private WithEvents linkLabel19 As System.Windows.Forms.LinkLabel
		Private WithEvents linkLabel16 As System.Windows.Forms.LinkLabel
		Private WithEvents linkLabel15 As System.Windows.Forms.LinkLabel
		Private groupBox7 As System.Windows.Forms.GroupBox
		Private WithEvents linkLabel20 As System.Windows.Forms.LinkLabel
		Private WithEvents linkLabel21 As System.Windows.Forms.LinkLabel
	End Class
End Namespace