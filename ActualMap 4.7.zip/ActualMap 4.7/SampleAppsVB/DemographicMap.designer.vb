Imports Microsoft.VisualBasic
Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports ActualMap
Imports ActualMap.Windows

Namespace SampleApps
	Partial Public Class DemographicMap
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(ByVal disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.statusBar1 = New System.Windows.Forms.StatusBar()
			Me.panel1 = New System.Windows.Forms.Panel()
			Me.panel2 = New System.Windows.Forms.Panel()
			Me.thematicFields = New System.Windows.Forms.ComboBox()
			Me.label1 = New System.Windows.Forms.Label()
			Me.legend1 = New ActualMap.Windows.Legend()
			Me.textBox1 = New System.Windows.Forms.TextBox()
			Me.splitter1 = New System.Windows.Forms.Splitter()
			Me.map1 = New ActualMap.Windows.Map()
			Me.panel1.SuspendLayout()
			Me.panel2.SuspendLayout()
			Me.SuspendLayout()
			' 
			' statusBar1
			' 
			Me.statusBar1.Location = New System.Drawing.Point(0, 473)
			Me.statusBar1.Name = "statusBar1"
			Me.statusBar1.Size = New System.Drawing.Size(879, 26)
			Me.statusBar1.TabIndex = 10
			' 
			' panel1
			' 
			Me.panel1.Controls.Add(Me.panel2)
			Me.panel1.Dock = System.Windows.Forms.DockStyle.Right
			Me.panel1.Location = New System.Drawing.Point(677, 0)
			Me.panel1.Name = "panel1"
			Me.panel1.Size = New System.Drawing.Size(202, 473)
			Me.panel1.TabIndex = 11
			' 
			' panel2
			' 
			Me.panel2.Controls.Add(Me.thematicFields)
			Me.panel2.Controls.Add(Me.label1)
			Me.panel2.Controls.Add(Me.legend1)
			Me.panel2.Controls.Add(Me.textBox1)
			Me.panel2.Dock = System.Windows.Forms.DockStyle.Fill
			Me.panel2.Location = New System.Drawing.Point(0, 0)
			Me.panel2.Name = "panel2"
			Me.panel2.Size = New System.Drawing.Size(202, 473)
			Me.panel2.TabIndex = 2
			' 
			' thematicFields
			' 
			Me.thematicFields.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
			Me.thematicFields.FormattingEnabled = True
			Me.thematicFields.Location = New System.Drawing.Point(11, 29)
			Me.thematicFields.Name = "thematicFields"
			Me.thematicFields.Size = New System.Drawing.Size(176, 24)
			Me.thematicFields.TabIndex = 23
'			Me.thematicFields.SelectedIndexChanged += New System.EventHandler(Me.thematicFields_SelectedIndexChanged);
			' 
			' label1
			' 
			Me.label1.AutoSize = True
			Me.label1.Location = New System.Drawing.Point(7, 10)
			Me.label1.Name = "label1"
			Me.label1.Size = New System.Drawing.Size(104, 17)
			Me.label1.TabIndex = 22
			Me.label1.Text = "Thematic Field:"
			' 
			' legend1
			' 
			Me.legend1.BackColor = System.Drawing.Color.Ivory
			Me.legend1.Dock = System.Windows.Forms.DockStyle.Bottom
			Me.legend1.IconHeight = 20
			Me.legend1.IconWidth = 20
			Me.legend1.Location = New System.Drawing.Point(0, 59)
			Me.legend1.Name = "legend1"
			Me.legend1.Size = New System.Drawing.Size(202, 286)
			Me.legend1.TabIndex = 21
			' 
			' textBox1
			' 
			Me.textBox1.BackColor = System.Drawing.SystemColors.Info
			Me.textBox1.Dock = System.Windows.Forms.DockStyle.Bottom
			Me.textBox1.Location = New System.Drawing.Point(0, 345)
			Me.textBox1.Multiline = True
			Me.textBox1.Name = "textBox1"
			Me.textBox1.ReadOnly = True
			Me.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both
			Me.textBox1.Size = New System.Drawing.Size(202, 128)
			Me.textBox1.TabIndex = 20
			Me.textBox1.TabStop = False
			Me.textBox1.Text = "This sample displays demographic data stored in a database."
			' 
			' splitter1
			' 
			Me.splitter1.Dock = System.Windows.Forms.DockStyle.Right
			Me.splitter1.Location = New System.Drawing.Point(674, 0)
			Me.splitter1.Name = "splitter1"
			Me.splitter1.Size = New System.Drawing.Size(3, 473)
			Me.splitter1.TabIndex = 12
			Me.splitter1.TabStop = False
			' 
			' map1
			' 
			Me.map1.BackColor = System.Drawing.Color.White
			Me.map1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
			Me.map1.Dock = System.Windows.Forms.DockStyle.Fill
			Me.map1.FontQuality = ActualMap.FontQuality.ClearType
			Me.map1.Location = New System.Drawing.Point(0, 0)
			Me.map1.MapTool = ActualMap.Windows.MapTool.Pan
			Me.map1.MapUnit = ActualMap.MeasureUnit.Degree
			Me.map1.Name = "map1"
			Me.map1.PixelPerInch = 96
			Me.map1.ScaleBar.BarUnit = ActualMap.UnitSystem.Imperial
			Me.map1.ScaleBar.FeetString = "ft"
			Me.map1.ScaleBar.Font.Alignment = ActualMap.TextAlign.Left
			Me.map1.ScaleBar.Font.Bold = False
			Me.map1.ScaleBar.Font.Charset = 1
			Me.map1.ScaleBar.Font.Color = System.Drawing.Color.FromArgb((CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))))
			Me.map1.ScaleBar.Font.Italic = False
			Me.map1.ScaleBar.Font.Name = "Arial"
			Me.map1.ScaleBar.Font.Outline = False
			Me.map1.ScaleBar.Font.OutlineColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
			Me.map1.ScaleBar.Font.Size = 12
			Me.map1.ScaleBar.Font.StrikeThrough = False
			Me.map1.ScaleBar.Font.Underline = False
			Me.map1.ScaleBar.KilometersString = "km"
			Me.map1.ScaleBar.MaxWidth = 0
			Me.map1.ScaleBar.MetersString = "m"
			Me.map1.ScaleBar.MilesString = "mi"
			Me.map1.ScaleBar.Position = ActualMap.ScaleBarPosition.BottomRight
			Me.map1.ScaleBar.Symbol.Bitmap = ""
			Me.map1.ScaleBar.Symbol.FillColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
			Me.map1.ScaleBar.Symbol.FillStyle = ActualMap.FillStyle.Solid
			Me.map1.ScaleBar.Symbol.InnerColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
			Me.map1.ScaleBar.Symbol.LineColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))))
			Me.map1.ScaleBar.Symbol.LineStyle = ActualMap.LineStyle.Solid
			Me.map1.ScaleBar.Symbol.PointStyle = ActualMap.PointStyle.Circle
			Me.map1.ScaleBar.Symbol.Rotation = 0
			Me.map1.ScaleBar.Symbol.Size = 1
			Me.map1.ScaleBar.Symbol.TransparentColor = System.Drawing.Color.Empty
			Me.map1.ScaleBar.Visible = False
			Me.map1.Size = New System.Drawing.Size(674, 473)
			Me.map1.SmoothingMode = ActualMap.SmoothingMode.AntiAlias
			Me.map1.TabIndex = 15
			Me.map1.ToolShape.FillColor = System.Drawing.Color.Silver
			Me.map1.ToolShape.LineColor = System.Drawing.Color.Red
			' 
			' DemographicMap
			' 
			Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
			Me.BackColor = System.Drawing.SystemColors.Control
			Me.ClientSize = New System.Drawing.Size(879, 499)
			Me.Controls.Add(Me.map1)
			Me.Controls.Add(Me.splitter1)
			Me.Controls.Add(Me.panel1)
			Me.Controls.Add(Me.statusBar1)
			Me.Name = "DemographicMap"
			Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
			Me.Text = "Demographic Map"
'			Me.Load += New System.EventHandler(Me.Form1_Load);
			Me.panel1.ResumeLayout(False)
			Me.panel2.ResumeLayout(False)
			Me.panel2.PerformLayout()
			Me.ResumeLayout(False)

		End Sub

		#End Region

		Private statusBar1 As System.Windows.Forms.StatusBar
		Private panel1 As System.Windows.Forms.Panel
		Private splitter1 As System.Windows.Forms.Splitter
		Private panel2 As System.Windows.Forms.Panel
		Private map1 As ActualMap.Windows.Map
		Private textBox1 As TextBox
		Private legend1 As Legend
		Private WithEvents thematicFields As ComboBox
		Private label1 As Label

	End Class
End Namespace