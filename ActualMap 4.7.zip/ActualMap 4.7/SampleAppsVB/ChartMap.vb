Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports ActualMap
Imports ActualMap.Windows

Namespace SampleApps
	Partial Public Class ChartMap
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub

		Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
			AddMapLayers()

			chartType.SelectedIndex = 0

			DoThematicMapping()
		End Sub

		Private Sub DoThematicMapping()
			Dim layer As ActualMap.Layer = map1("USA")
			Dim chartRenderer As ActualMap.ChartRenderer = layer.ChartRenderer

			chartRenderer.Clear()

			' population 1990
			chartRenderer.Add("POP1990", Color.Red)
			' population 1997
			chartRenderer.Add("POP1997", Color.Green)

			If chartType.SelectedItem.ToString() = "Bar" Then
				chartRenderer.ChartType = ActualMap.ChartType.Bar
				chartRenderer.BarHeight = 40
				chartRenderer.BarWidth = 30
			Else ' Pie
				chartRenderer.ChartType = ActualMap.ChartType.Pie
				chartRenderer.MinPieSize = 40
				chartRenderer.MaxPieSize = 60
			End If

			chartRenderer.OutlineColor = Color.Black
			chartRenderer.OutlineWidth = 1

			' populate the legend
			legend1.Clear()

			For Each item As ChartItem In chartRenderer
				legend1.Add(item.Field, chartRenderer.OutlineColor, item.FillColor)
			Next item

			map1.Refresh()
		End Sub

		Private Sub AddMapLayers()
			Dim dataSource As ActualMap.DataSource = New ActualMap.DataSource()
			Dim LayerFolder As String = Application.StartupPath & "\..\..\MAPS\USA\"

			Dim layer As ActualMap.Layer = map1.AddLayer(LayerFolder & "USA.shp")

			layer.ShowLabels = True
			layer.LabelField = "STATE_ABBR"
            layer.LabelStyle = ActualMap.LabelStyle.PolygonCenter

			Dim dataFile As String = Application.StartupPath & "\..\..\DATA\demography.mdb"

			dataSource.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & dataFile
			dataSource.CommandText = "SELECT * FROM demography"

			' create a relation between the USA shapefile and the 
			' database by the state abbreviation field
			If (Not map1("USA").AddRelate("STATE_ABBR", dataSource, "STATE_ABBR")) Then
				MessageBox.Show("Cannot add a relate to the database: " & dataFile)
			End If
		End Sub

		Private Sub chartType_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles chartType.SelectedIndexChanged
			DoThematicMapping()
		End Sub
	End Class
End Namespace