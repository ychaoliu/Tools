Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.IO
Imports System.Windows.Forms
Imports ActualMap
Imports ActualMap.Windows

Namespace SampleApps
	Partial Public Class Route
		Inherits Form
		Private _route As ActualMap.Route

		Public Sub New()
			InitializeComponent()
		End Sub

		Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
			AddMapLayers()

			Dim rs As ActualMap.Recordset = map1("locations").Recordset
			Do While Not rs.EOF
				startLocation.Items.Add(rs("NAME"))
				endLocation.Items.Add(rs("NAME"))
				rs.MoveNext()
			Loop
			startLocation.SelectedIndex = 1
			endLocation.SelectedIndex = 3
		End Sub

		Private Sub AddMapLayers()
			Dim layer As Layer

			Dim LayerFolder As String = Application.StartupPath & "\..\..\MAPS\ROUTING\"

			layer = map1.AddLayer(LayerFolder & "climits.shp")
			layer.Symbol.Size = 1
			layer.Symbol.LineColor = Color.FromArgb(199, 172, 116)
			layer.Symbol.FillColor = Color.FromArgb(242, 236, 223)

			layer = map1.AddLayer(LayerFolder & "roads.shp")
			layer.LabelField = "FNAME"
			layer.LabelFont.Size = 10
			layer.ShowLabels = True
            layer.Symbol.LineStyle = ActualMap.LineStyle.Road
			layer.Symbol.LineColor = Color.FromArgb(171, 158, 137)
			layer.Symbol.InnerColor = Color.White
			layer.Symbol.Size = 3

			layer = map1.AddLayer(LayerFolder & "locations.shp")
			layer.LabelField = "NAME"
			layer.LabelFont.Size = 12
			layer.LabelFont.Outline = True
			layer.ShowLabels = True
			layer.Symbol.Size = 8
            layer.Symbol.PointStyle = ActualMap.PointStyle.Triangle
			layer.Symbol.LineColor = Color.White
			layer.Symbol.FillColor = Color.FromArgb(0, 0, 200)

			map1.ZoomFull()
		End Sub

		Private Sub findRoute_Click(ByVal sender As Object, ByVal e As EventArgs) Handles findRoute.Click
			Dim start, [end] As ActualMap.Point
			Dim roadNetworkFolder As String = Application.StartupPath & "\..\..\MAPS\ROUTING\"

			' find coordinates of start and end locations
			start = GetLocationCoordinate(startLocation.SelectedItem.ToString())
			If start Is Nothing Then
			Return
			End If
			[end] = GetLocationCoordinate(endLocation.SelectedItem.ToString())
			If [end] Is Nothing Then
			Return
			End If

			If start.Equals([end]) Then
				MessageBox.Show("Locations are equal.")
				Return
			End If

			' load the road network 
			Dim roadNetwork As ActualMap.Network = New ActualMap.Network()

			If (Not roadNetwork.Open(roadNetworkFolder & "roads.shp", roadNetworkFolder & "roads.rtn")) Then
				MessageBox.Show("Cannot load road network: " & roadNetworkFolder & "roads.rtn")
				Return
			End If

			' create a Route object
			Dim route As ActualMap.Route = roadNetwork.CreateRoute()

			' set the properties of the Route object
			If btnMiles.Checked Then
                route.DistanceUnit = ActualMap.MeasureUnit.Mile
			Else
                route.DistanceUnit = ActualMap.MeasureUnit.Kilometer
			End If

			If btnQuickest.Checked Then
                route.RouteType = ActualMap.RouteType.Quickest
			Else
                route.RouteType = ActualMap.RouteType.Shortest
			End If

            route.MaxDistance = 0.5
            route.CurrentDate = DateTime.Now

			' find a route between two points
			If route.FindRoute(start.X, start.Y, [end].X, [end].Y) Then
				' remove previous route layers
				ClearRouteLayer()

				' merge the Segment objects of the Route to Street objects, 
				' the Street objects will be used to generate driving directions
				route.MergeSegments("ADDRESS")

				' add the route to the map
				AddRouteLayer(route)

				' generate driving directions
				GenerateDrivingDirections(route)

				' set the map extent to the route extent
				map1.Extent = route.Extent

				map1.Refresh()

				_route = route
			Else
				route.Dispose()
				MessageBox.Show("Route not found.")
			End If
		End Sub

		Private Function GetLocationCoordinate(ByVal locationName As String) As ActualMap.Point
			Dim rs As ActualMap.Recordset

			rs = map1("locations").SearchExpression("NAME = """ & locationName.Trim() & """")

			If rs.EOF Then
				MessageBox.Show("Location not found.")
				Return Nothing
			End If

			Return rs.Shape.GetPoint(0)
		End Function

		Private Sub AddRouteLayer(ByVal route As ActualMap.Route)
			Dim routeLayer As ActualMap.Layer = map1.AddLayer(route)

			routeLayer.Name = "RouteLayer"
			routeLayer.Symbol.LineColor = Color.FromArgb(198, 86, 245)
			routeLayer.Symbol.Size = 9
			routeLayer.Opacity = 0.3

			Dim routeMarkers As ActualMap.DynamicLayer = New ActualMap.DynamicLayer()

			' add a start marker
			Dim startMarker As ActualMap.MapShape = routeMarkers.Add(route.StartPoint, "Start")
			startMarker.Symbol.Size = 10
			startMarker.Symbol.FillColor = Color.FromArgb(0, 160, 0)
			startMarker.Symbol.LineColor = Color.White
			startMarker.Font.Name = "Verdana"
			startMarker.Font.Size = 14
			startMarker.Font.Bold = True
			startMarker.Font.Color = Color.FromArgb(0, 160, 0)
			startMarker.Font.Outline = True

			' add an end marker
			Dim endMarker As ActualMap.MapShape = routeMarkers.Add(route.EndPoint, "End")
			endMarker.Symbol.FillColor = Color.FromArgb(230, 0, 0)
			endMarker.Symbol.LineColor = Color.White
			endMarker.Font.Name = "Verdana"
			endMarker.Font.Size = 14
			endMarker.Font.Bold = True
			endMarker.Font.Color = Color.FromArgb(230, 0, 0)
			endMarker.Font.Outline = True

			' add street markers
			For street As Integer = 1 To route.Streets.Count - 1
				routeMarkers.Add(route.Streets(street).Start, Convert.ToString(street))
			Next street

			Dim markerLayer As ActualMap.Layer = map1.AddLayer(routeMarkers)
			markerLayer.Name = "RouteLayerMarkers"
			markerLayer.LabelField = "LABEL"
			markerLayer.ShowLabels = True

			' set attributes of the street markers as the default symbol/font of the marker layer
			markerLayer.LabelFont.Name = "Verdana"
			markerLayer.LabelFont.Size = 14
			markerLayer.LabelFont.Bold = True
			markerLayer.LabelFont.Color = Color.SteelBlue
			markerLayer.LabelFont.Outline = True
			markerLayer.Symbol.FillColor = Color.SteelBlue
			markerLayer.Symbol.LineColor = Color.White
			markerLayer.Symbol.Size = 8
		End Sub

		Private Sub GenerateDrivingDirections(ByVal route As ActualMap.Route)
			Dim streets As Streets = route.Streets
			If streets.Count = 0 Then
			Return
			End If

			Dim units As String

            If route.DistanceUnit = ActualMap.MeasureUnit.Mile Then
                units = "miles"
            Else
                units = "kilometers"
            End If

			Dim direction, distance As String

			directions.Columns.Add("Directions", 350)
			directions.Columns.Add("Distance (" & units & ")", 90)

			direction = "Start out going " & streets(0).Direction.ToString() & " on " & streets(0).Name

			If streets.Count > 1 Then
				direction &= " towards " & streets(1).Name
			End If

			distance = Convert.ToString(Math.Round(streets(0).Distance, 2))

			directions.Items.Add(New ListViewItem(New String() { direction, distance }))

			For i As Integer = 1 To streets.Count - 1
				Dim street As Street = streets(i)

				direction = i & ". "

				If street.TurnAngle > 30 Then
					direction &= "Turn LEFT onto " & street.Name
				ElseIf street.TurnAngle < -30 Then
					direction &= "Turn RIGHT onto " & street.Name
				Else
					direction &= "Road name changes to " & street.Name
				End If

				direction &= " (" & street.Direction.ToString() & ")"

				distance = Convert.ToString(Math.Round(street.Distance, 2))

				directions.Items.Add(New ListViewItem(New String() { direction, distance }))
			Next i

			direction = "Arrive " & streets(streets.Count - 1).Name

			directions.Items.Add(New ListViewItem(New String() { direction, "" }))

			direction = "Total Estimated Time: " & Convert.ToString(Math.Round(route.RouteTime / 60.0, 1)) & " minutes"

			directions.Items.Add(New ListViewItem(New String() { direction, "" }))

			direction = "Total Distance: " & Convert.ToString(Math.Round(route.RouteDistance, 2)) & " " & units

			directions.Items.Add(New ListViewItem(New String() { direction, "" }))
		End Sub

		Private Sub ClearRouteLayer()
			Dim index As Integer = map1.GetLayerIndex("RouteLayer")
			If index >= 0 Then
				map1.RemoveLayer(index)
			End If
			index = map1.GetLayerIndex("RouteLayerMarkers")
			If index >= 0 Then
				map1.RemoveLayer(index)
			End If

			directions.Columns.Clear()
			directions.Items.Clear()

			_route = Nothing
		End Sub

		Private Sub directions_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles directions.SelectedIndexChanged
			If _route Is Nothing OrElse directions.SelectedIndices.Count = 0 Then
			Return
			End If

			Dim index As Integer = directions.SelectedIndices(0)

			If index < _route.Streets.Count Then
				Dim street As Street = _route.Streets(index)
				map1.Extent = street.Shape.Extent
				map1.Refresh()
			End If
		End Sub

		Private Sub toolBar_ButtonClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles toolBar.ButtonClick
			If e.Button.Style = ToolBarButtonStyle.ToggleButton Then
				For Each b As ToolBarButton In toolBar.Buttons
				b.Pushed = False
				Next b
				e.Button.Pushed = True
			End If

			If e.Button Is zoomFull Then
				map1.ZoomFull()
				map1.Refresh()
			ElseIf e.Button Is zoomInTool Then
			map1.MapTool = MapTool.ZoomIn
			ElseIf e.Button Is zoomOutTool Then
			map1.MapTool = MapTool.ZoomOut
			ElseIf e.Button Is panTool Then
			map1.MapTool = MapTool.Pan
			End If
		End Sub
	End Class
End Namespace