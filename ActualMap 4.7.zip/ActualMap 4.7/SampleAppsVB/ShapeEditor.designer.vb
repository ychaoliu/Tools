Imports Microsoft.VisualBasic
Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports ActualMap
Imports ActualMap.Windows

Namespace SampleApps
    Partial Public Class ShapeEditor
        ''' <summary>
        ''' Required designer variable.
        ''' </summary>
        Private components As System.ComponentModel.IContainer = Nothing

        ''' <summary>
        ''' Clean up any resources being used.
        ''' </summary>
        ''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing AndAlso (components IsNot Nothing) Then
                components.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub

#Region "Windows Form Designer generated code"

        ''' <summary>
        ''' Required method for Designer support - do not modify
        ''' the contents of this method with the code editor.
        ''' </summary>
        Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ShapeEditor))
            Me.statusBar1 = New System.Windows.Forms.StatusBar()
            Me.splitter1 = New System.Windows.Forms.Splitter()
            Me.panel1 = New System.Windows.Forms.Panel()
            Me.panel3 = New System.Windows.Forms.Panel()
            Me.shapePanel = New System.Windows.Forms.Panel()
            Me.remove = New System.Windows.Forms.Button()
            Me.cancel = New System.Windows.Forms.Button()
            Me.save = New System.Windows.Forms.Button()
            Me.shapeTitle = New System.Windows.Forms.TextBox()
            Me.operation = New System.Windows.Forms.Label()
            Me.textBox1 = New System.Windows.Forms.TextBox()
            Me.toolStripContainer1 = New System.Windows.Forms.ToolStripContainer()
            Me.toolStrip1 = New System.Windows.Forms.ToolStrip()
            Me.infoTool = New System.Windows.Forms.ToolStripButton()
            Me.toolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
            Me.drawTool = New System.Windows.Forms.ToolStripButton()
            Me.editTool = New System.Windows.Forms.ToolStripButton()
            Me.toolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
            Me.panTool = New System.Windows.Forms.ToolStripButton()
            Me.toolStripButton1 = New System.Windows.Forms.ToolStripButton()
            Me.map1 = New ActualMap.Windows.Map()
            Me.toolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
            Me.toolStripButton2 = New System.Windows.Forms.ToolStripButton()
            Me.toolStripButton3 = New System.Windows.Forms.ToolStripButton()
            Me.toolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
            Me.panel1.SuspendLayout()
            Me.panel3.SuspendLayout()
            Me.shapePanel.SuspendLayout()
            Me.toolStripContainer1.ContentPanel.SuspendLayout()
            Me.toolStripContainer1.TopToolStripPanel.SuspendLayout()
            Me.toolStripContainer1.SuspendLayout()
            Me.toolStrip1.SuspendLayout()
            Me.SuspendLayout()
            ' 
            ' statusBar1
            ' 
            Me.statusBar1.Location = New System.Drawing.Point(0, 556)
            Me.statusBar1.Name = "statusBar1"
            Me.statusBar1.Size = New System.Drawing.Size(976, 26)
            Me.statusBar1.TabIndex = 10
            ' 
            ' splitter1
            ' 
            Me.splitter1.Dock = System.Windows.Forms.DockStyle.Right
            Me.splitter1.Location = New System.Drawing.Point(716, 0)
            Me.splitter1.Name = "splitter1"
            Me.splitter1.Size = New System.Drawing.Size(3, 556)
            Me.splitter1.TabIndex = 12
            Me.splitter1.TabStop = False
            ' 
            ' panel1
            ' 
            Me.panel1.Controls.Add(Me.panel3)
            Me.panel1.Dock = System.Windows.Forms.DockStyle.Right
            Me.panel1.Location = New System.Drawing.Point(719, 0)
            Me.panel1.Name = "panel1"
            Me.panel1.Size = New System.Drawing.Size(257, 556)
            Me.panel1.TabIndex = 11
            ' 
            ' panel3
            ' 
            Me.panel3.Controls.Add(Me.shapePanel)
            Me.panel3.Controls.Add(Me.textBox1)
            Me.panel3.Dock = System.Windows.Forms.DockStyle.Fill
            Me.panel3.Location = New System.Drawing.Point(0, 0)
            Me.panel3.Name = "panel3"
            Me.panel3.Size = New System.Drawing.Size(257, 556)
            Me.panel3.TabIndex = 2
            ' 
            ' shapePanel
            ' 
            Me.shapePanel.Controls.Add(Me.remove)
            Me.shapePanel.Controls.Add(Me.cancel)
            Me.shapePanel.Controls.Add(Me.save)
            Me.shapePanel.Controls.Add(Me.shapeTitle)
            Me.shapePanel.Controls.Add(Me.operation)
            Me.shapePanel.Dock = System.Windows.Forms.DockStyle.Fill
            Me.shapePanel.Location = New System.Drawing.Point(0, 266)
            Me.shapePanel.Name = "shapePanel"
            Me.shapePanel.Size = New System.Drawing.Size(257, 290)
            Me.shapePanel.TabIndex = 21
            ' 
            ' remove
            ' 
            Me.remove.Location = New System.Drawing.Point(118, 99)
            Me.remove.Name = "remove"
            Me.remove.Size = New System.Drawing.Size(75, 23)
            Me.remove.TabIndex = 34
            Me.remove.Text = "Remove"
            Me.remove.UseVisualStyleBackColor = True
            '			Me.remove.Click += New System.EventHandler(Me.remove_Click);
            ' 
            ' cancel
            ' 
            Me.cancel.Location = New System.Drawing.Point(118, 59)
            Me.cancel.Name = "cancel"
            Me.cancel.Size = New System.Drawing.Size(75, 23)
            Me.cancel.TabIndex = 33
            Me.cancel.Text = "Cancel"
            Me.cancel.UseVisualStyleBackColor = True
            '			Me.cancel.Click += New System.EventHandler(Me.cancel_Click);
            ' 
            ' save
            ' 
            Me.save.Location = New System.Drawing.Point(12, 59)
            Me.save.Name = "save"
            Me.save.Size = New System.Drawing.Size(75, 23)
            Me.save.TabIndex = 32
            Me.save.Text = "Save"
            Me.save.UseVisualStyleBackColor = True
            '			Me.save.Click += New System.EventHandler(Me.save_Click);
            ' 
            ' shapeTitle
            ' 
            Me.shapeTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, (CByte(204)))
            Me.shapeTitle.Location = New System.Drawing.Point(9, 26)
            Me.shapeTitle.Name = "shapeTitle"
            Me.shapeTitle.Size = New System.Drawing.Size(184, 22)
            Me.shapeTitle.TabIndex = 29
            Me.shapeTitle.Text = "Title"
            ' 
            ' operation
            ' 
            Me.operation.AutoSize = True
            Me.operation.Location = New System.Drawing.Point(9, 6)
            Me.operation.Name = "operation"
            Me.operation.Size = New System.Drawing.Size(80, 17)
            Me.operation.TabIndex = 28
            Me.operation.Text = "Add shape:"
            ' 
            ' textBox1
            ' 
            Me.textBox1.BackColor = System.Drawing.SystemColors.Info
            Me.textBox1.Dock = System.Windows.Forms.DockStyle.Top
            Me.textBox1.Location = New System.Drawing.Point(0, 0)
            Me.textBox1.Multiline = True
            Me.textBox1.Name = "textBox1"
            Me.textBox1.ReadOnly = True
            Me.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both
            Me.textBox1.Size = New System.Drawing.Size(257, 266)
            Me.textBox1.TabIndex = 20
            Me.textBox1.TabStop = False
            Me.textBox1.Text = resources.GetString("textBox1.Text")
            ' 
            ' toolStripContainer1
            ' 
            ' 
            ' toolStripContainer1.ContentPanel
            ' 
            Me.toolStripContainer1.ContentPanel.Controls.Add(Me.map1)
            Me.toolStripContainer1.ContentPanel.Size = New System.Drawing.Size(716, 529)
            Me.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill
            Me.toolStripContainer1.Location = New System.Drawing.Point(0, 0)
            Me.toolStripContainer1.Name = "toolStripContainer1"
            Me.toolStripContainer1.Size = New System.Drawing.Size(716, 556)
            Me.toolStripContainer1.TabIndex = 16
            Me.toolStripContainer1.Text = "toolStripContainer1"
            ' 
            ' toolStripContainer1.TopToolStripPanel
            ' 
            Me.toolStripContainer1.TopToolStripPanel.Controls.Add(Me.toolStrip1)
            ' 
            ' toolStrip1
            ' 
            Me.toolStrip1.Dock = System.Windows.Forms.DockStyle.None
            Me.toolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.infoTool, Me.toolStripSeparator1, Me.drawTool, Me.editTool, Me.toolStripSeparator2, Me.panTool, Me.toolStripButton1, Me.toolStripSeparator3, Me.toolStripButton2, Me.toolStripSeparator4, Me.toolStripButton3})
            Me.toolStrip1.Location = New System.Drawing.Point(3, 0)
            Me.toolStrip1.Name = "toolStrip1"
            Me.toolStrip1.Size = New System.Drawing.Size(321, 27)
            Me.toolStrip1.TabIndex = 0
            ' 
            ' infoTool
            ' 
            Me.infoTool.CheckOnClick = True
            Me.infoTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
            Me.infoTool.Image = (CType(resources.GetObject("infoTool.Image"), System.Drawing.Image))
            Me.infoTool.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
            Me.infoTool.ImageTransparentColor = System.Drawing.Color.Magenta
            Me.infoTool.Name = "infoTool"
            Me.infoTool.Size = New System.Drawing.Size(25, 24)
            Me.infoTool.Text = "Select"
            '			Me.infoTool.Click += New System.EventHandler(Me.infoTool_Click);
            ' 
            ' toolStripSeparator1
            ' 
            Me.toolStripSeparator1.Name = "toolStripSeparator1"
            Me.toolStripSeparator1.Size = New System.Drawing.Size(6, 27)
            ' 
            ' drawTool
            ' 
            Me.drawTool.CheckOnClick = True
            Me.drawTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
            Me.drawTool.Image = (CType(resources.GetObject("drawTool.Image"), System.Drawing.Image))
            Me.drawTool.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
            Me.drawTool.ImageTransparentColor = System.Drawing.Color.Magenta
            Me.drawTool.Name = "drawTool"
            Me.drawTool.Size = New System.Drawing.Size(25, 24)
            Me.drawTool.Text = "DrawShape"
            '			Me.drawTool.Click += New System.EventHandler(Me.drawTool_Click);
            ' 
            ' editTool
            ' 
            Me.editTool.CheckOnClick = True
            Me.editTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
            Me.editTool.Image = (CType(resources.GetObject("editTool.Image"), System.Drawing.Image))
            Me.editTool.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
            Me.editTool.ImageTransparentColor = System.Drawing.Color.Magenta
            Me.editTool.Name = "editTool"
            Me.editTool.Size = New System.Drawing.Size(25, 24)
            Me.editTool.Text = "EditShape"
            '			Me.editTool.Click += New System.EventHandler(Me.editTool_Click);
            ' 
            ' toolStripSeparator2
            ' 
            Me.toolStripSeparator2.Name = "toolStripSeparator2"
            Me.toolStripSeparator2.Size = New System.Drawing.Size(6, 27)
            ' 
            ' panTool
            ' 
            Me.panTool.Checked = True
            Me.panTool.CheckOnClick = True
            Me.panTool.CheckState = System.Windows.Forms.CheckState.Checked
            Me.panTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
            Me.panTool.Image = (CType(resources.GetObject("panTool.Image"), System.Drawing.Image))
            Me.panTool.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
            Me.panTool.ImageTransparentColor = System.Drawing.Color.Magenta
            Me.panTool.Name = "panTool"
            Me.panTool.Size = New System.Drawing.Size(25, 24)
            Me.panTool.Text = "Pan"
            '			Me.panTool.Click += New System.EventHandler(Me.panTool_Click);
            ' 
            ' toolStripButton1
            ' 
            Me.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
            Me.toolStripButton1.Image = (CType(resources.GetObject("toolStripButton1.Image"), System.Drawing.Image))
            Me.toolStripButton1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
            Me.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
            Me.toolStripButton1.Name = "toolStripButton1"
            Me.toolStripButton1.Size = New System.Drawing.Size(25, 24)
            Me.toolStripButton1.Text = "Full Extent"
            '			Me.toolStripButton1.Click += New System.EventHandler(Me.toolStripButton1_Click);
            ' 
            ' map1
            ' 
            Me.map1.BackColor = System.Drawing.Color.White
            Me.map1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
            Me.map1.Dock = System.Windows.Forms.DockStyle.Fill
            Me.map1.FontQuality = ActualMap.FontQuality.ClearType
            Me.map1.Location = New System.Drawing.Point(0, 0)
            Me.map1.MapTool = ActualMap.Windows.MapTool.Info
            Me.map1.Name = "map1"
            Me.map1.PixelPerInch = 96
            Me.map1.ScaleBar.BarUnit = ActualMap.UnitSystem.Imperial
            Me.map1.ScaleBar.FeetString = "ft"
            Me.map1.ScaleBar.Font.Alignment = ActualMap.TextAlign.Left
            Me.map1.ScaleBar.Font.Bold = False
            Me.map1.ScaleBar.Font.Charset = 1
            Me.map1.ScaleBar.Font.Color = System.Drawing.Color.FromArgb((CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))))
            Me.map1.ScaleBar.Font.Italic = False
            Me.map1.ScaleBar.Font.Name = "Arial"
            Me.map1.ScaleBar.Font.Outline = False
            Me.map1.ScaleBar.Font.OutlineColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
            Me.map1.ScaleBar.Font.Size = 12
            Me.map1.ScaleBar.Font.StrikeThrough = False
            Me.map1.ScaleBar.Font.Underline = False
            Me.map1.ScaleBar.KilometersString = "km"
            Me.map1.ScaleBar.MaxWidth = 0
            Me.map1.ScaleBar.MetersString = "m"
            Me.map1.ScaleBar.MilesString = "mi"
            Me.map1.ScaleBar.Position = ActualMap.ScaleBarPosition.BottomRight
            Me.map1.ScaleBar.Symbol.Bitmap = ""
            Me.map1.ScaleBar.Symbol.FillColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
            Me.map1.ScaleBar.Symbol.FillStyle = ActualMap.FillStyle.Solid
            Me.map1.ScaleBar.Symbol.InnerColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
            Me.map1.ScaleBar.Symbol.LineColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))))
            Me.map1.ScaleBar.Symbol.LineStyle = ActualMap.LineStyle.Solid
            Me.map1.ScaleBar.Symbol.PointStyle = ActualMap.PointStyle.Circle
            Me.map1.ScaleBar.Symbol.Rotation = 0
            Me.map1.ScaleBar.Symbol.Size = 1
            Me.map1.ScaleBar.Symbol.TransparentColor = System.Drawing.Color.Empty
            Me.map1.ScaleBar.Visible = True
            Me.map1.Size = New System.Drawing.Size(716, 529)
            Me.map1.SmoothingMode = ActualMap.SmoothingMode.AntiAlias
            Me.map1.TabIndex = 16
            Me.map1.ToolShape.FillColor = System.Drawing.Color.LightGray
            Me.map1.ToolShape.LineColor = System.Drawing.Color.Red
            Me.map1.ToolShape.LineWidth = 1
            Me.map1.ToolShape.VertexColor = System.Drawing.Color.Red
            Me.map1.ToolShape.VertexSize = 10
            Me.map1.ToolShape.VirtualVertexColor = System.Drawing.Color.Green
            '			Me.map1.InfoTool += New ActualMap.Windows.InfoToolEventHandler(Me.map1_InfoTool);
            ' 
            ' toolStripSeparator3
            ' 
            Me.toolStripSeparator3.Name = "toolStripSeparator3"
            Me.toolStripSeparator3.Size = New System.Drawing.Size(6, 27)
            ' 
            ' toolStripButton2
            ' 
            Me.toolStripButton2.BackColor = System.Drawing.SystemColors.Control
            Me.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
            Me.toolStripButton2.Image = (CType(resources.GetObject("toolStripButton2.Image"), System.Drawing.Image))
            Me.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
            Me.toolStripButton2.Name = "toolStripButton2"
            Me.toolStripButton2.Size = New System.Drawing.Size(113, 24)
            Me.toolStripButton2.Text = "Remove Vertex"
            '			Me.toolStripButton2.Click += New System.EventHandler(Me.toolStripButton2_Click);
            ' 
            ' toolStripButton3
            ' 
            Me.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
            Me.toolStripButton3.Image = (CType(resources.GetObject("toolStripButton3.Image"), System.Drawing.Image))
            Me.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
            Me.toolStripButton3.Name = "toolStripButton3"
            Me.toolStripButton3.Size = New System.Drawing.Size(47, 24)
            Me.toolStripButton3.Text = "Clear"
            '			Me.toolStripButton3.Click += New System.EventHandler(Me.toolStripButton3_Click);
            ' 
            ' toolStripSeparator4
            ' 
            Me.toolStripSeparator4.Name = "toolStripSeparator4"
            Me.toolStripSeparator4.Size = New System.Drawing.Size(6, 27)
            ' 
            ' ShapeEditor
            ' 
            Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
            Me.BackColor = System.Drawing.SystemColors.Control
            Me.ClientSize = New System.Drawing.Size(976, 582)
            Me.Controls.Add(Me.toolStripContainer1)
            Me.Controls.Add(Me.splitter1)
            Me.Controls.Add(Me.panel1)
            Me.Controls.Add(Me.statusBar1)
            Me.Name = "ShapeEditor"
            Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
            Me.Text = "Shape Editor"
            '			Me.Load += New System.EventHandler(Me.Form1_Load);
            Me.panel1.ResumeLayout(False)
            Me.panel3.ResumeLayout(False)
            Me.panel3.PerformLayout()
            Me.shapePanel.ResumeLayout(False)
            Me.shapePanel.PerformLayout()
            Me.toolStripContainer1.ContentPanel.ResumeLayout(False)
            Me.toolStripContainer1.TopToolStripPanel.ResumeLayout(False)
            Me.toolStripContainer1.TopToolStripPanel.PerformLayout()
            Me.toolStripContainer1.ResumeLayout(False)
            Me.toolStripContainer1.PerformLayout()
            Me.toolStrip1.ResumeLayout(False)
            Me.toolStrip1.PerformLayout()
            Me.ResumeLayout(False)

        End Sub

#End Region

        Private statusBar1 As System.Windows.Forms.StatusBar
        Private splitter1 As System.Windows.Forms.Splitter
        Private panel1 As Panel
        Private panel3 As Panel
        Private shapePanel As Panel
        Private WithEvents remove As Button
        Private WithEvents cancel As Button
        Private WithEvents save As Button
        Private shapeTitle As TextBox
        Private operation As Label
        Private textBox1 As TextBox
        Private toolStripContainer1 As ToolStripContainer
        Private WithEvents map1 As Map
        Private toolStrip1 As ToolStrip
        Private WithEvents infoTool As ToolStripButton
        Private toolStripSeparator1 As ToolStripSeparator
        Private WithEvents panTool As ToolStripButton
        Private WithEvents editTool As ToolStripButton
        Private WithEvents drawTool As ToolStripButton
        Private toolStripSeparator2 As ToolStripSeparator
        Private WithEvents toolStripButton1 As ToolStripButton
        Private toolStripSeparator3 As ToolStripSeparator
        Private WithEvents toolStripButton2 As ToolStripButton
        Private WithEvents toolStripButton3 As ToolStripButton
        Private toolStripSeparator4 As ToolStripSeparator

    End Class
End Namespace