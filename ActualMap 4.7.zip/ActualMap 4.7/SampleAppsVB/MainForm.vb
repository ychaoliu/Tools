Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms

Namespace SampleApps
	Partial Public Class MainForm
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub

		''' <summary>
		''' The main entry point for the application.
		''' </summary>
		<STAThread> _
		Shared Sub Main()
			Application.Run(New MainForm())
		End Sub

		Private Sub linkLabel13_LinkClicked(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles linkLabel13.LinkClicked
			System.Diagnostics.Process.Start("http://www.vdstech.com/actualmap.aspx")
		End Sub

		Private Sub linkLabel14_LinkClicked(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles linkLabel14.LinkClicked
			System.Diagnostics.Process.Start("http://www.vdstech.com/support.aspx")
		End Sub

		Private Sub linkLabel1_LinkClicked(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles linkLabel1.LinkClicked
			CType(New StreetMap(), StreetMap).ShowDialog()
		End Sub

		Private Sub linkLabel2_LinkClicked(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles linkLabel2.LinkClicked
			CType(New MapTools(), MapTools).ShowDialog()
		End Sub

		Private Sub linkLabel3_LinkClicked(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles linkLabel3.LinkClicked
			CType(New USAMap(), USAMap).ShowDialog()
		End Sub

		Private Sub linkLabel4_LinkClicked(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles linkLabel4.LinkClicked
			CType(New WorldMap(), WorldMap).ShowDialog()
		End Sub

		Private Sub linkLabel8_LinkClicked(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles linkLabel8.LinkClicked
			CType(New Airports(), Airports).ShowDialog()
		End Sub

		Private Sub linkLabel7_LinkClicked(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles linkLabel7.LinkClicked
			CType(New ParcelMap(), ParcelMap).ShowDialog()
		End Sub

		Private Sub linkLabel12_LinkClicked(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles linkLabel12.LinkClicked
			CType(New ProjectedWorldMap(), ProjectedWorldMap).ShowDialog()
		End Sub

		Private Sub linkLabel11_LinkClicked(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles linkLabel11.LinkClicked
			CType(New CommonCoordSystem(), CommonCoordSystem).ShowDialog()
		End Sub

		Private Sub linkLabel6_LinkClicked(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles linkLabel6.LinkClicked
			CType(New VehicleTracking(), VehicleTracking).ShowDialog()
		End Sub

		Private Sub linkLabel5_LinkClicked(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles linkLabel5.LinkClicked
			CType(New Route(), Route).ShowDialog()
		End Sub

		Private Sub linkLabel10_LinkClicked(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles linkLabel10.LinkClicked
			CType(New DemographicMap(), DemographicMap).ShowDialog()
		End Sub

		Private Sub linkLabel9_LinkClicked(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles linkLabel9.LinkClicked
			CType(New Population(), Population).ShowDialog()
		End Sub

		Private Sub linkLabel15_LinkClicked(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles linkLabel19.LinkClicked
			CType(New MapTutorial(), MapTutorial).ShowDialog()
		End Sub

		Private Sub linkLabel16_LinkClicked(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles linkLabel18.LinkClicked
			CType(New RouteTutorial(), RouteTutorial).ShowDialog()
		End Sub

		Private Sub linkLabel17_LinkClicked(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles linkLabel17.LinkClicked
			CType(New ChartMap(), ChartMap).ShowDialog()
		End Sub

		Private Sub linkLabel15_LinkClicked_1(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles linkLabel15.LinkClicked
			CType(New LocationEditor(), LocationEditor).ShowDialog()
		End Sub

		Private Sub linkLabel16_LinkClicked_1(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles linkLabel16.LinkClicked
			CType(New ShapeEditor(), ShapeEditor).ShowDialog()
		End Sub

		Private Sub linkLabel21_LinkClicked(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles linkLabel21.LinkClicked
            CType(New WMSLayerApp(), WMSLayerApp).ShowDialog()
		End Sub

		Private Sub linkLabel20_LinkClicked(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles linkLabel20.LinkClicked
			CType(New WMSBrowser(), WMSBrowser).ShowDialog()
		End Sub

	End Class

End Namespace