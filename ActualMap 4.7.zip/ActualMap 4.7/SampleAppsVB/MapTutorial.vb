Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Data.OleDb
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports ActualMap
Imports ActualMap.Data
Imports ActualMap.Windows

Namespace SampleApps
	Partial Public Class MapTutorial
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub

		Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
			AddMapLayers()
			AddDatabase()
		End Sub

		Private Sub AddMapLayers()
			Dim layer As Layer

			Dim MapDir As String = Application.StartupPath & "\..\..\MAPS\USA\"

			' add States layer
			layer = map1.AddLayer(MapDir & "States.shp")

			layer.LabelField = "STATE_ABBR"
			layer.ShowLabels = True
			layer.LabelFont.Name = "Verdana"
			layer.LabelFont.Size = 12
			layer.LabelFont.Bold = True
            layer.LabelStyle = ActualMap.LabelStyle.PolygonCenter

			RenderStates(layer)

			' add Roads layer
			layer = map1.AddLayer(MapDir & "Roads.shp")

			layer.Symbol.LineColor = Color.Red
			layer.Symbol.Size = 2

			layer.LabelField = "NUMBER"
			layer.ShowLabels = True
			layer.LabelFont.Size = 12

			RenderRoads(layer)

			' add Capitals layer
			layer = map1.AddLayer(MapDir & "Capitals.shp")

            layer.Symbol.PointStyle = ActualMap.PointStyle.CircleWithLargeCenter
			layer.Symbol.Size = 10
			layer.Symbol.FillColor = Color.FromArgb(255, 255, 0)

			layer.LabelField = "CITY_NAME"
			layer.ShowLabels = True
			layer.LabelFont.Name = "Arial"
			layer.LabelFont.Bold = True
			layer.LabelFont.Size = 14
			layer.LabelFont.Outline = True
			layer.LabelFont.OutlineColor = Color.FromArgb(255, 255, 0)
		End Sub

		Private Sub RenderRoads(ByVal RoadLayer As ActualMap.Layer)
			Dim renderer As FeatureRenderer
			Dim feature As Feature

			renderer = RoadLayer.Renderer
			renderer.Field = "CLASS"

			feature = renderer.Add()
			feature.Value = "Interstate"
			feature.Symbol.LineColor = Color.Red
			feature.Symbol.Size = 2

			feature = renderer.Add()
			feature.Value = "US Highway"
			feature.Symbol.LineColor = Color.Blue
			feature.Symbol.Size = 2

			feature = renderer.Add()
			feature.Value = "State Highway"
			feature.Symbol.LineColor = Color.Green
			feature.Symbol.Size = 2
		End Sub

		Private Sub RenderStates(ByVal StateLayer As ActualMap.Layer)
			Dim renderer As FeatureRenderer
			Dim feature As Feature

			renderer = StateLayer.Renderer

			feature = renderer.Add()
			feature.Expression = "POPULATION < 1000000"
			feature.Symbol.FillColor = Color.LightYellow

			feature = renderer.Add()
			feature.Expression = "POPULATION < 5000000"
			feature.Symbol.FillColor = Color.Yellow

			feature = renderer.Add()
			feature.Expression = "POPULATION < 10000000"
			feature.Symbol.FillColor = Color.Pink

			feature = renderer.Add()
			feature.Expression = "POPULATION >= 10000000"
			feature.Symbol.FillColor = Color.Red
		End Sub

		Private Sub AddDatabase()
            Dim dataFile As String = Application.StartupPath & "\..\..\DATA\airports.mdb"
            Dim connectionString As String = "PROVIDER=Microsoft.Jet.OLEDB.4.0;DATA Source=" & dataFile

            Dim pointData As PointDataLayer = New PointDataLayer("System.Data.OleDb", connectionString, "airports", "LONGITUDE", "LATITUDE")

            Dim dbLayer As Layer = map1.AddLayer(pointData)
			If dbLayer Is Nothing Then
				MessageBox.Show("Cannot add airports.mdb database.")
				Return
			End If

			dbLayer.Name = "Airports"
            dbLayer.Symbol.PointStyle = ActualMap.PointStyle.Circle
			dbLayer.Symbol.FillColor = Color.Silver

			dbLayer.LabelField = "DESCRIP"
			dbLayer.LabelFont.Name = "Arial"
			dbLayer.LabelFont.Size = 12
		End Sub

		Private Sub map1_InfoTool(ByVal sender As Object, ByVal e As ActualMap.Windows.InfoToolEventArgs) Handles map1.InfoTool
			map1.Callouts.Clear()

			Dim records As ActualMap.Recordset = map1.Identify(e.InfoPoint, 5)

			If (Not records.EOF) Then
				dataGridView1.DataSource = records

				Dim callout As Callout = map1.Callouts.Add()
				callout.X = e.InfoPoint.X
				callout.Y = e.InfoPoint.Y
				callout.Font.Size = 16

				If records.Layer.LabelField.Length > 0 Then
					callout.Text = records(records.Layer.LabelField).ToString()
				Else
					callout.Text = records(0).ToString()
				End If

				map1.Refresh()
			End If
		End Sub

		Private Sub zoomFull_Click(ByVal sender As Object, ByVal e As EventArgs) Handles zoomFull.Click
			map1.ZoomFull()
			map1.Refresh()
		End Sub

		Private Sub zoomInTool_Click(ByVal sender As Object, ByVal e As EventArgs) Handles zoomInTool.Click
			map1.MapTool = MapTool.ZoomIn
			CheckButton(zoomInTool)
		End Sub

		Private Sub zoomOutTool_Click(ByVal sender As Object, ByVal e As EventArgs) Handles zoomOutTool.Click
			map1.MapTool = MapTool.ZoomOut
			CheckButton(zoomOutTool)
		End Sub

		Private Sub panTool_Click(ByVal sender As Object, ByVal e As EventArgs) Handles panTool.Click
			map1.MapTool = MapTool.Pan
			CheckButton(panTool)
		End Sub

		Private Sub infoTool_Click(ByVal sender As Object, ByVal e As EventArgs) Handles infoTool.Click
			map1.MapTool = MapTool.Info
			CheckButton(infoTool)
		End Sub

		Private Sub CheckButton(ByVal button As ToolStripButton)
			zoomInTool.Checked = False
			zoomOutTool.Checked = False
			panTool.Checked = False
			infoTool.Checked = False
			button.Checked = True
		End Sub
	End Class
End Namespace