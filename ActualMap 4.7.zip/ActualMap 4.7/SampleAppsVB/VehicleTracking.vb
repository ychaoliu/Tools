Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.IO
Imports System.Windows.Forms
Imports ActualMap
Imports ActualMap.Windows

Namespace SampleApps
	Partial Public Class VehicleTracking
		Inherits Form
		Private position As Integer = 0

		Public Sub New()
			InitializeComponent()
		End Sub

		Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
			AddMapLayers()
			map1.StartAnimation(1000)
		End Sub

		Private Sub startTracking_Click(ByVal sender As Object, ByVal e As EventArgs) Handles startTracking.Click
			map1.StartAnimation(1000)
		End Sub

		Private Sub stopTracking_Click(ByVal sender As Object, ByVal e As EventArgs) Handles stopTracking.Click
			map1.StopAnimation()
		End Sub

		Private Sub map1_RefreshAnimationLayer(ByVal sender As Object, ByVal e As RefreshAnimationLayerArgs) Handles map1.RefreshAnimationLayer
			TrackVehicles()
		End Sub

		Private Sub TrackVehicles()
			map1.AnimationLayer.Clear()

			Dim vehicleLocation As ActualMap.Point = GetVehicleCoordinates()

			Dim geoEvent As GeoEvent = New GeoEvent(vehicleLocation)

            geoEvent.Symbol.PointStyle = ActualMap.PointStyle.Bitmap
			geoEvent.Symbol.Bitmap = Application.StartupPath & "\..\..\SYMBOLS\vehicle.gif"
			geoEvent.Symbol.TransparentColor = Color.White
			geoEvent.Symbol.Size = 20
			geoEvent.Label = "Vehicle 1"

			map1.AnimationLayer.Add(geoEvent)
		End Sub

		Private Sub AddMapLayers()
			Dim layer As Layer

			Dim LayerFolder As String = Application.StartupPath & "\..\..\MAPS\STREETS\"

			'- COUNTY -------------------------------------------
			layer = map1.AddLayer(LayerFolder & "County.shp")

			layer.LabelField = "NAME"
			layer.Symbol.Size = 2
			layer.Symbol.LineColor = Color.FromArgb(199, 172, 116)
			layer.Symbol.FillColor = Color.FromArgb(242, 236, 223)

			'- STREETS ------------------------------------------
			layer = map1.AddLayer(LayerFolder & "Street.shp")

			layer.LabelField = "NAME"
			layer.LabelFont.Size = 10
			layer.Symbol.Size = 3
            layer.Symbol.LineStyle = ActualMap.LineStyle.Road
			layer.Symbol.LineColor = Color.FromArgb(171, 158, 137)
			layer.Symbol.InnerColor = Color.White
		End Sub

		' For demostration purposes, obtains GPS coordinates (latitude/longitude) of the vehicle from a text file.
		Private Function GetVehicleCoordinates() As ActualMap.Point
			Dim reader As StreamReader = File.OpenText(Application.StartupPath & "\..\..\DATA\vehicle_points.txt")

			Dim line As String
			Dim points As ActualMap.Points = New ActualMap.Points()

			line = reader.ReadLine()
			Do While line IsNot Nothing
				Dim coords() As String = line.Split(" "c)
				points.Add(Convert.ToDouble(coords(0)), Convert.ToDouble(coords(1)))
				line = reader.ReadLine()
			Loop

			reader.Close()

			If position+1 >= points.Count Then
				position = 0
			Else
				position += 1
			End If

			Return points(position)
		End Function

		Private Sub toolBar_ButtonClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles toolBar.ButtonClick
			If e.Button.Style = ToolBarButtonStyle.ToggleButton Then
				For Each b As ToolBarButton In toolBar.Buttons
				b.Pushed = False
				Next b
				e.Button.Pushed = True
			End If

			If e.Button Is zoomFull Then
				map1.ZoomFull()
				map1.Refresh()
			ElseIf e.Button Is zoomInTool Then
			map1.MapTool = MapTool.ZoomIn
			ElseIf e.Button Is zoomOutTool Then
			map1.MapTool = MapTool.ZoomOut
			ElseIf e.Button Is panTool Then
			map1.MapTool = MapTool.Pan
			End If
		End Sub
	End Class
End Namespace