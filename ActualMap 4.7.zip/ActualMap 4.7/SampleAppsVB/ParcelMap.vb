Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports System.Text.RegularExpressions
Imports ActualMap
Imports ActualMap.Windows


Namespace SampleApps
	Partial Public Class ParcelMap
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub

		Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
			' map units of the parcels.shp, streets.shp and aerialphoto.tif files are feet
            map1.MapUnit = ActualMap.MeasureUnit.Foot

			AddMapLayers()
			UpdateLayerProperties()

			' add a relation to the parcel tax database
			AddRelation()
		End Sub

		' adds a relation to the parcel tax database
		Private Sub AddRelation()
			Dim DataFolder As String = Application.StartupPath & "\..\..\DATA\"

			Dim dataSource As ActualMap.DataSource = New ActualMap.DataSource()

			Dim dataFile As String = DataFolder & "taxattr.mdb"

			dataSource.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & dataFile
			dataSource.CommandText = "SELECT * From taxattr"

			' create a relation between the parcel shapefile and the 
			' database by the parcel number field
			If (Not map1("parcels").AddRelate("PARNUM", dataSource, "PARNUM")) Then
				MessageBox.Show("Cannot add a relate to the database: " & dataFile)
			End If
		End Sub

		Private Sub AddMapLayers()
			Dim layer As Layer

			Dim LayerFolder As String = Application.StartupPath & "\..\..\MAPS\PARCELS\"

			map1.AddLayer(LayerFolder & "aerialphoto.tif")

			' parcel shapefile
			layer = map1.AddLayer(LayerFolder & "parcels.shp")

			layer.LabelField = "PARNUM"
            layer.LabelStyle = ActualMap.LabelStyle.PolygonCenter
			layer.LabelFont.Size = 14
			layer.LabelFont.Outline = True
			layer.LabelFont.OutlineColor = Color.Black
			layer.LabelFont.Color = Color.White

            layer.Symbol.FillStyle = ActualMap.FillStyle.Invisible
			layer.Symbol.LineColor = Color.White

			' street shapefile
			layer = map1.AddLayer(LayerFolder & "streets.shp")

			layer.LabelField = "STREET"
			layer.LabelFont.Name = "Verdana"
			layer.LabelFont.Size = 14
			layer.LabelFont.Outline = True
			layer.LabelFont.OutlineColor = Color.FromArgb(255, 255, 0)

            layer.Symbol.LineStyle = ActualMap.LineStyle.Invisible
		End Sub

		Private Sub map1_MapScaleChanged(ByVal sender As Object, ByVal e As MapScaleChangedEventArgs) Handles map1.MapScaleChanged
			' update layers depending on the new scale
			UpdateLayerProperties()
		End Sub

		Private Sub UpdateLayerProperties()
			Dim layer As Layer = map1("parcels")
            layer.ShowLabels = (map1.ConvertDistance(map1.Extent.Width, map1.MapUnit, ActualMap.MeasureUnit.Mile) <= 1)

			layer = map1("streets")
            layer.ShowLabels = (map1.ConvertDistance(map1.Extent.Width, map1.MapUnit, ActualMap.MeasureUnit.Mile) <= 1)
		End Sub

		Private Sub toolBar_ButtonClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles toolBar.ButtonClick
			If e.Button.Style = ToolBarButtonStyle.ToggleButton Then
				For Each b As ToolBarButton In toolBar.Buttons
				b.Pushed = False
				Next b
				e.Button.Pushed = True
			End If

			If e.Button Is zoomFull Then
				map1.ZoomFull()
				map1.Refresh()
			End If
			If e.Button Is clearShapes Then
				map1.MapShapes.Clear()
				map1.Callouts.Clear()
				dataGrid.DataSource = Nothing
				dataGrid.CaptionText = String.Empty
				map1.Refresh()
			ElseIf e.Button Is zoomInTool Then
			map1.MapTool = MapTool.ZoomIn
			ElseIf e.Button Is zoomOutTool Then
			map1.MapTool = MapTool.ZoomOut
			ElseIf e.Button Is panTool Then
			map1.MapTool = MapTool.Pan
			ElseIf e.Button Is centerTool Then
			map1.MapTool = MapTool.Center
			ElseIf e.Button Is distanceTool Then
			map1.MapTool = MapTool.Distance
			ElseIf e.Button Is infoTool Then
			map1.MapTool = MapTool.Info
			End If
		End Sub

		Private Sub map1_InfoTool(ByVal sender As Object, ByVal e As ActualMap.Windows.InfoToolEventArgs) Handles map1.InfoTool
			map1.Callouts.Clear()

			Dim records As ActualMap.Recordset = map1.Identify(e.InfoPoint, 5)

			If (Not records.EOF) Then
				dataGrid.DataSource = records
				dataGrid.CaptionText = records.Layer.Name

				Dim callout As Callout = map1.Callouts.Add()
				callout.X = e.InfoPoint.X
				callout.Y = e.InfoPoint.Y
				callout.Text = GetCalloutText(records)
				callout.Font.Size = 16

				map1.Refresh()
			End If
		End Sub

		Private Sub menuItem2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles menuItem2.Click
			printPreview.ShowDialog()
		End Sub

		Private Sub printDocument_PrintPage(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles printDocument.PrintPage
			Dim mapImage As Bitmap = map1.GetBitmap(700, 600)
			e.Graphics.DrawImageUnscaled(mapImage, 50, 50)
		End Sub

		Private Function GetCalloutText(ByVal rs As ActualMap.Recordset) As String
			Dim index As Integer = rs.Fields.GetFieldIndex("NAME")
			If index < 0 Then
			index = rs.Fields.GetFieldIndex(rs.Layer.LabelField)
			End If
			If index < 0 Then
			index = 0
			End If
			Return rs(index).ToString()
		End Function

		Private Sub map1_DistanceToolMove(ByVal sender As Object, ByVal e As DistanceToolEventArgs) Handles map1.DistanceToolMove
			Dim distanceInMapUnits As Double = e.Distance
            Dim distanceInMiles As Double = Math.Round(map1.ConvertDistance(distanceInMapUnits, map1.MapUnit, ActualMap.MeasureUnit.Mile), 3)
            Dim distanceInKilometers As Double = Math.Round(map1.ConvertDistance(distanceInMapUnits, map1.MapUnit, ActualMap.MeasureUnit.Kilometer), 3)

			statusBar1.Text = distanceInMiles.ToString() & " mi  |  " & distanceInKilometers.ToString() & " km"
		End Sub

		Private Sub map1_DistanceToolFinished(ByVal sender As Object, ByVal e As DistanceToolEventArgs) Handles map1.DistanceToolFinished
			statusBar1.Text = String.Empty
		End Sub

		Private Sub btnAddress_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAddress.Click
			Dim simpleAddrPattern As String = "^(?<num>\d+)\W+(?<street>.+)"

			Dim address As String = txtAddress.Text.Trim()

			If (Not Regex.IsMatch(address, simpleAddrPattern)) Then
				MessageBox.Show("Invalid address format.")
				Return
			End If

			Dim m As Match = Regex.Match(address, simpleAddrPattern)

			Dim houseNum As String = m.Groups("num").Value
			Dim streetName As String = m.Groups("street").Value

			' strip extra spaces
			streetName = Regex.Replace(streetName, "\s+", " ")

			Dim addrExpr As String = "LIKE(STREET,""" & streetName & """) "

			' search within street numbers range
			If houseNum.Length > 0 Then
				addrExpr = addrExpr & "AND ((FRADDL < TOADDL AND (FRADDL <= " & houseNum & " AND " & houseNum & "<= TOADDL)) OR "
				addrExpr = addrExpr & "(FRADDL > TOADDL AND (FRADDL >= " & houseNum & " AND " & houseNum & " >= TOADDL)) OR "
				addrExpr = addrExpr & "(FRADDR < TOADDR AND (FRADDR <= " & houseNum & " AND " & houseNum & " <= TOADDR)) OR "
				addrExpr = addrExpr & "(FRADDR > TOADDR AND (FRADDR >= " & houseNum & " AND " & houseNum & " >= TOADDR)))"
			End If

			Dim records As ActualMap.Recordset = map1("streets").SearchExpression(addrExpr)

			If (Not records.EOF) Then
				map1.Extent = records.RecordExtent
				map1.Refresh()
			Else
				MessageBox.Show("Address not found.")
			End If
		End Sub

		Private Sub btnParcel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnParcel.Click
			Dim expr As String = "PARNUM = """ & txtParcel.Text.Trim() & """"

			Dim rs As ActualMap.Recordset = map1("parcels").SearchExpression(expr)

			If rs.EOF Then
				MessageBox.Show("Parcel number not found.")
				Return
			End If

			map1.Callouts.Clear()

			dataGrid.DataSource = rs
			dataGrid.CaptionText = rs.Layer.Name.ToUpper()

			Dim callout As Callout = map1.Callouts.Add()
			Dim center As ActualMap.Point = rs.Shape.Centroid
			callout.X = center.X
			callout.Y = center.Y
			callout.Text = rs("PARNUM") + Constants.vbLf + rs("OWNERNAME")
			callout.Font.Size = 16

			map1.Extent = rs.RecordExtent

			map1.Refresh()
		End Sub

		Private Sub btnOwner_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnOwner.Click
			Dim expr As String = "LIKE(OWNERNAME,""" & txtOwner.Text.Trim() & "*"")"

			Dim rs As ActualMap.Recordset = map1("parcels").SearchExpression(expr)

			If rs.EOF Then
				MessageBox.Show("Owner not found.")
				Return
			End If

			map1.Callouts.Clear()

			dataGrid.DataSource = rs
			dataGrid.CaptionText = rs.Layer.Name.ToUpper()

			Dim callout As Callout = map1.Callouts.Add()
			Dim center As ActualMap.Point = rs.Shape.Centroid
			callout.X = center.X
			callout.Y = center.Y
			callout.Text = rs("PARNUM") + Constants.vbLf + rs("OWNERNAME")
			callout.Font.Size = 16

			Dim extent As ActualMap.Rectangle = rs.RecordExtent
			extent.Inflate(extent.Width * 0.8, extent.Height * 0.8)
			map1.Extent = extent

			map1.Refresh()
		End Sub
	End Class
End Namespace