Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports ActualMap
Imports ActualMap.Windows

Namespace SampleApps
	Partial Public Class ProjectedWorldMap
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub

		Private Class ListItem
			Public name As String
            Public code As ActualMap.CoordSystemCode
            Public Sub New(ByVal name As String, ByVal code As ActualMap.CoordSystemCode)
                Me.name = name
                Me.code = code
            End Sub
			Public Overrides Function ToString() As String
				Return name
			End Function
		End Class

		Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
			AddMapLayers()

            coordSystemList.Items.Add(New ListItem("World Robinson", ActualMap.CoordSystemCode.PCS_WorldRobinson))
            coordSystemList.Items.Add(New ListItem("Plate Carree", ActualMap.CoordSystemCode.PCS_WorldPlateCarree))
            coordSystemList.Items.Add(New ListItem("World Equidistant Cylindrical", ActualMap.CoordSystemCode.PCS_WorldEquidistantCylindrical))
            coordSystemList.Items.Add(New ListItem("WorldMiller Cylindrical", ActualMap.CoordSystemCode.PCS_WorldMillerCylindrical))
            coordSystemList.Items.Add(New ListItem("World Mercator", ActualMap.CoordSystemCode.PCS_WorldMercator))
            coordSystemList.Items.Add(New ListItem("World Sinusoidal", ActualMap.CoordSystemCode.PCS_WorldSinusoidal))
            coordSystemList.Items.Add(New ListItem("World Mollweide", ActualMap.CoordSystemCode.PCS_WorldMollweide))
            coordSystemList.Items.Add(New ListItem("World Eckert I", ActualMap.CoordSystemCode.PCS_WorldEckertI))
            coordSystemList.Items.Add(New ListItem("World Eckert II", ActualMap.CoordSystemCode.PCS_WorldEckertII))
            coordSystemList.Items.Add(New ListItem("World Eckert III", ActualMap.CoordSystemCode.PCS_WorldEckertIII))
            coordSystemList.Items.Add(New ListItem("World Eckert IV", ActualMap.CoordSystemCode.PCS_WorldEckertIV))
            coordSystemList.Items.Add(New ListItem("World Eckert V", ActualMap.CoordSystemCode.PCS_WorldEckertV))
            coordSystemList.Items.Add(New ListItem("World Eckert VI", ActualMap.CoordSystemCode.PCS_WorldEckertVI))
            coordSystemList.Items.Add(New ListItem("World Gall Stereographic", ActualMap.CoordSystemCode.PCS_WorldGallStereographic))
            coordSystemList.Items.Add(New ListItem("World Winkel I", ActualMap.CoordSystemCode.PCS_WorldWinkelI))
            coordSystemList.Items.Add(New ListItem("World Winkel II", ActualMap.CoordSystemCode.PCS_WorldWinkelII))
            coordSystemList.Items.Add(New ListItem("World Polyconic", ActualMap.CoordSystemCode.PCS_WorldPolyconic))
            coordSystemList.Items.Add(New ListItem("World Quartic Authalic", ActualMap.CoordSystemCode.PCS_WorldQuarticAuthalic))
            coordSystemList.Items.Add(New ListItem("World Loximuthal", ActualMap.CoordSystemCode.PCS_WorldLoximuthal))
            coordSystemList.Items.Add(New ListItem("World Bonne", ActualMap.CoordSystemCode.PCS_WorldBonne))
            coordSystemList.Items.Add(New ListItem("World Vander Grinten I", ActualMap.CoordSystemCode.PCS_WorldVanderGrintenI))
            coordSystemList.Items.Add(New ListItem("World Two Point Equidistant", ActualMap.CoordSystemCode.PCS_WorldTwoPointEquidistant))

			coordSystemList.SelectedIndex = 0
		End Sub

		Private Sub AddMapLayers()
			Dim layer As Layer

			Dim LayerFolder As String = Application.StartupPath & "\..\..\MAPS\WORLD\"

			' world
			layer = map1.AddLayer(LayerFolder & "world.shp")
			layer.CoordinateSystem = CoordSystem.WGS1984

			layer.ShowLabels = True
			layer.LabelField = "NAME"
			layer.LabelFont.Name = "Verdana"
			layer.LabelFont.Size = 12
            layer.LabelStyle = ActualMap.LabelStyle.PolygonCenter
			layer.Opacity = 0.6

			' lakes
			layer = map1.AddLayer(LayerFolder & "lakes.shp")
			layer.CoordinateSystem = CoordSystem.WGS1984

			layer.ShowLabels = True
			layer.LabelField = "NAME"
			layer.LabelFont.Size = 10
			layer.LabelFont.Outline = True
			layer.Symbol.FillColor = Color.Blue
			layer.Symbol.LineColor = layer.Symbol.FillColor
            layer.LabelStyle = ActualMap.LabelStyle.PolygonCenter

			' capitals
			layer = map1.AddLayer(LayerFolder & "capitals.shp")
			layer.CoordinateSystem = CoordSystem.WGS1984

			layer.ShowLabels = True
			layer.LabelField = "NAME"
			layer.LabelFont.Bold = True
			layer.LabelFont.Size = 11
			layer.LabelFont.Outline = True
            layer.Symbol.PointStyle = ActualMap.PointStyle.CircleWithLargeCenter
			layer.Symbol.Size = 8
			layer.Symbol.FillColor = Color.White
		End Sub

		Private Sub coordSystemList_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles coordSystemList.SelectedIndexChanged
			Dim item As ListItem = CType(coordSystemList.SelectedItem, ListItem)
			map1.CoordinateSystem = New ActualMap.CoordSystem(item.code)
			map1.Refresh()
		End Sub

	End Class
End Namespace