Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports ActualMap
Imports ActualMap.Data
Imports ActualMap.Windows

Namespace SampleApps
    Partial Public Class LocationEditor
        Inherits Form
        Private locationID As String = Nothing

        Public Sub New()
            InitializeComponent()
        End Sub

        Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
            AddMapLayers()
            AddLocationsDatabase()
        End Sub

        Private Sub map1_PanToolClick(ByVal sender As Object, ByVal e As PanToolClickEventArgs) Handles map1.PanToolClick
            RestoreState()

            Dim rs As Recordset = map1("locations").SearchNearest(e.Point, map1.ToMapDistance(8))

            If rs.EOF Then
                ' add new location
                map1.EditShape(e.Point)
            Else
                ' edit the location
                locationTitle.Text = rs("TITLE").ToString()
                locationID = rs("ID").ToString()
                remove.Visible = True
                operation.Text = "Edit location:"

                map1.EditShape(rs.Shape)
            End If

            map1.Refresh()
            locationPanel.Visible = True
        End Sub

        Private Sub save_Click(ByVal sender As Object, ByVal e As EventArgs) Handles save.Click
            If (Not map1.IsEdit) Then
                Return
            End If

            If locationID IsNot Nothing Then
                ' update location
                UpdateLocation(locationID, locationTitle.Text, map1.GetEditedShape())
            Else
                ' add new location
                AddNewLocation(locationTitle.Text, map1.GetEditedShape())
            End If

            RestoreState()
            map1.Refresh()
        End Sub

        Private Sub remove_Click(ByVal sender As Object, ByVal e As EventArgs) Handles remove.Click
            If locationID IsNot Nothing Then
                RemoveLocation(locationID)
                RestoreState()
                map1.Refresh()
            End If
        End Sub

        Private Sub AddNewLocation(ByVal title As String, ByVal shape As Shape)
            Dim layer As Layer = map1("locations")

            Dim rs As Recordset = layer.NewRecord()

            If (Not rs.EOF) Then
                rs("TITLE") = title
                rs.Shape = shape
                rs.Update()
            End If
        End Sub

        Private Sub cancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cancel.Click
            RestoreState()
            map1.Refresh()
        End Sub

        Private Sub UpdateLocation(ByVal id As String, ByVal title As String, ByVal shape As Shape)
            Dim layer As Layer = map1("locations")
            layer.EnablePassthroughQuery = True

            Dim rs As Recordset = layer.SearchExpression("ID = " & id & "")

            If (Not rs.EOF) Then
                rs("TITLE") = title
                rs.Shape = shape
                rs.Update()
            End If
        End Sub

        Private Sub RemoveLocation(ByVal id As String)
            Dim layer As Layer = map1("locations")
            layer.EnablePassthroughQuery = True

            Dim rs As Recordset = layer.SearchExpression("ID = " & id & "")

            If (Not rs.EOF) Then
                rs.Delete()
            End If
        End Sub

        Private Sub AddLocationsDatabase()
            Dim connectionString As String = "PROVIDER=Microsoft.Jet.OLEDB.4.0;DATA Source=" & Application.StartupPath & "\..\..\DATA\locations.mdb"

            Dim pointData As PointDataLayer = New PointDataLayer("System.Data.OleDb", connectionString, "locations", "LONGITUDE", "LATITUDE")

            Dim dbLayer As Layer = map1.AddLayer(pointData)

            If dbLayer Is Nothing Then
                MessageBox.Show("Cannot add locations.mdb database.")
                Return
            End If

            dbLayer.Name = "locations"
            dbLayer.Symbol.FillColor = Color.LightGreen
            dbLayer.Symbol.LineColor = Color.Gray
            dbLayer.Symbol.Size = 11
            dbLayer.ShowLabels = True
            dbLayer.LabelField = "TITLE"
            dbLayer.LabelFont.Name = "Verdana"
            dbLayer.LabelFont.Size = 14
            dbLayer.LabelFont.Color = Color.White
            dbLayer.LabelFont.OutlineColor = Color.Black
            dbLayer.LabelFont.Outline = True
        End Sub

        Protected Sub RestoreState()
            map1.CancelEdit()
            locationPanel.Visible = False
            locationID = Nothing
            remove.Visible = False
            operation.Text = "Add location:"
        End Sub

        Private Sub AddMapLayers()
            Dim LayerFolder As String = Application.StartupPath & "\..\..\MAPS\WORLD\"

            Dim layer As Layer = map1.AddLayer(LayerFolder & "world.shp")
            layer.Symbol.LineColor = Color.Gray
        End Sub

        Private Sub toolStripButton1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles toolStripButton1.Click
            map1.ZoomFull()
            map1.Refresh()
        End Sub

    End Class
End Namespace