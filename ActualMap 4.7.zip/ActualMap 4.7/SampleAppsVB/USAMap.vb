Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports ActualMap
Imports ActualMap.Windows

Namespace SampleApps
	Partial Public Class USAMap
		Inherits Form
		Private Const CITY As Double = 1000000 ' MapScale = 1000000
		Private Const COUNTY As Double = 2500000 ' MapScale = 2500000
		Private Const STATE As Double = 7400000 ' MapScale = 7400000
		Private Const SUBREGION As Double = 15000000 ' MapScale = 15000000
		Private Const REGION As Double = 30000000 ' MapScale = 30000000
		Private Const COUNTRY As Double = 75000000 ' full extent

		Public Sub New()
			InitializeComponent()
		End Sub

		Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
			AddMapLayers()

			' fill the states combobox
			Dim layer As Layer = map1.FindLayer("states")
			If layer IsNot Nothing Then
				Dim records As Recordset = layer.Recordset
				Do While Not records.EOF
					statesList.Items.Add(records("STATE_NAME"))
					records.MoveNext()
				Loop
			End If
		End Sub

		Private Sub AddMapLayers()
			Dim layer As Layer
			Dim feature As Feature
			Dim renderer As FeatureRenderer

			Dim LayerFolder As String = Application.StartupPath & "\..\..\MAPS\USA\"
			Dim SymbolFolder As String = Application.StartupPath & "\..\..\SYMBOLS\"

			'- STATES -------------------------------------------
			layer = map1.AddLayer(LayerFolder & "states.shp")

			layer.LabelField = "STATE_ABBR"
			layer.ShowLabels = True
			layer.LabelFont.Name = "Verdana"
			layer.LabelFont.Size = 12
			layer.LabelFont.Bold = True
            layer.LabelStyle = ActualMap.LabelStyle.PolygonCenter

			'- ROADS -------------------------------------------
			layer = map1.AddLayer(LayerFolder & "roads.shp")

			' default symbol
			layer.LabelField = "NUMBER"
			layer.ShowLabels = True
			layer.DuplicateLabels = False
			layer.LabelFont.Size = 12
			layer.Symbol.LineColor = Color.FromArgb(255, 0, 0)
			layer.Symbol.Size = 1

			renderer = layer.Renderer
			renderer.Field = "CLASS"

			' Interstate
			feature = renderer.Add()
			feature.MinScale = SUBREGION
            feature.LabelStyle = ActualMap.LabelStyle.Shield
			feature.Value = "Interstate"
            feature.ShieldSymbol.PointStyle = ActualMap.PointStyle.Bitmap
			feature.ShieldSymbol.Bitmap = SymbolFolder & "interstate_highway.bmp"
			feature.ShieldSymbol.Size = 20
			feature.ShieldSymbol.TransparentColor = Color.FromArgb(255, 255, 255)
            feature.Symbol.LineStyle = ActualMap.LineStyle.Solid
			feature.Symbol.Size = 1
			feature.Symbol.LineColor = Color.FromArgb(205, 120, 45)
			feature.LabelFont.Color = Color.FromArgb(255, 255, 255)

			feature = feature.Clone()
			feature.MinScale = COUNTY
            feature.Symbol.LineStyle = ActualMap.LineStyle.Road
			feature.Symbol.Size = 3
			feature.Symbol.LineColor = Color.FromArgb(205, 120, 45)
			feature.Symbol.InnerColor = Color.FromArgb(249, 208, 137)
			renderer.Add(feature)

			feature = feature.Clone()
			feature.MinScale = -1
            feature.Symbol.LineStyle = ActualMap.LineStyle.DualRoad
			feature.Symbol.Size = 5
			renderer.Add(feature)

			' US Highway
			feature = renderer.Add()
			feature.MinScale = SUBREGION
            feature.LabelStyle = ActualMap.LabelStyle.Shield
			feature.Value = "US Highway"
            feature.ShieldSymbol.PointStyle = ActualMap.PointStyle.Bitmap
			feature.ShieldSymbol.Bitmap = SymbolFolder & "us_highway.bmp"
			feature.ShieldSymbol.Size = 20
			feature.ShieldSymbol.TransparentColor = Color.White
            feature.Symbol.LineStyle = ActualMap.LineStyle.Solid
			feature.Symbol.Size = 1
			feature.Symbol.LineColor = Color.FromArgb(205, 120, 45)

			feature = feature.Clone()
			feature.MinScale = COUNTY
            feature.Symbol.LineStyle = ActualMap.LineStyle.Road
			feature.Symbol.Size = 3
			feature.Symbol.LineColor = Color.FromArgb(205, 120, 45)
			feature.Symbol.InnerColor = Color.FromArgb(254, 244, 131)
			renderer.Add(feature)

			feature = feature.Clone()
			feature.MinScale = -1
            feature.Symbol.LineStyle = ActualMap.LineStyle.DualRoad
			feature.Symbol.Size = 5
			renderer.Add(feature)

			' State Highway
			feature = renderer.Add()
			feature.MinScale = SUBREGION
            feature.LabelStyle = ActualMap.LabelStyle.Shield
			feature.Value = "State Highway"
            feature.ShieldSymbol.PointStyle = ActualMap.PointStyle.Bitmap
			feature.ShieldSymbol.Bitmap = SymbolFolder & "state_highway.bmp"
			feature.ShieldSymbol.Size = 20
			feature.ShieldSymbol.TransparentColor = Color.White
            feature.Symbol.LineStyle = ActualMap.LineStyle.Solid
			feature.Symbol.Size = 1
			feature.Symbol.LineColor = Color.FromArgb(205, 120, 45)

			feature = feature.Clone()
			feature.MinScale = COUNTY
            feature.Symbol.LineStyle = ActualMap.LineStyle.Road
			feature.Symbol.Size = 3
			feature.Symbol.LineColor = Color.FromArgb(205, 120, 45)
			feature.Symbol.InnerColor = Color.FromArgb(255, 255, 204)
			renderer.Add(feature)

			feature = feature.Clone()
			feature.MinScale = -1
            feature.Symbol.LineStyle = ActualMap.LineStyle.Road
			feature.Symbol.Size = 5
			renderer.Add(feature)

			'- CITIES --------------------------------------------
			layer = map1.AddLayer(LayerFolder & "cities.shp")

			layer.LabelField = "CITY_NAME"
			layer.ShowLabels = True
			layer.UseDefaultSymbol = False

			renderer = layer.Renderer

			feature = renderer.Add()
			feature.Expression = "CAPITAL = ""Y"""
            feature.Symbol.PointStyle = ActualMap.PointStyle.CircleWithLargeCenter
			feature.Symbol.Size = 10
			feature.Symbol.FillColor = Color.FromArgb(255, 255, 0)
			feature.LabelFont.Name = "Arial"
			feature.LabelFont.Bold = True
			feature.LabelFont.Size = 14
			feature.LabelFont.Outline = True
			feature.LabelFont.OutlineColor = Color.FromArgb(255, 255, 0)

			feature = renderer.Add()
			feature.MaxScale = SUBREGION
			feature.Expression = "POP > 500000"
            feature.Symbol.PointStyle = ActualMap.PointStyle.SquareWithLargeCenter
			feature.Symbol.Size = 10
			feature.Symbol.FillColor = Color.FromArgb(255, 255, 255)
			feature.LabelFont.Name = "Arial"
			feature.LabelFont.Bold = True
			feature.LabelFont.Size = 13
			feature.LabelFont.Outline = True

			feature = renderer.Add()
			feature.MaxScale = SUBREGION
			feature.Expression = "POP > 250000"
            feature.Symbol.PointStyle = ActualMap.PointStyle.CircleWithSmallCenter
			feature.Symbol.Size = 10
			feature.Symbol.FillColor = Color.FromArgb(255, 255, 255)
			feature.LabelFont.Name = "Arial"
			feature.LabelFont.Bold = True
			feature.LabelFont.Size = 13
			feature.LabelFont.Outline = True

			feature = renderer.Add()
			feature.MaxScale = SUBREGION
			feature.Expression = "POP > 150000"
            feature.Symbol.PointStyle = ActualMap.PointStyle.SquareWithSmallCenter
			feature.Symbol.Size = 8
			feature.Symbol.FillColor = Color.FromArgb(255, 255, 255)
			feature.LabelFont.Size = 12

			feature = renderer.Add()
			feature.MaxScale = COUNTY
			feature.Expression = "POP > 50000"
            feature.Symbol.PointStyle = ActualMap.PointStyle.Square
			feature.Symbol.Size = 6
			feature.Symbol.FillColor = Color.FromArgb(255, 255, 255)
			feature.LabelFont.Size = 12

			feature = renderer.Add()
			feature.MaxScale = CITY
			feature.Expression = "POP <= 50000"
            feature.Symbol.PointStyle = ActualMap.PointStyle.Circle
			feature.Symbol.Size = 6
			feature.Symbol.FillColor = Color.FromArgb(255, 255, 255)
			feature.LabelFont.Size = 12
		End Sub

		Private Sub toolBar_ButtonClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles toolBar.ButtonClick
			If e.Button.Style = ToolBarButtonStyle.ToggleButton Then
				For Each b As ToolBarButton In toolBar.Buttons
				b.Pushed = False
				Next b
				e.Button.Pushed = True
			End If

			map1.Cursor = Cursors.Default

			If e.Button Is zoomFull Then
				map1.ZoomFull()
				map1.Refresh()
			End If
			If e.Button Is clearShapes Then
				map1.MapShapes.Clear()
				map1.Callouts.Clear()
				dataGrid.DataSource = Nothing
				dataGrid.CaptionText = String.Empty
				map1.Refresh()
			ElseIf e.Button Is zoomInTool Then
			map1.MapTool = MapTool.ZoomIn
			ElseIf e.Button Is zoomOutTool Then
			map1.MapTool = MapTool.ZoomOut
			ElseIf e.Button Is panTool Then
				map1.MapTool = MapTool.Pan
				map1.Cursor = Cursors.SizeAll
			ElseIf e.Button Is centerTool Then
			map1.MapTool = MapTool.Center
			ElseIf e.Button Is distanceTool Then
			map1.MapTool = MapTool.Distance
			ElseIf e.Button Is infoTool Then
			map1.MapTool = MapTool.Info
			End If
		End Sub

		Private Sub map1_InfoTool(ByVal sender As Object, ByVal e As ActualMap.Windows.InfoToolEventArgs) Handles map1.InfoTool
			map1.Callouts.Clear()

			Dim records As ActualMap.Recordset = map1.Identify(e.InfoPoint, 5)

			If (Not records.EOF) Then
				dataGrid.DataSource = records
				dataGrid.CaptionText = records.Layer.Name

				Dim callout As Callout = map1.Callouts.Add()
				callout.X = e.InfoPoint.X
				callout.Y = e.InfoPoint.Y
				callout.Text = GetCalloutText(records)
				callout.Font.Size = 16

				map1.Refresh()
			End If
		End Sub

		Private Sub menuItem2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles menuItem2.Click
			printPreview.ShowDialog()
		End Sub

		Private Sub printDocument_PrintPage(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles printDocument.PrintPage
			Dim mapImage As Bitmap = map1.GetBitmap(700, 600)
			e.Graphics.DrawImageUnscaled(mapImage, 50, 50)
		End Sub

		Private Function GetCalloutText(ByVal rs As ActualMap.Recordset) As String
			Dim index As Integer = rs.Fields.GetFieldIndex("NAME")
			If index < 0 Then
			index = rs.Fields.GetFieldIndex(rs.Layer.LabelField)
			End If
			If index < 0 Then
			index = 0
			End If
			Return rs(index).ToString()
		End Function

		Private Sub map1_DistanceToolMove(ByVal sender As Object, ByVal e As DistanceToolEventArgs) Handles map1.DistanceToolMove
			Dim distanceInMapUnits As Double = e.Distance
            Dim distanceInMiles As Double = Math.Round(map1.ConvertDistance(distanceInMapUnits, map1.MapUnit, ActualMap.MeasureUnit.Mile), 3)
            Dim distanceInKilometers As Double = Math.Round(map1.ConvertDistance(distanceInMapUnits, map1.MapUnit, ActualMap.MeasureUnit.Kilometer), 3)

			statusBar1.Text = distanceInMiles.ToString() & " mi  |  " & distanceInKilometers.ToString() & " km"
		End Sub

		Private Sub map1_DistanceToolFinished(ByVal sender As Object, ByVal e As DistanceToolEventArgs) Handles map1.DistanceToolFinished
			statusBar1.Text = String.Empty
		End Sub

		Private Sub statesList_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles statesList.SelectedIndexChanged
			Dim state As Recordset
			state = map1("states").SearchExpression("STATE_NAME = """ & statesList.SelectedItem & """")
			If (Not state.EOF) Then
				map1.Extent = state.RecordExtent

				' select the state shape with a red outline
				map1.MapShapes.Clear()
				Dim shape As MapShape = map1.MapShapes.Add(state.Shape)
				Dim s As Symbol = New Symbol()
                s.FillStyle = ActualMap.FillStyle.Invisible
				s.LineColor = Color.Red
				s.Size = 3
				shape.Symbol = s

				map1.Refresh()
			End If
		End Sub
	End Class
End Namespace