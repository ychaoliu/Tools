Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports ActualMap
Imports ActualMap.Windows

Namespace SampleApps
	Partial Public Class WorldMap
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub

		Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
			AddMapLayers()
		End Sub

		Private Sub AddMapLayers()
			Dim layer As Layer

			Dim LayerFolder As String = Application.StartupPath & "\..\..\MAPS\WORLD\"

			map1.AddLayer(LayerFolder & "earth.ecw")

			' world
			layer = map1.AddLayer(LayerFolder & "world.shp")
			layer.ShowLabels = True
			layer.LabelField = "NAME"
			layer.LabelFont.Name = "Verdana"
			layer.LabelFont.Size = 12
            layer.LabelStyle = ActualMap.LabelStyle.PolygonCenter
			layer.Opacity = 0.6

			' lakes
			layer = map1.AddLayer(LayerFolder & "lakes.shp")
			layer.ShowLabels = True
			layer.LabelField = "NAME"
			layer.LabelFont.Size = 10
			layer.LabelFont.Outline = True
			layer.Symbol.FillColor = Color.Blue
			layer.Symbol.LineColor = layer.Symbol.FillColor
            layer.LabelStyle = ActualMap.LabelStyle.PolygonCenter

			' capitals
			layer = map1.AddLayer(LayerFolder & "capitals.shp")
			layer.ShowLabels = True
			layer.LabelField = "NAME"
			layer.LabelFont.Bold = True
			layer.LabelFont.Size = 11
			layer.LabelFont.Outline = True
            layer.Symbol.PointStyle = ActualMap.PointStyle.CircleWithLargeCenter
			layer.Symbol.Size = 8
			layer.Symbol.FillColor = Color.White
		End Sub

		Private Sub toolBar_ButtonClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles toolBar.ButtonClick
			If e.Button.Style = ToolBarButtonStyle.ToggleButton Then
				For Each b As ToolBarButton In toolBar.Buttons
				b.Pushed = False
				Next b
				e.Button.Pushed = True
			End If

			If e.Button Is zoomFull Then
				map1.ZoomFull()
				map1.Refresh()
			End If
			If e.Button Is clearShapes Then
				map1.MapShapes.Clear()
				map1.Callouts.Clear()
				dataGrid.DataSource = Nothing
				dataGrid.CaptionText = String.Empty
				map1.Refresh()
			ElseIf e.Button Is zoomInTool Then
			map1.MapTool = MapTool.ZoomIn
			ElseIf e.Button Is zoomOutTool Then
			map1.MapTool = MapTool.ZoomOut
			ElseIf e.Button Is panTool Then
			map1.MapTool = MapTool.Pan
			ElseIf e.Button Is centerTool Then
			map1.MapTool = MapTool.Center
			ElseIf e.Button Is distanceTool Then
			map1.MapTool = MapTool.Distance
			ElseIf e.Button Is infoTool Then
			map1.MapTool = MapTool.Info
			End If
		End Sub

		Private Sub map1_InfoTool(ByVal sender As Object, ByVal e As ActualMap.Windows.InfoToolEventArgs) Handles map1.InfoTool
			map1.Callouts.Clear()

			Dim records As ActualMap.Recordset = map1.Identify(e.InfoPoint, 5)

			If (Not records.EOF) Then
				dataGrid.DataSource = records
				dataGrid.CaptionText = records.Layer.Name

				Dim callout As Callout = map1.Callouts.Add()
				callout.X = e.InfoPoint.X
				callout.Y = e.InfoPoint.Y
				callout.Text = GetCalloutText(records)
				callout.Font.Size = 16

				map1.Refresh()
			End If
		End Sub

		Private Sub menuItem2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles menuItem2.Click
			printPreview.ShowDialog()
		End Sub

		Private Sub printDocument_PrintPage(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles printDocument.PrintPage
			Dim mapImage As Bitmap = map1.GetBitmap(700, 600)
			e.Graphics.DrawImageUnscaled(mapImage, 50, 50)
		End Sub

		Private Function GetCalloutText(ByVal rs As ActualMap.Recordset) As String
			Dim index As Integer = rs.Fields.GetFieldIndex("NAME")
			If index < 0 Then
			index = rs.Fields.GetFieldIndex(rs.Layer.LabelField)
			End If
			If index < 0 Then
			index = 0
			End If
			Return rs(index).ToString()
		End Function

		Private Sub map1_DistanceToolMove(ByVal sender As Object, ByVal e As DistanceToolEventArgs) Handles map1.DistanceToolMove
			Dim distanceInMapUnits As Double = e.Distance
            Dim distanceInMiles As Double = Math.Round(map1.ConvertDistance(distanceInMapUnits, map1.MapUnit, ActualMap.MeasureUnit.Mile), 3)
            Dim distanceInKilometers As Double = Math.Round(map1.ConvertDistance(distanceInMapUnits, map1.MapUnit, ActualMap.MeasureUnit.Kilometer), 3)

			statusBar1.Text = distanceInMiles.ToString() & " mi  |  " & distanceInKilometers.ToString() & " km"
		End Sub

		Private Sub map1_DistanceToolFinished(ByVal sender As Object, ByVal e As DistanceToolEventArgs) Handles map1.DistanceToolFinished
			statusBar1.Text = String.Empty
		End Sub
	End Class
End Namespace