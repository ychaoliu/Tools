Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports ActualMap
Imports ActualMap.Windows

Namespace SampleApps
    Partial Public Class WMSLayerApp
        Inherits Form

        Public Sub New()
            InitializeComponent()
        End Sub

        Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
            AddShapefileLayer()
            AddWmsLayer()
        End Sub

        ' add the WMS layer ( http://nationalatlas.gov/infodocs/wms_intro.html )
        Private Sub AddWmsLayer()
            Dim wms As WmsLayer = New WmsLayer("http://webservices.nationalatlas.gov/wms", New ActualMap.Rectangle(-168.99, 70.2545, -55, 17.6895))
            wms.AddLayer("roads")
            wms.Transparent = True
            wms.ImageFormat = ImageFormat.Png

            map1.AddLayer(wms)
        End Sub

        ' search for features in the WMS layer
        Private Sub map1_InfoTool(ByVal sender As Object, ByVal e As ActualMap.Windows.InfoToolEventArgs) Handles map1.InfoTool
            Cursor = Cursors.WaitCursor
            map1.Callouts.Clear()

            Try
                Dim info As String = map1.GetWmsFeatureInfo("http://webservices.nationalatlas.gov/wms", "roads", e.InfoPoint, 1, "text/plain")

                If info IsNot Nothing Then
                    Dim callout As Callout = map1.Callouts.Add()
                    callout.X = e.InfoPoint.X
                    callout.Y = e.InfoPoint.Y
                    callout.Text = info
                    callout.Font.Size = 14

                    map1.Refresh()
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            Finally
                Cursor = Cursors.Default
            End Try
        End Sub

        Private Sub AddShapefileLayer()
            Dim layer As Layer

            Dim LayerFolder As String = Application.StartupPath & "\..\..\MAPS\USA\"

            layer = map1.AddLayer(LayerFolder & "states.shp")

            layer.Symbol.Size = 1
            layer.Symbol.LineColor = Color.FromArgb(199, 172, 116)
            layer.Symbol.FillColor = Color.FromArgb(242, 236, 223)
        End Sub

        Private Sub toolBar_ButtonClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles toolBar.ButtonClick
            If e.Button.Style = ToolBarButtonStyle.ToggleButton Then
                For Each b As ToolBarButton In toolBar.Buttons
                    b.Pushed = False
                Next b
                e.Button.Pushed = True
            End If

            map1.Cursor = Cursors.Default

            If e.Button Is zoomFull Then
                map1.ZoomFull()
                map1.Refresh()
            ElseIf e.Button Is zoomInTool Then
                map1.MapTool = MapTool.ZoomIn
            ElseIf e.Button Is zoomOutTool Then
                map1.MapTool = MapTool.ZoomOut
            ElseIf e.Button Is panTool Then
                map1.MapTool = MapTool.Pan
                map1.Cursor = Cursors.SizeAll
            ElseIf e.Button Is infoTool Then
                map1.MapTool = MapTool.Info
            ElseIf e.Button Is clearShapes Then
                map1.Callouts.Clear()
                map1.Refresh()
            End If
        End Sub

        Private Sub menuItem2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles menuItem2.Click
            printPreview.ShowDialog()
        End Sub

        Private Sub printDocument_PrintPage(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles printDocument.PrintPage
            Dim mapImage As Bitmap = map1.GetBitmap(700, 600)
            e.Graphics.DrawImageUnscaled(mapImage, 50, 50)
        End Sub

        Private Function GetCalloutText(ByVal rs As ActualMap.Recordset) As String
            Dim index As Integer = rs.Fields.GetFieldIndex("NAME")
            If index < 0 Then
                index = rs.Fields.GetFieldIndex(rs.Layer.LabelField)
            End If
            If index < 0 Then
                index = 0
            End If
            Return rs(index).ToString()
        End Function

        Private Sub map1_BeforeMapDraw(ByVal sender As Object, ByVal e As MapDrawEventArgs) Handles map1.BeforeMapDraw
            Cursor = Cursors.WaitCursor
        End Sub

        Private Sub map1_AfterMapDraw(ByVal sender As Object, ByVal e As MapDrawEventArgs) Handles map1.AfterMapDraw
            Cursor = Cursors.Default
        End Sub
    End Class
End Namespace