Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports ActualMap
Imports ActualMap.Windows

Namespace SampleApps
	Partial Public Class CommonCoordSystem
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub

		Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
			AddMapLayers()
            map1.CoordinateSystem = New ActualMap.CoordSystem(ActualMap.CoordSystemCode.PCS_WorldWinkelI)
			map1.ZoomFull()
		End Sub

		Private Sub AddMapLayers()
			Dim layer As Layer

			Dim LayerFolder As String = Application.StartupPath & "\..\..\MAPS\PROJECTED\"

			' world
			layer = map1.AddLayer(LayerFolder & "world.shp")
			layer.ShowLabels = True
			layer.LabelField = "NAME"
			layer.LabelFont.Name = "Verdana"
			layer.LabelFont.Size = 12
            layer.LabelStyle = ActualMap.LabelStyle.PolygonCenter
			layer.Opacity = 0.6

			' lakes
			layer = map1.AddLayer(LayerFolder & "lakes.shp")
			layer.ShowLabels = True
			layer.LabelField = "NAME"
			layer.LabelFont.Size = 10
			layer.LabelFont.Outline = True
			layer.Symbol.FillColor = Color.Blue
			layer.Symbol.LineColor = layer.Symbol.FillColor
            layer.LabelStyle = ActualMap.LabelStyle.PolygonCenter

			' capitals
			layer = map1.AddLayer(LayerFolder & "capitals.shp")
			layer.ShowLabels = True
			layer.LabelField = "NAME"
			layer.LabelFont.Bold = True
			layer.LabelFont.Size = 11
			layer.LabelFont.Outline = True
            layer.Symbol.PointStyle = ActualMap.PointStyle.CircleWithLargeCenter
			layer.Symbol.Size = 8
			layer.Symbol.FillColor = Color.White
		End Sub

		Private Sub toolBar_ButtonClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles toolBar.ButtonClick
			If e.Button.Style = ToolBarButtonStyle.ToggleButton Then
				For Each b As ToolBarButton In toolBar.Buttons
				b.Pushed = False
				Next b
				e.Button.Pushed = True
			End If

			If e.Button Is zoomFull Then
				map1.ZoomFull()
				map1.Refresh()
			ElseIf e.Button Is zoomInTool Then
			map1.MapTool = MapTool.ZoomIn
			ElseIf e.Button Is zoomOutTool Then
			map1.MapTool = MapTool.ZoomOut
			ElseIf e.Button Is panTool Then
			map1.MapTool = MapTool.Pan
			End If
		End Sub
	End Class
End Namespace