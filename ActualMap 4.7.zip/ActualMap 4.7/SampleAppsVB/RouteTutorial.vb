Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.IO
Imports System.Windows.Forms
Imports ActualMap
Imports ActualMap.Windows

Namespace SampleApps
	Partial Public Class RouteTutorial
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub

		Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Dim RouteFiles As String = Application.StartupPath & "\..\..\MAPS\ROUTING\"

			' create a Network Object
			Dim roadNetwork As ActualMap.Network = New ActualMap.Network()

			' load the road network
			roadNetwork.Open(RouteFiles & "streets.shp", RouteFiles & "streets.rtn")

			' create a Route Object
			Dim route As ActualMap.Route
			route = roadNetwork.CreateRoute()

			' start/end coordinates
			Dim StartX, StartY, EndX, EndY As Double
			StartX = -71.5591 ' start longitude
			StartY = 43.1851 ' start latitude
			EndX = -71.5227 ' end longitude
			EndY = 43.2542 ' end latitude

            ' set the route optimization: quickest or shortest
            route.RouteType = RouteType.Quickest

            ' set the current date for turn restrictions
            route.CurrentDate = DateTime.Now

			' find the route
			If (Not route.FindRoute(StartX, StartY, EndX, EndY)) Then
				MessageBox.Show("Route not found.")
				Return
			End If

			' merge the road segments to streets
			route.MergeSegments("NAME;TYPE")

			' add the route to the map as a layer
			Dim routeLayer As ActualMap.Layer = map1.AddLayer(route)
			routeLayer.Symbol.LineColor = Color.FromArgb(198, 86, 245)
			routeLayer.Symbol.Size = 6

			' add the streets.shp layer to the map
			Dim streetLayer As ActualMap.Layer = map1.AddLayer(RouteFiles & "streets.shp")
			streetLayer.ShowLabels = True
			streetLayer.LabelField = "NAME"

			' set the extent of the route as the current extent of the map
			map1.Extent = route.Extent

			' add driving directions to listView1
			GenerateDirections(route)
		End Sub

		Private Sub GenerateDirections(ByVal route As ActualMap.Route)
			Dim streets As Streets = route.Streets
			If streets.Count = 0 Then
			Return
			End If

			Dim units As String

            If route.DistanceUnit = ActualMap.MeasureUnit.Mile Then
                units = "miles"
            Else
                units = "kilometers"
            End If

			Dim direction, distance As String

			listView1.Columns.Add("Directions", 350)
			listView1.Columns.Add("Distance (" & units & ")", 90)

			direction = "Start out going " & streets(0).Direction.ToString() & " on " & streets(0).Name

			If streets.Count > 1 Then
				direction &= " towards " & streets(1).Name
			End If

			distance = Convert.ToString(Math.Round(streets(0).Distance, 2))

			listView1.Items.Add(New ListViewItem(New String() { direction, distance }))

			For i As Integer = 1 To streets.Count - 1
				Dim street As Street = streets(i)

				direction = i & ". "

				If street.TurnAngle > 30 Then
					direction &= "Turn LEFT onto " & street.Name
				ElseIf street.TurnAngle < -30 Then
					direction &= "Turn RIGHT onto " & street.Name
				Else
					direction &= "Road name changes to " & street.Name
				End If

				direction &= " (" & street.Direction.ToString() & ")"

				distance = Convert.ToString(Math.Round(street.Distance, 2))

				listView1.Items.Add(New ListViewItem(New String() { direction, distance }))
			Next i

			direction = "Arrive " & streets(streets.Count - 1).Name

			listView1.Items.Add(New ListViewItem(New String() { direction, "" }))

			direction = "Total Estimated Time: " & Convert.ToString(Math.Round(route.RouteTime / 60.0, 1)) & " minutes"

			listView1.Items.Add(New ListViewItem(New String() { direction, "" }))

			direction = "Total Distance: " & Convert.ToString(Math.Round(route.RouteDistance, 2)) & " " & units

			listView1.Items.Add(New ListViewItem(New String() { direction, "" }))
		End Sub

		Private Sub toolBar_ButtonClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles toolBar.ButtonClick
			If e.Button.Style = ToolBarButtonStyle.ToggleButton Then
				For Each b As ToolBarButton In toolBar.Buttons
				b.Pushed = False
				Next b
				e.Button.Pushed = True
			End If

			If e.Button Is zoomFull Then
				map1.ZoomFull()
				map1.Refresh()
			ElseIf e.Button Is zoomInTool Then
			map1.MapTool = MapTool.ZoomIn
			ElseIf e.Button Is zoomOutTool Then
			map1.MapTool = MapTool.ZoomOut
			ElseIf e.Button Is panTool Then
			map1.MapTool = MapTool.Pan
			End If
		End Sub
	End Class
End Namespace