Imports Microsoft.VisualBasic
Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports ActualMap
Imports ActualMap.Windows

Namespace SampleApps
    Partial Public Class WMSLayerApp
        ''' <summary>
        ''' Required designer variable.
        ''' </summary>
        Private components As System.ComponentModel.IContainer = Nothing

        ''' <summary>
        ''' Clean up any resources being used.
        ''' </summary>
        ''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing AndAlso (components IsNot Nothing) Then
                components.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub

#Region "Windows Form Designer generated code"

        ''' <summary>
        ''' Required method for Designer support - do not modify
        ''' the contents of this method with the code editor.
        ''' </summary>
        Private Sub InitializeComponent()
            Me.components = New System.ComponentModel.Container()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(WMSLayerApp))
            Me.toolBar = New System.Windows.Forms.ToolBar()
            Me.sep = New System.Windows.Forms.ToolBarButton()
            Me.zoomFull = New System.Windows.Forms.ToolBarButton()
            Me.zoomInTool = New System.Windows.Forms.ToolBarButton()
            Me.zoomOutTool = New System.Windows.Forms.ToolBarButton()
            Me.panTool = New System.Windows.Forms.ToolBarButton()
            Me.toolBarButton1 = New System.Windows.Forms.ToolBarButton()
            Me.infoTool = New System.Windows.Forms.ToolBarButton()
            Me.clearShapes = New System.Windows.Forms.ToolBarButton()
            Me.toolImages = New System.Windows.Forms.ImageList(Me.components)
            Me.statusBar1 = New System.Windows.Forms.StatusBar()
            Me.panel1 = New System.Windows.Forms.Panel()
            Me.panel2 = New System.Windows.Forms.Panel()
            Me.textBox1 = New System.Windows.Forms.TextBox()
            Me.splitter1 = New System.Windows.Forms.Splitter()
            Me.splitter3 = New System.Windows.Forms.Splitter()
            Me.printPreview = New System.Windows.Forms.PrintPreviewDialog()
            Me.printDocument = New System.Drawing.Printing.PrintDocument()
            Me.mainMenu1 = New System.Windows.Forms.MainMenu(Me.components)
            Me.menuItem1 = New System.Windows.Forms.MenuItem()
            Me.menuItem2 = New System.Windows.Forms.MenuItem()
            Me.map1 = New ActualMap.Windows.Map()
            Me.panel1.SuspendLayout()
            Me.panel2.SuspendLayout()
            Me.SuspendLayout()
            ' 
            ' toolBar
            ' 
            Me.toolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
            Me.toolBar.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.sep, Me.zoomFull, Me.zoomInTool, Me.zoomOutTool, Me.panTool, Me.toolBarButton1, Me.infoTool, Me.clearShapes})
            Me.toolBar.ButtonSize = New System.Drawing.Size(23, 21)
            Me.toolBar.DropDownArrows = True
            Me.toolBar.ImageList = Me.toolImages
            Me.toolBar.Location = New System.Drawing.Point(0, 0)
            Me.toolBar.Name = "toolBar"
            Me.toolBar.ShowToolTips = True
            Me.toolBar.Size = New System.Drawing.Size(1019, 32)
            Me.toolBar.TabIndex = 1
            '			Me.toolBar.ButtonClick += New System.Windows.Forms.ToolBarButtonClickEventHandler(Me.toolBar_ButtonClick);
            ' 
            ' sep
            ' 
            Me.sep.Name = "sep"
            Me.sep.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
            ' 
            ' zoomFull
            ' 
            Me.zoomFull.ImageIndex = 10
            Me.zoomFull.Name = "zoomFull"
            Me.zoomFull.ToolTipText = "Zoom Full"
            ' 
            ' zoomInTool
            ' 
            Me.zoomInTool.ImageIndex = 11
            Me.zoomInTool.Name = "zoomInTool"
            Me.zoomInTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
            Me.zoomInTool.Tag = ""
            Me.zoomInTool.ToolTipText = "Zoom In"
            ' 
            ' zoomOutTool
            ' 
            Me.zoomOutTool.ImageIndex = 12
            Me.zoomOutTool.Name = "zoomOutTool"
            Me.zoomOutTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
            Me.zoomOutTool.ToolTipText = "Zoom Out"
            ' 
            ' panTool
            ' 
            Me.panTool.ImageIndex = 5
            Me.panTool.Name = "panTool"
            Me.panTool.Pushed = True
            Me.panTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
            Me.panTool.ToolTipText = "Pan"
            ' 
            ' toolBarButton1
            ' 
            Me.toolBarButton1.Name = "toolBarButton1"
            Me.toolBarButton1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
            ' 
            ' infoTool
            ' 
            Me.infoTool.ImageIndex = 3
            Me.infoTool.Name = "infoTool"
            Me.infoTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
            Me.infoTool.ToolTipText = "Identify"
            ' 
            ' clearShapes
            ' 
            Me.clearShapes.ImageIndex = 13
            Me.clearShapes.Name = "clearShapes"
            Me.clearShapes.ToolTipText = "Clear callouts"
            ' 
            ' toolImages
            ' 
            Me.toolImages.ImageStream = (CType(resources.GetObject("toolImages.ImageStream"), System.Windows.Forms.ImageListStreamer))
            Me.toolImages.TransparentColor = System.Drawing.Color.Transparent
            Me.toolImages.Images.SetKeyName(0, "")
            Me.toolImages.Images.SetKeyName(1, "")
            Me.toolImages.Images.SetKeyName(2, "")
            Me.toolImages.Images.SetKeyName(3, "")
            Me.toolImages.Images.SetKeyName(4, "")
            Me.toolImages.Images.SetKeyName(5, "")
            Me.toolImages.Images.SetKeyName(6, "")
            Me.toolImages.Images.SetKeyName(7, "")
            Me.toolImages.Images.SetKeyName(8, "")
            Me.toolImages.Images.SetKeyName(9, "")
            Me.toolImages.Images.SetKeyName(10, "")
            Me.toolImages.Images.SetKeyName(11, "")
            Me.toolImages.Images.SetKeyName(12, "")
            Me.toolImages.Images.SetKeyName(13, "clear.gif")
            ' 
            ' statusBar1
            ' 
            Me.statusBar1.Location = New System.Drawing.Point(0, 468)
            Me.statusBar1.Name = "statusBar1"
            Me.statusBar1.Size = New System.Drawing.Size(1019, 26)
            Me.statusBar1.TabIndex = 10
            ' 
            ' panel1
            ' 
            Me.panel1.Controls.Add(Me.panel2)
            Me.panel1.Dock = System.Windows.Forms.DockStyle.Right
            Me.panel1.Location = New System.Drawing.Point(817, 32)
            Me.panel1.Name = "panel1"
            Me.panel1.Size = New System.Drawing.Size(202, 436)
            Me.panel1.TabIndex = 11
            ' 
            ' panel2
            ' 
            Me.panel2.Controls.Add(Me.textBox1)
            Me.panel2.Dock = System.Windows.Forms.DockStyle.Fill
            Me.panel2.Location = New System.Drawing.Point(0, 0)
            Me.panel2.Name = "panel2"
            Me.panel2.Size = New System.Drawing.Size(202, 436)
            Me.panel2.TabIndex = 2
            ' 
            ' textBox1
            ' 
            Me.textBox1.BackColor = System.Drawing.SystemColors.Info
            Me.textBox1.Dock = System.Windows.Forms.DockStyle.Fill
            Me.textBox1.Location = New System.Drawing.Point(0, 0)
            Me.textBox1.Multiline = True
            Me.textBox1.Name = "textBox1"
            Me.textBox1.ReadOnly = True
            Me.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both
            Me.textBox1.Size = New System.Drawing.Size(202, 436)
            Me.textBox1.TabIndex = 20
            Me.textBox1.TabStop = False
            Me.textBox1.Text = "Demonstrates the WmsLayer class by plotting the 'roads' layer from the National A" & "tlas Web Map Service over the local shapefile layer."
            ' 
            ' splitter1
            ' 
            Me.splitter1.Dock = System.Windows.Forms.DockStyle.Right
            Me.splitter1.Location = New System.Drawing.Point(814, 32)
            Me.splitter1.Name = "splitter1"
            Me.splitter1.Size = New System.Drawing.Size(3, 436)
            Me.splitter1.TabIndex = 12
            Me.splitter1.TabStop = False
            ' 
            ' splitter3
            ' 
            Me.splitter3.Dock = System.Windows.Forms.DockStyle.Bottom
            Me.splitter3.Location = New System.Drawing.Point(0, 465)
            Me.splitter3.Name = "splitter3"
            Me.splitter3.Size = New System.Drawing.Size(814, 3)
            Me.splitter3.TabIndex = 14
            Me.splitter3.TabStop = False
            ' 
            ' printPreview
            ' 
            Me.printPreview.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.printPreview.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.printPreview.ClientSize = New System.Drawing.Size(400, 300)
            Me.printPreview.Document = Me.printDocument
            Me.printPreview.Enabled = True
            Me.printPreview.Icon = (CType(resources.GetObject("printPreview.Icon"), System.Drawing.Icon))
            Me.printPreview.Name = "printPreview"
            Me.printPreview.Visible = False
            ' 
            ' printDocument
            ' 
            '			Me.printDocument.PrintPage += New System.Drawing.Printing.PrintPageEventHandler(Me.printDocument_PrintPage);
            ' 
            ' mainMenu1
            ' 
            Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1})
            ' 
            ' menuItem1
            ' 
            Me.menuItem1.Index = 0
            Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem2})
            Me.menuItem1.Text = "File"
            ' 
            ' menuItem2
            ' 
            Me.menuItem2.Index = 0
            Me.menuItem2.Text = "Print Map..."
            '			Me.menuItem2.Click += New System.EventHandler(Me.menuItem2_Click);
            ' 
            ' map1
            ' 
            Me.map1.BackColor = System.Drawing.Color.White
            Me.map1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
            Me.map1.Cursor = System.Windows.Forms.Cursors.SizeAll
            Me.map1.Dock = System.Windows.Forms.DockStyle.Fill
            Me.map1.FontQuality = ActualMap.FontQuality.ClearType
            Me.map1.Location = New System.Drawing.Point(0, 32)
            Me.map1.MapTool = ActualMap.Windows.MapTool.Pan
            Me.map1.Name = "map1"
            Me.map1.PixelPerInch = 96
            Me.map1.ScaleBar.BarUnit = ActualMap.UnitSystem.Imperial
            Me.map1.ScaleBar.FeetString = "ft"
            Me.map1.ScaleBar.Font.Alignment = ActualMap.TextAlign.Left
            Me.map1.ScaleBar.Font.Bold = False
            Me.map1.ScaleBar.Font.Charset = 1
            Me.map1.ScaleBar.Font.Color = System.Drawing.Color.FromArgb((CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))))
            Me.map1.ScaleBar.Font.Italic = False
            Me.map1.ScaleBar.Font.Name = "Arial"
            Me.map1.ScaleBar.Font.Outline = False
            Me.map1.ScaleBar.Font.OutlineColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
            Me.map1.ScaleBar.Font.Quality = ActualMap.FontQuality.Default
            Me.map1.ScaleBar.Font.Size = 12
            Me.map1.ScaleBar.Font.StrikeThrough = False
            Me.map1.ScaleBar.Font.Underline = False
            Me.map1.ScaleBar.KilometersString = "km"
            Me.map1.ScaleBar.MaxWidth = 0
            Me.map1.ScaleBar.MetersString = "m"
            Me.map1.ScaleBar.MilesString = "mi"
            Me.map1.ScaleBar.Position = ActualMap.ScaleBarPosition.BottomRight
            Me.map1.ScaleBar.Symbol.Bitmap = ""
            Me.map1.ScaleBar.Symbol.FillColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
            Me.map1.ScaleBar.Symbol.FillStyle = ActualMap.FillStyle.Solid
            Me.map1.ScaleBar.Symbol.InnerColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
            Me.map1.ScaleBar.Symbol.LineColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))))
            Me.map1.ScaleBar.Symbol.LineStyle = ActualMap.LineStyle.Solid
            Me.map1.ScaleBar.Symbol.PointStyle = ActualMap.PointStyle.Circle
            Me.map1.ScaleBar.Symbol.Rotation = 0
            Me.map1.ScaleBar.Symbol.Size = 1
            Me.map1.ScaleBar.Symbol.TransparentColor = System.Drawing.Color.Empty
            Me.map1.ScaleBar.Visible = True
            Me.map1.Size = New System.Drawing.Size(814, 433)
            Me.map1.SmoothingMode = ActualMap.SmoothingMode.AntiAlias
            Me.map1.TabIndex = 15
            Me.map1.ToolShape.FillColor = System.Drawing.Color.Silver
            Me.map1.ToolShape.LineColor = System.Drawing.Color.Red
            Me.map1.ToolShape.Opacity = 0.5
            Me.map1.ToolShape.VertexColor = System.Drawing.Color.Red
            Me.map1.ToolShape.VirtualVertexColor = System.Drawing.Color.Green
            '			Me.map1.AfterMapDraw += New ActualMap.Windows.MapDrawEventHandler(Me.map1_AfterMapDraw);
            '			Me.map1.BeforeMapDraw += New ActualMap.Windows.MapDrawEventHandler(Me.map1_BeforeMapDraw);
            '			Me.map1.InfoTool += New ActualMap.Windows.InfoToolEventHandler(Me.map1_InfoTool);
            ' 
            ' WMSLayer
            ' 
            Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
            Me.BackColor = System.Drawing.SystemColors.Control
            Me.ClientSize = New System.Drawing.Size(1019, 494)
            Me.Controls.Add(Me.map1)
            Me.Controls.Add(Me.splitter3)
            Me.Controls.Add(Me.splitter1)
            Me.Controls.Add(Me.panel1)
            Me.Controls.Add(Me.statusBar1)
            Me.Controls.Add(Me.toolBar)
            Me.Menu = Me.mainMenu1
            Me.Name = "WMSLayer"
            Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
            Me.Text = "WMS Layer"
            '			Me.Load += New System.EventHandler(Me.Form1_Load);
            Me.panel1.ResumeLayout(False)
            Me.panel2.ResumeLayout(False)
            Me.panel2.PerformLayout()
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

#End Region

        Private zoomFull As System.Windows.Forms.ToolBarButton
        Private sep As System.Windows.Forms.ToolBarButton
        Private toolImages As System.Windows.Forms.ImageList
        Private zoomInTool As System.Windows.Forms.ToolBarButton
        Private zoomOutTool As System.Windows.Forms.ToolBarButton
        Private panTool As System.Windows.Forms.ToolBarButton
        Private WithEvents toolBar As System.Windows.Forms.ToolBar
        Private infoTool As System.Windows.Forms.ToolBarButton
        Private statusBar1 As System.Windows.Forms.StatusBar
        Private panel1 As System.Windows.Forms.Panel
        Private splitter1 As System.Windows.Forms.Splitter
        Private panel2 As System.Windows.Forms.Panel
        Private splitter3 As System.Windows.Forms.Splitter
        Private WithEvents map1 As ActualMap.Windows.Map
        Private printPreview As System.Windows.Forms.PrintPreviewDialog
        Private mainMenu1 As System.Windows.Forms.MainMenu
        Private menuItem1 As System.Windows.Forms.MenuItem
        Private WithEvents menuItem2 As System.Windows.Forms.MenuItem
        Private WithEvents printDocument As System.Drawing.Printing.PrintDocument
        Private textBox1 As TextBox
        Private toolBarButton1 As ToolBarButton
        Private clearShapes As ToolBarButton

    End Class
End Namespace