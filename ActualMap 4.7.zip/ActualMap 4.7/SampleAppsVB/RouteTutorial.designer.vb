Imports Microsoft.VisualBasic
Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports ActualMap
Imports ActualMap.Windows

Namespace SampleApps
	Partial Public Class RouteTutorial
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(ByVal disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.components = New System.ComponentModel.Container()
			Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(RouteTutorial))
			Me.toolBar = New System.Windows.Forms.ToolBar()
			Me.sep = New System.Windows.Forms.ToolBarButton()
			Me.zoomFull = New System.Windows.Forms.ToolBarButton()
			Me.zoomInTool = New System.Windows.Forms.ToolBarButton()
			Me.zoomOutTool = New System.Windows.Forms.ToolBarButton()
			Me.panTool = New System.Windows.Forms.ToolBarButton()
			Me.toolImages = New System.Windows.Forms.ImageList(Me.components)
			Me.listView1 = New System.Windows.Forms.ListView()
			Me.splitter1 = New System.Windows.Forms.Splitter()
			Me.map1 = New ActualMap.Windows.Map()
			Me.SuspendLayout()
			' 
			' toolBar
			' 
			Me.toolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
			Me.toolBar.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() { Me.sep, Me.zoomFull, Me.zoomInTool, Me.zoomOutTool, Me.panTool})
			Me.toolBar.ButtonSize = New System.Drawing.Size(23, 21)
			Me.toolBar.DropDownArrows = True
			Me.toolBar.ImageList = Me.toolImages
			Me.toolBar.Location = New System.Drawing.Point(0, 0)
			Me.toolBar.Name = "toolBar"
			Me.toolBar.ShowToolTips = True
			Me.toolBar.Size = New System.Drawing.Size(879, 32)
			Me.toolBar.TabIndex = 1
'			Me.toolBar.ButtonClick += New System.Windows.Forms.ToolBarButtonClickEventHandler(Me.toolBar_ButtonClick);
			' 
			' sep
			' 
			Me.sep.Name = "sep"
			Me.sep.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
			' 
			' zoomFull
			' 
			Me.zoomFull.ImageIndex = 10
			Me.zoomFull.Name = "zoomFull"
			Me.zoomFull.ToolTipText = "Zoom Full"
			' 
			' zoomInTool
			' 
			Me.zoomInTool.ImageIndex = 11
			Me.zoomInTool.Name = "zoomInTool"
			Me.zoomInTool.Pushed = True
			Me.zoomInTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
			Me.zoomInTool.Tag = ""
			Me.zoomInTool.ToolTipText = "Zoom In"
			' 
			' zoomOutTool
			' 
			Me.zoomOutTool.ImageIndex = 12
			Me.zoomOutTool.Name = "zoomOutTool"
			Me.zoomOutTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
			Me.zoomOutTool.ToolTipText = "Zoom Out"
			' 
			' panTool
			' 
			Me.panTool.ImageIndex = 5
			Me.panTool.Name = "panTool"
			Me.panTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
			Me.panTool.ToolTipText = "Pan"
			' 
			' toolImages
			' 
			Me.toolImages.ImageStream = (CType(resources.GetObject("toolImages.ImageStream"), System.Windows.Forms.ImageListStreamer))
			Me.toolImages.TransparentColor = System.Drawing.Color.Transparent
			Me.toolImages.Images.SetKeyName(0, "")
			Me.toolImages.Images.SetKeyName(1, "")
			Me.toolImages.Images.SetKeyName(2, "")
			Me.toolImages.Images.SetKeyName(3, "")
			Me.toolImages.Images.SetKeyName(4, "")
			Me.toolImages.Images.SetKeyName(5, "")
			Me.toolImages.Images.SetKeyName(6, "")
			Me.toolImages.Images.SetKeyName(7, "")
			Me.toolImages.Images.SetKeyName(8, "")
			Me.toolImages.Images.SetKeyName(9, "")
			Me.toolImages.Images.SetKeyName(10, "")
			Me.toolImages.Images.SetKeyName(11, "")
			Me.toolImages.Images.SetKeyName(12, "")
			Me.toolImages.Images.SetKeyName(13, "clear.gif")
			' 
			' listView1
			' 
			Me.listView1.Dock = System.Windows.Forms.DockStyle.Bottom
			Me.listView1.FullRowSelect = True
			Me.listView1.Location = New System.Drawing.Point(0, 388)
			Me.listView1.MultiSelect = False
			Me.listView1.Name = "listView1"
			Me.listView1.Size = New System.Drawing.Size(879, 111)
			Me.listView1.TabIndex = 16
			Me.listView1.UseCompatibleStateImageBehavior = False
			Me.listView1.View = System.Windows.Forms.View.Details
			' 
			' splitter1
			' 
			Me.splitter1.Dock = System.Windows.Forms.DockStyle.Bottom
			Me.splitter1.Location = New System.Drawing.Point(0, 385)
			Me.splitter1.Name = "splitter1"
			Me.splitter1.Size = New System.Drawing.Size(879, 3)
			Me.splitter1.TabIndex = 17
			Me.splitter1.TabStop = False
			' 
			' map1
			' 
			Me.map1.BackColor = System.Drawing.Color.White
			Me.map1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
			Me.map1.Dock = System.Windows.Forms.DockStyle.Fill
			Me.map1.FontQuality = ActualMap.FontQuality.ClearType
			Me.map1.Location = New System.Drawing.Point(0, 32)
			Me.map1.MapTool = ActualMap.Windows.MapTool.ZoomIn
			Me.map1.MapUnit = ActualMap.MeasureUnit.Degree
			Me.map1.Name = "map1"
			Me.map1.PixelPerInch = 96
			Me.map1.ScaleBar.BarUnit = ActualMap.UnitSystem.Imperial
			Me.map1.ScaleBar.FeetString = "ft"
			Me.map1.ScaleBar.Font.Alignment = ActualMap.TextAlign.Left
			Me.map1.ScaleBar.Font.Bold = False
			Me.map1.ScaleBar.Font.Charset = 1
			Me.map1.ScaleBar.Font.Color = System.Drawing.Color.FromArgb((CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))))
			Me.map1.ScaleBar.Font.Italic = False
			Me.map1.ScaleBar.Font.Name = "Arial"
			Me.map1.ScaleBar.Font.Outline = False
			Me.map1.ScaleBar.Font.OutlineColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
			Me.map1.ScaleBar.Font.Size = 12
			Me.map1.ScaleBar.Font.StrikeThrough = False
			Me.map1.ScaleBar.Font.Underline = False
			Me.map1.ScaleBar.KilometersString = "km"
			Me.map1.ScaleBar.MaxWidth = 0
			Me.map1.ScaleBar.MetersString = "m"
			Me.map1.ScaleBar.MilesString = "mi"
			Me.map1.ScaleBar.Position = ActualMap.ScaleBarPosition.BottomRight
			Me.map1.ScaleBar.Symbol.Bitmap = ""
			Me.map1.ScaleBar.Symbol.FillColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
			Me.map1.ScaleBar.Symbol.FillStyle = ActualMap.FillStyle.Solid
			Me.map1.ScaleBar.Symbol.InnerColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
			Me.map1.ScaleBar.Symbol.LineColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))))
			Me.map1.ScaleBar.Symbol.LineStyle = ActualMap.LineStyle.Solid
			Me.map1.ScaleBar.Symbol.PointStyle = ActualMap.PointStyle.Circle
			Me.map1.ScaleBar.Symbol.Size = 1
			Me.map1.ScaleBar.Symbol.TransparentColor = System.Drawing.Color.Empty
			Me.map1.ScaleBar.Visible = True
			Me.map1.Size = New System.Drawing.Size(879, 353)
			Me.map1.SmoothingMode = ActualMap.SmoothingMode.AntiAlias
			Me.map1.TabIndex = 18
			Me.map1.ToolShape.FillColor = System.Drawing.Color.Transparent
			Me.map1.ToolShape.LineColor = System.Drawing.Color.Red
			' 
			' RouteTutorial
			' 
			Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
			Me.BackColor = System.Drawing.SystemColors.Control
			Me.ClientSize = New System.Drawing.Size(879, 499)
			Me.Controls.Add(Me.map1)
			Me.Controls.Add(Me.splitter1)
			Me.Controls.Add(Me.listView1)
			Me.Controls.Add(Me.toolBar)
			Me.Name = "RouteTutorial"
			Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
			Me.Text = "Route Tutorial"
'			Me.Load += New System.EventHandler(Me.Form1_Load);
			Me.ResumeLayout(False)
			Me.PerformLayout()

		End Sub

		#End Region

		Private zoomFull As System.Windows.Forms.ToolBarButton
		Private sep As System.Windows.Forms.ToolBarButton
		Private toolImages As System.Windows.Forms.ImageList
		Private zoomInTool As System.Windows.Forms.ToolBarButton
		Private zoomOutTool As System.Windows.Forms.ToolBarButton
		Private panTool As System.Windows.Forms.ToolBarButton
		Private WithEvents toolBar As System.Windows.Forms.ToolBar
		Private listView1 As ListView
		Private splitter1 As Splitter
		Private map1 As Map

	End Class
End Namespace