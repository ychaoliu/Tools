Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports ActualMap
Imports ActualMap.Windows
Imports ActualMap.Web

Namespace SampleApps
	Partial Public Class WMSBrowser
		Inherits Form
        Private wmsCaps As WmsCapabilities

		Public Sub New()
			InitializeComponent()
		End Sub

		Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
			url.Text = "http://webservices.nationalatlas.gov/wms/boundaries" ' see also http://nationalatlas.gov/infodocs/wms_intro.html
		End Sub

		Private Sub Form1_Shown(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Shown
			ReloadWmsLayer()
		End Sub

		Private Sub ReloadWmsLayer()
			map1.RemoveAllLayers()
			map1.Callouts.Clear()
			Cursor = Cursors.WaitCursor

			If wmsCaps Is Nothing Then
				Clear()

				Try
					wmsCaps = New WmsCapabilities(url.Text.Trim())

					If wmsCaps.Layers.Count = 0 Then
						Throw New Exception("Layers not found")
					End If

					wmsLayers.DataSource = wmsCaps.Layers
					wmsLayers.DisplayMember = "Name"

					wmsTitle.Text = wmsCaps.ServiceTitle

					UpdateLayerInfo()
				Catch ex As Exception
					map1.Refresh()
					MessageBox.Show(ex.Message, "Error")
					Return
				End Try
			End If

            Dim wms As WMSLayer = New WMSLayer(wmsCaps.MapUrl)

			If layerStyles.Items.Count = 0 Then
                wms.AddLayer(wmsCaps.Layers(wmsLayers.SelectedIndex).Name, wmsCaps.Layers(wmsLayers.SelectedIndex).GeoExtent)
			Else
                wms.AddLayer(wmsCaps.Layers(wmsLayers.SelectedIndex).Name, wmsCaps.Layers(wmsLayers.SelectedIndex).GeoExtent, wmsCaps.Layers(wmsLayers.SelectedIndex).Styles(layerStyles.SelectedIndex).Name)
			End If

            wms.Transparent = True
            wms.ImageFormat = ImageFormat.Png

            map1.AddLayer(wms)

			map1.ZoomFull()
			map1.Refresh()

			Cursor = Cursors.Default
		End Sub

		Private Sub wmsLayers_SelectionChangeCommitted(ByVal sender As Object, ByVal e As EventArgs) Handles wmsLayers.SelectionChangeCommitted
			If wmsCaps Is Nothing Then
			Return
			End If

			ReloadWmsLayer()
		End Sub

		Private Sub layerStyles_SelectionChangeCommitted(ByVal sender As Object, ByVal e As EventArgs) Handles layerStyles.SelectionChangeCommitted
			If wmsCaps Is Nothing Then
			Return
			End If

			ReloadWmsLayer()
		End Sub

		Private Sub map1_BeforeMapDraw(ByVal sender As Object, ByVal e As MapDrawEventArgs) Handles map1.BeforeMapDraw
			Cursor = Cursors.WaitCursor
		End Sub

		Private Sub map1_AfterMapDraw(ByVal sender As Object, ByVal e As MapDrawEventArgs) Handles map1.AfterMapDraw
			Cursor = Cursors.Default
		End Sub

		Private Sub url_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs) Handles url.KeyPress
            If e.KeyChar = Microsoft.VisualBasic.ChrW(Keys.Return) Then
                e.Handled = True

                If String.IsNullOrEmpty(url.Text.Trim()) Then
                    Return
                End If

                wmsCaps = Nothing

                ReloadWmsLayer()
            End If
		End Sub

		Private Sub UpdateLayerInfo()
			Dim info As WmsLayerInfo = wmsCaps.Layers(wmsLayers.SelectedIndex)

			layerName.Text = info.Name
			layerTitle.Text = info.Title
			layerAbstract.Text = info.Abstract

			layerStyles.DataSource = info.Styles
			layerStyles.DisplayMember = "name"
		End Sub

		' search for features in the WMS layer
		Private Sub map1_InfoTool(ByVal sender As Object, ByVal e As ActualMap.Windows.InfoToolEventArgs) Handles map1.InfoTool
			If wmsCaps Is Nothing Then
			Return
			End If

			Cursor = Cursors.WaitCursor
			map1.Callouts.Clear()

			Try
				Dim info As String = map1.GetWmsFeatureInfo(wmsCaps.MapUrl, wmsCaps.Layers(wmsLayers.SelectedIndex).Name, e.InfoPoint, 1, "text/plain")

				If info IsNot Nothing Then
					Dim callout As Callout = map1.Callouts.Add()
					callout.X = e.InfoPoint.X
					callout.Y = e.InfoPoint.Y
					callout.Text = info
					callout.Font.Size = 14

					map1.Refresh()
				End If
			Catch ex As Exception
				MessageBox.Show(ex.Message)
			End Try

			Cursor = Cursors.Default
		End Sub

		Private Sub Clear()
			wmsTitle.Text = String.Empty
			layerName.Text = String.Empty
			layerTitle.Text = String.Empty
			layerAbstract.Text = String.Empty
			wmsLayers.DataSource = Nothing
			layerStyles.DataSource = Nothing
		End Sub

		Private Sub toolBar_ButtonClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles toolBar.ButtonClick
			If e.Button.Style = ToolBarButtonStyle.ToggleButton Then
				For Each b As ToolBarButton In toolBar.Buttons
				b.Pushed = False
				Next b
				e.Button.Pushed = True
			End If

			map1.Cursor = Cursors.Default

			If e.Button Is zoomFull Then
				map1.ZoomFull()
				map1.Refresh()
			ElseIf e.Button Is clearShapes Then
				map1.Callouts.Clear()
				map1.Refresh()
			ElseIf e.Button Is zoomInTool Then
			map1.MapTool = MapTool.ZoomIn
			ElseIf e.Button Is zoomOutTool Then
			map1.MapTool = MapTool.ZoomOut
			ElseIf e.Button Is panTool Then
				map1.MapTool = MapTool.Pan
				map1.Cursor = Cursors.SizeAll
			ElseIf e.Button Is infoTool Then
			map1.MapTool = MapTool.Info
			End If
		End Sub

		Private Sub menuItem2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles menuItem2.Click
			printPreview.ShowDialog()
		End Sub

		Private Sub printDocument_PrintPage(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles printDocument.PrintPage
			Dim mapImage As Bitmap = map1.GetBitmap(700, 600)
			e.Graphics.DrawImageUnscaled(mapImage, 50, 50)
		End Sub

		Private Function GetCalloutText(ByVal rs As ActualMap.Recordset) As String
			Dim index As Integer = rs.Fields.GetFieldIndex("NAME")
			If index < 0 Then
			index = rs.Fields.GetFieldIndex(rs.Layer.LabelField)
			End If
			If index < 0 Then
			index = 0
			End If
			Return rs(index).ToString()
		End Function

	End Class
End Namespace