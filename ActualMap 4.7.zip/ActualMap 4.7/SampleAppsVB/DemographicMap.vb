Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports ActualMap
Imports ActualMap.Windows

Namespace SampleApps
	Partial Public Class DemographicMap
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub

		Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
			AddMapLayers()

			Dim fields As ActualMap.Fields = map1("USA").Recordset.Fields
			For i As Integer = 4 To fields.Count - 1
				thematicFields.Items.Add(fields(i).Name)
			Next i

			thematicFields.SelectedIndex = 0

			DoThematicMapping()
		End Sub

		Private Sub DoThematicMapping()
			Dim Delta, Prev, Curr As Double

			map1("USA").Renderer.Clear()
			legend1.Clear()

			Dim field As String = thematicFields.SelectedItem.ToString()

			' calculate statistics
			Dim statistics As ActualMap.Statistics = map1("USA").Recordset.CalculateStatistics(field)

			' calculate ranges
			Dim colors() As Color = { Color.FromArgb(251, 234, 208), Color.FromArgb(248, 215, 165), Color.FromArgb(244, 197, 125), Color.FromArgb(240, 174, 74), Color.FromArgb(236, 130, 55), Color.FromArgb(230, 100, 40) }

			Delta = (statistics.Max - statistics.Min) / colors.Length
			Prev = statistics.Min

            legend1.Add("No data", ActualMap.LayerType.Polygon, map1("USA").Symbol)

			For index As Integer = 0 To colors.Length - 1
				Curr = Prev + Delta

				Dim feature As ActualMap.Feature = map1("USA").Renderer.Add()
				feature.Expression = field & "<=" & Convert.ToInt32(Curr)
				feature.Symbol.FillColor = colors(index)
				feature.Symbol.LineColor = Color.White

                legend1.Add(Convert.ToInt32(Prev) & " - " & Convert.ToInt32(Curr), ActualMap.LayerType.Polygon, feature.Symbol)

				Prev = Curr
			Next index

			map1.Refresh()
		End Sub

		Private Sub AddMapLayers()
			Dim dataSource As ActualMap.DataSource = New ActualMap.DataSource()
			Dim LayerFolder As String = Application.StartupPath & "\..\..\MAPS\USA\"

			Dim layer As ActualMap.Layer = map1.AddLayer(LayerFolder & "USA.shp")

			layer.Symbol.FillColor = Color.White ' no data
			layer.ShowLabels = True
			layer.LabelField = "STATE_ABBR"
            layer.LabelStyle = ActualMap.LabelStyle.PolygonCenter

			Dim dataFile As String = Application.StartupPath & "\..\..\DATA\demography.mdb"

			dataSource.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & dataFile
			dataSource.CommandText = "SELECT * FROM demography"

			' create a relation between the USA shapefile and the 
			' database by the state abbreviation field
			If (Not map1("USA").AddRelate("STATE_ABBR", dataSource, "STATE_ABBR")) Then
				MessageBox.Show("Cannot add a relate to the database: " & dataFile)
			End If
		End Sub

		Private Sub thematicFields_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles thematicFields.SelectedIndexChanged
			DoThematicMapping()
		End Sub
	End Class
End Namespace