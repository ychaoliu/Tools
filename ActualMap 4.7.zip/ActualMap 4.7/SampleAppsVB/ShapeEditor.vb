Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Data.OleDb
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports ActualMap
Imports ActualMap.Data
Imports ActualMap.Windows

Namespace SampleApps
    Partial Public Class ShapeEditor
        Inherits Form
        Private shapeID As String = Nothing

        Public Sub New()
            InitializeComponent()
        End Sub

        Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
            AddMapLayers()
            AddDatabase()

            map1.NewShapeType = ActualMap.ShapeType.Polygon

            RestoreState()
        End Sub

        Private Sub map1_InfoTool(ByVal sender As Object, ByVal e As InfoToolEventArgs) Handles map1.InfoTool
            RestoreState()

            Dim rs As Recordset = map1.Identify(e.InfoPoint, 10)

            If rs.EOF Then
                Return
            End If
            If rs.Layer.Name <> "polygons" Then
                Return
            End If

            ' edit the shape
            map1.EditShape(rs.Shape)

            shapeTitle.Text = rs("TITLE").ToString()
            shapeID = rs("ID").ToString()

            remove.Visible = True
            operation.Text = "Edit shape:"
            operation.ForeColor = Color.Blue
            CheckButton(editTool)
        End Sub

        Private Sub save_Click(ByVal sender As Object, ByVal e As EventArgs) Handles save.Click
            If (Not map1.IsEdit) Then
                Return
            End If

            If shapeID IsNot Nothing Then
                ' update shape
                UpdateShape(shapeID, shapeTitle.Text, map1.GetEditedShape())
            Else
                ' add new shape
                AddNewShape(shapeTitle.Text, map1.GetEditedShape())
            End If

            RestoreState()
            map1.Refresh()
        End Sub

        Private Sub remove_Click(ByVal sender As Object, ByVal e As EventArgs) Handles remove.Click
            If shapeID IsNot Nothing Then
                RemoveShape(shapeID)
                map1.Refresh()
                RestoreState()
            End If
        End Sub

        Private Sub cancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cancel.Click
            RestoreState()
        End Sub

        Private Sub AddNewShape(ByVal title As String, ByVal shape As ActualMap.Shape)
            Dim layer As Layer = map1("polygons")

            Dim rs As Recordset = layer.NewRecord()

            If (Not rs.EOF) Then
                rs("TITLE") = title
                rs.Shape = shape
                rs.Update()
            End If
        End Sub

        Private Sub UpdateShape(ByVal id As String, ByVal title As String, ByVal shape As Shape)
            Dim layer As Layer = map1("polygons")
            layer.EnablePassthroughQuery = True

            Dim rs As Recordset = layer.SearchExpression("ID = " & id & "")

            If (Not rs.EOF) Then
                rs("TITLE") = title
                rs.Shape = shape
                rs.Update()
            End If
        End Sub

        Private Sub RemoveShape(ByVal id As String)
            Dim layer As Layer = map1("polygons")
            layer.EnablePassthroughQuery = True

            Dim rs As Recordset = layer.SearchExpression("ID = " & id & "")

            If (Not rs.EOF) Then
                rs.Delete()
            End If
        End Sub

        Private Sub AddDatabase()
            Dim connectionString As String = "PROVIDER=Microsoft.Jet.OLEDB.4.0;DATA Source=" & Application.StartupPath & "\..\..\DATA\shapes.mdb"

            Dim wkbDataLayer As WkbDataLayer = New WkbDataLayer("System.Data.OleDb", connectionString, "polygons", "WKBDATA")
            wkbDataLayer.FieldList = "ID, TITLE"
            wkbDataLayer.ShapeType = ActualMap.ShapeType.Polygon

            Dim layer As Layer = map1.AddLayer(wkbDataLayer)

            If layer Is Nothing Then
                MessageBox.Show("Cannot add table.")
                Return
            End If

            layer.Name = "polygons"
            layer.Opacity = 0.4
            layer.ShowLabels = True
            layer.LabelStyle = ActualMap.LabelStyle.PolygonCenter
            layer.LabelField = "TITLE"
            layer.LabelFont.Name = "Verdana"
            layer.LabelFont.Size = 12
            layer.LabelFont.Color = Color.White
            layer.LabelFont.OutlineColor = Color.Black
            layer.LabelFont.Outline = True
            layer.Symbol.Size = 1
            layer.Symbol.FillColor = Color.LightGreen
            layer.Symbol.LineColor = Color.Green
        End Sub

        Private Sub AddMapLayers()
            Dim LayerFolder As String = Application.StartupPath & "\..\..\MAPS\WORLD\"

            Dim layer As Layer = map1.AddLayer(LayerFolder & "world.shp")
            layer.Symbol.LineColor = Color.Gray
        End Sub

        Private Sub infoTool_Click(ByVal sender As Object, ByVal e As EventArgs) Handles infoTool.Click
            CheckButton(sender)
            map1.MapTool = MapTool.Info
        End Sub

        Private Sub panTool_Click(ByVal sender As Object, ByVal e As EventArgs) Handles panTool.Click
            CheckButton(sender)
            map1.MapTool = MapTool.Pan
        End Sub

        Private Sub editTool_Click(ByVal sender As Object, ByVal e As EventArgs) Handles editTool.Click
            CheckButton(sender)
            map1.MapTool = MapTool.EditShape
        End Sub

        Private Sub drawTool_Click(ByVal sender As Object, ByVal e As EventArgs) Handles drawTool.Click
            CheckButton(sender)
            map1.MapTool = MapTool.DrawShape
        End Sub

        Protected Sub RestoreState()
            shapeID = Nothing
            remove.Visible = False
            operation.Text = "Add shape:"
            operation.ForeColor = Color.Red
            map1.MapTool = MapTool.Info
            map1.CancelEdit()
            CheckButton(infoTool)
        End Sub

        Private Sub CheckButton(ByVal sender As Object)
            infoTool.Checked = False
            panTool.Checked = False
            editTool.Checked = False
            drawTool.Checked = False
            CType(sender, ToolStripButton).Checked = True
        End Sub

        Private Sub toolStripButton1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles toolStripButton1.Click
            map1.ZoomFull()
            map1.Refresh()
        End Sub

        Private Sub toolStripButton2_Click(ByVal sender As Object, ByVal e As EventArgs) Handles toolStripButton2.Click
            map1.RemoveSelectedVertex()
        End Sub

        Private Sub toolStripButton3_Click(ByVal sender As Object, ByVal e As EventArgs) Handles toolStripButton3.Click
            map1.CancelEdit()
            RestoreState()
        End Sub
    End Class
End Namespace