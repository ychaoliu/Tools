Imports Microsoft.VisualBasic
Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports ActualMap
Imports ActualMap.Windows

Namespace SampleApps
	''' <summary>
	''' Summary description for Form1.
	''' </summary>
	Public Class MapTools
		Inherits System.Windows.Forms.Form
		Private zoomFull As System.Windows.Forms.ToolBarButton
		Private sep As System.Windows.Forms.ToolBarButton
		Private toolImages As System.Windows.Forms.ImageList
		Private zoomInTool As System.Windows.Forms.ToolBarButton
		Private zoomOutTool As System.Windows.Forms.ToolBarButton
		Private panTool As System.Windows.Forms.ToolBarButton
		Private centerTool As System.Windows.Forms.ToolBarButton
		Private distanceTool As System.Windows.Forms.ToolBarButton
		Private sep2 As System.Windows.Forms.ToolBarButton
		Private pointTool As System.Windows.Forms.ToolBarButton
		Private rectangleTool As System.Windows.Forms.ToolBarButton
		Private lineTool As System.Windows.Forms.ToolBarButton
		Private polylineTool As System.Windows.Forms.ToolBarButton
		Private circleTool As System.Windows.Forms.ToolBarButton
		Private polygonTool As System.Windows.Forms.ToolBarButton
		Private WithEvents toolBar As System.Windows.Forms.ToolBar
		Private infoTool As System.Windows.Forms.ToolBarButton
		Private statusBar1 As System.Windows.Forms.StatusBar
		Private panel1 As System.Windows.Forms.Panel
		Private splitter1 As System.Windows.Forms.Splitter
		Private panel2 As System.Windows.Forms.Panel
		Private splitter3 As System.Windows.Forms.Splitter
		Private WithEvents map1 As ActualMap.Windows.Map
		Private dataGrid As System.Windows.Forms.DataGrid
		Private printPreview As System.Windows.Forms.PrintPreviewDialog
		Private mainMenu1 As System.Windows.Forms.MainMenu
		Private menuItem1 As System.Windows.Forms.MenuItem
		Private WithEvents menuItem2 As System.Windows.Forms.MenuItem
		Private WithEvents printDocument As System.Drawing.Printing.PrintDocument
		Private layerList As ComboBox
		Private label1 As Label
		Private textBox1 As TextBox
		Private toolBarButton1 As ToolBarButton
		Private clearShapes As ToolBarButton
		Private distanceMi As Label
		Private label2 As Label
		Private distanceKm As Label
		Private components As System.ComponentModel.IContainer

		Public Sub New()
			InitializeComponent()
		End Sub

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		Protected Overrides Overloads Sub Dispose(ByVal disposing As Boolean)
			If disposing Then
				If components IsNot Nothing Then
					components.Dispose()
				End If
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"
		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.components = New System.ComponentModel.Container()
			Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MapTools))
			Me.toolBar = New System.Windows.Forms.ToolBar()
			Me.sep = New System.Windows.Forms.ToolBarButton()
			Me.zoomFull = New System.Windows.Forms.ToolBarButton()
			Me.zoomInTool = New System.Windows.Forms.ToolBarButton()
			Me.zoomOutTool = New System.Windows.Forms.ToolBarButton()
			Me.panTool = New System.Windows.Forms.ToolBarButton()
			Me.centerTool = New System.Windows.Forms.ToolBarButton()
			Me.distanceTool = New System.Windows.Forms.ToolBarButton()
			Me.infoTool = New System.Windows.Forms.ToolBarButton()
			Me.sep2 = New System.Windows.Forms.ToolBarButton()
			Me.pointTool = New System.Windows.Forms.ToolBarButton()
			Me.rectangleTool = New System.Windows.Forms.ToolBarButton()
			Me.lineTool = New System.Windows.Forms.ToolBarButton()
			Me.polylineTool = New System.Windows.Forms.ToolBarButton()
			Me.circleTool = New System.Windows.Forms.ToolBarButton()
			Me.polygonTool = New System.Windows.Forms.ToolBarButton()
			Me.toolBarButton1 = New System.Windows.Forms.ToolBarButton()
			Me.clearShapes = New System.Windows.Forms.ToolBarButton()
			Me.toolImages = New System.Windows.Forms.ImageList(Me.components)
			Me.statusBar1 = New System.Windows.Forms.StatusBar()
			Me.panel1 = New System.Windows.Forms.Panel()
			Me.panel2 = New System.Windows.Forms.Panel()
			Me.distanceKm = New System.Windows.Forms.Label()
			Me.distanceMi = New System.Windows.Forms.Label()
			Me.label2 = New System.Windows.Forms.Label()
			Me.layerList = New System.Windows.Forms.ComboBox()
			Me.label1 = New System.Windows.Forms.Label()
			Me.textBox1 = New System.Windows.Forms.TextBox()
			Me.splitter1 = New System.Windows.Forms.Splitter()
			Me.dataGrid = New System.Windows.Forms.DataGrid()
			Me.splitter3 = New System.Windows.Forms.Splitter()
			Me.map1 = New ActualMap.Windows.Map()
			Me.printPreview = New System.Windows.Forms.PrintPreviewDialog()
			Me.printDocument = New System.Drawing.Printing.PrintDocument()
			Me.mainMenu1 = New System.Windows.Forms.MainMenu(Me.components)
			Me.menuItem1 = New System.Windows.Forms.MenuItem()
			Me.menuItem2 = New System.Windows.Forms.MenuItem()
			Me.panel1.SuspendLayout()
			Me.panel2.SuspendLayout()
			CType(Me.dataGrid, System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			' 
			' toolBar
			' 
			Me.toolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
			Me.toolBar.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() { Me.sep, Me.zoomFull, Me.zoomInTool, Me.zoomOutTool, Me.panTool, Me.centerTool, Me.distanceTool, Me.infoTool, Me.sep2, Me.pointTool, Me.rectangleTool, Me.lineTool, Me.polylineTool, Me.circleTool, Me.polygonTool, Me.toolBarButton1, Me.clearShapes})
			Me.toolBar.ButtonSize = New System.Drawing.Size(23, 21)
			Me.toolBar.DropDownArrows = True
			Me.toolBar.ImageList = Me.toolImages
			Me.toolBar.Location = New System.Drawing.Point(0, 0)
			Me.toolBar.Name = "toolBar"
			Me.toolBar.ShowToolTips = True
			Me.toolBar.Size = New System.Drawing.Size(994, 32)
			Me.toolBar.TabIndex = 1
'			Me.toolBar.ButtonClick += New System.Windows.Forms.ToolBarButtonClickEventHandler(Me.toolBar_ButtonClick);
			' 
			' sep
			' 
			Me.sep.Name = "sep"
			Me.sep.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
			' 
			' zoomFull
			' 
			Me.zoomFull.ImageIndex = 10
			Me.zoomFull.Name = "zoomFull"
			Me.zoomFull.ToolTipText = "Zoom Full"
			' 
			' zoomInTool
			' 
			Me.zoomInTool.ImageIndex = 11
			Me.zoomInTool.Name = "zoomInTool"
			Me.zoomInTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
			Me.zoomInTool.Tag = ""
			Me.zoomInTool.ToolTipText = "Zoom In"
			' 
			' zoomOutTool
			' 
			Me.zoomOutTool.ImageIndex = 12
			Me.zoomOutTool.Name = "zoomOutTool"
			Me.zoomOutTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
			Me.zoomOutTool.ToolTipText = "Zoom Out"
			' 
			' panTool
			' 
			Me.panTool.ImageIndex = 5
			Me.panTool.Name = "panTool"
			Me.panTool.Pushed = True
			Me.panTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
			Me.panTool.ToolTipText = "Pan"
			' 
			' centerTool
			' 
			Me.centerTool.ImageIndex = 0
			Me.centerTool.Name = "centerTool"
			Me.centerTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
			Me.centerTool.ToolTipText = "Center Map"
			' 
			' distanceTool
			' 
			Me.distanceTool.ImageIndex = 2
			Me.distanceTool.Name = "distanceTool"
			Me.distanceTool.ToolTipText = "Measure Distance"
			' 
			' infoTool
			' 
			Me.infoTool.ImageIndex = 3
			Me.infoTool.Name = "infoTool"
			Me.infoTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
			Me.infoTool.ToolTipText = "Identify"
			' 
			' sep2
			' 
			Me.sep2.Name = "sep2"
			Me.sep2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
			' 
			' pointTool
			' 
			Me.pointTool.ImageIndex = 6
			Me.pointTool.Name = "pointTool"
			Me.pointTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
			Me.pointTool.ToolTipText = "Point Tool"
			' 
			' rectangleTool
			' 
			Me.rectangleTool.ImageIndex = 9
			Me.rectangleTool.Name = "rectangleTool"
			Me.rectangleTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
			Me.rectangleTool.ToolTipText = "Rectangle Tool"
			' 
			' lineTool
			' 
			Me.lineTool.ImageIndex = 4
			Me.lineTool.Name = "lineTool"
			Me.lineTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
			Me.lineTool.ToolTipText = "Line Tool"
			' 
			' polylineTool
			' 
			Me.polylineTool.ImageIndex = 8
			Me.polylineTool.Name = "polylineTool"
			Me.polylineTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
			Me.polylineTool.ToolTipText = "Polyline Tool"
			' 
			' circleTool
			' 
			Me.circleTool.ImageIndex = 1
			Me.circleTool.Name = "circleTool"
			Me.circleTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
			Me.circleTool.ToolTipText = "Circle Tool"
			' 
			' polygonTool
			' 
			Me.polygonTool.ImageIndex = 7
			Me.polygonTool.Name = "polygonTool"
			Me.polygonTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
			Me.polygonTool.ToolTipText = "Polygon Tool"
			' 
			' toolBarButton1
			' 
			Me.toolBarButton1.Name = "toolBarButton1"
			Me.toolBarButton1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
			' 
			' clearShapes
			' 
			Me.clearShapes.ImageIndex = 13
			Me.clearShapes.Name = "clearShapes"
			Me.clearShapes.ToolTipText = "Clear Shapes"
			' 
			' toolImages
			' 
			Me.toolImages.ImageStream = (CType(resources.GetObject("toolImages.ImageStream"), System.Windows.Forms.ImageListStreamer))
			Me.toolImages.TransparentColor = System.Drawing.Color.Transparent
			Me.toolImages.Images.SetKeyName(0, "")
			Me.toolImages.Images.SetKeyName(1, "")
			Me.toolImages.Images.SetKeyName(2, "")
			Me.toolImages.Images.SetKeyName(3, "")
			Me.toolImages.Images.SetKeyName(4, "")
			Me.toolImages.Images.SetKeyName(5, "")
			Me.toolImages.Images.SetKeyName(6, "")
			Me.toolImages.Images.SetKeyName(7, "")
			Me.toolImages.Images.SetKeyName(8, "")
			Me.toolImages.Images.SetKeyName(9, "")
			Me.toolImages.Images.SetKeyName(10, "")
			Me.toolImages.Images.SetKeyName(11, "")
			Me.toolImages.Images.SetKeyName(12, "")
			Me.toolImages.Images.SetKeyName(13, "clear.gif")
			' 
			' statusBar1
			' 
			Me.statusBar1.Location = New System.Drawing.Point(0, 575)
			Me.statusBar1.Name = "statusBar1"
			Me.statusBar1.Size = New System.Drawing.Size(994, 26)
			Me.statusBar1.TabIndex = 10
			' 
			' panel1
			' 
			Me.panel1.Controls.Add(Me.panel2)
			Me.panel1.Dock = System.Windows.Forms.DockStyle.Right
			Me.panel1.Location = New System.Drawing.Point(792, 32)
			Me.panel1.Name = "panel1"
			Me.panel1.Size = New System.Drawing.Size(202, 543)
			Me.panel1.TabIndex = 11
			' 
			' panel2
			' 
			Me.panel2.Controls.Add(Me.distanceKm)
			Me.panel2.Controls.Add(Me.distanceMi)
			Me.panel2.Controls.Add(Me.label2)
			Me.panel2.Controls.Add(Me.layerList)
			Me.panel2.Controls.Add(Me.label1)
			Me.panel2.Controls.Add(Me.textBox1)
			Me.panel2.Dock = System.Windows.Forms.DockStyle.Fill
			Me.panel2.Location = New System.Drawing.Point(0, 0)
			Me.panel2.Name = "panel2"
			Me.panel2.Size = New System.Drawing.Size(202, 543)
			Me.panel2.TabIndex = 2
			' 
			' distanceKm
			' 
			Me.distanceKm.Location = New System.Drawing.Point(11, 150)
			Me.distanceKm.Name = "distanceKm"
			Me.distanceKm.Size = New System.Drawing.Size(176, 27)
			Me.distanceKm.TabIndex = 23
			Me.distanceKm.Text = "kilometers"
			' 
			' distanceMi
			' 
			Me.distanceMi.Location = New System.Drawing.Point(11, 123)
			Me.distanceMi.Name = "distanceMi"
			Me.distanceMi.Size = New System.Drawing.Size(176, 27)
			Me.distanceMi.TabIndex = 22
			Me.distanceMi.Text = "miles"
			' 
			' label2
			' 
			Me.label2.AutoSize = True
			Me.label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.label2.Location = New System.Drawing.Point(7, 97)
			Me.label2.Name = "label2"
			Me.label2.Size = New System.Drawing.Size(76, 17)
			Me.label2.TabIndex = 21
			Me.label2.Text = "Distance:"
			' 
			' layerList
			' 
			Me.layerList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
			Me.layerList.FormattingEnabled = True
			Me.layerList.Location = New System.Drawing.Point(11, 43)
			Me.layerList.Name = "layerList"
			Me.layerList.Size = New System.Drawing.Size(176, 24)
			Me.layerList.TabIndex = 2
			' 
			' label1
			' 
			Me.label1.AutoSize = True
			Me.label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, (CByte(204)))
			Me.label1.Location = New System.Drawing.Point(7, 14)
			Me.label1.Name = "label1"
			Me.label1.Size = New System.Drawing.Size(103, 17)
			Me.label1.TabIndex = 1
			Me.label1.Text = "Active Layer:"
			' 
			' textBox1
			' 
			Me.textBox1.BackColor = System.Drawing.SystemColors.Info
			Me.textBox1.Dock = System.Windows.Forms.DockStyle.Bottom
			Me.textBox1.Location = New System.Drawing.Point(0, 415)
			Me.textBox1.Multiline = True
			Me.textBox1.Name = "textBox1"
			Me.textBox1.ReadOnly = True
			Me.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both
			Me.textBox1.Size = New System.Drawing.Size(202, 128)
			Me.textBox1.TabIndex = 20
			Me.textBox1.Text = "This sample demonstrates the built-in map tools and allows you to select map feat" & "ures by drawing points, lines, circles, rectangles or polygons directly on the m" & "ap."
			' 
			' splitter1
			' 
			Me.splitter1.Dock = System.Windows.Forms.DockStyle.Right
			Me.splitter1.Location = New System.Drawing.Point(789, 32)
			Me.splitter1.Name = "splitter1"
			Me.splitter1.Size = New System.Drawing.Size(3, 543)
			Me.splitter1.TabIndex = 12
			Me.splitter1.TabStop = False
			' 
			' dataGrid
			' 
			Me.dataGrid.DataMember = ""
			Me.dataGrid.Dock = System.Windows.Forms.DockStyle.Bottom
			Me.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText
			Me.dataGrid.Location = New System.Drawing.Point(0, 447)
			Me.dataGrid.Name = "dataGrid"
			Me.dataGrid.RowHeadersVisible = False
			Me.dataGrid.Size = New System.Drawing.Size(789, 128)
			Me.dataGrid.TabIndex = 13
			' 
			' splitter3
			' 
			Me.splitter3.Dock = System.Windows.Forms.DockStyle.Bottom
			Me.splitter3.Location = New System.Drawing.Point(0, 444)
			Me.splitter3.Name = "splitter3"
			Me.splitter3.Size = New System.Drawing.Size(789, 3)
			Me.splitter3.TabIndex = 14
			Me.splitter3.TabStop = False
			' 
			' map1
			' 
			Me.map1.BackColor = System.Drawing.Color.White
			Me.map1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
			Me.map1.Cursor = System.Windows.Forms.Cursors.SizeAll
			Me.map1.Dock = System.Windows.Forms.DockStyle.Fill
			Me.map1.FontQuality = ActualMap.FontQuality.ClearType
			Me.map1.Location = New System.Drawing.Point(0, 32)
			Me.map1.MapTool = ActualMap.Windows.MapTool.Pan
			Me.map1.MapUnit = ActualMap.MeasureUnit.Degree
			Me.map1.Name = "map1"
			Me.map1.PixelPerInch = 96
			Me.map1.ScaleBar.BarUnit = ActualMap.UnitSystem.Imperial
			Me.map1.ScaleBar.FeetString = "ft"
			Me.map1.ScaleBar.Font.Alignment = ActualMap.TextAlign.Left
			Me.map1.ScaleBar.Font.Bold = False
			Me.map1.ScaleBar.Font.Charset = 1
			Me.map1.ScaleBar.Font.Color = System.Drawing.Color.FromArgb((CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))))
			Me.map1.ScaleBar.Font.Italic = False
			Me.map1.ScaleBar.Font.Name = "Arial"
			Me.map1.ScaleBar.Font.Outline = False
			Me.map1.ScaleBar.Font.OutlineColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
			Me.map1.ScaleBar.Font.Size = 12
			Me.map1.ScaleBar.Font.StrikeThrough = False
			Me.map1.ScaleBar.Font.Underline = False
			Me.map1.ScaleBar.KilometersString = "km"
			Me.map1.ScaleBar.MaxWidth = 0
			Me.map1.ScaleBar.MetersString = "m"
			Me.map1.ScaleBar.MilesString = "mi"
			Me.map1.ScaleBar.Position = ActualMap.ScaleBarPosition.BottomRight
			Me.map1.ScaleBar.Symbol.Bitmap = ""
			Me.map1.ScaleBar.Symbol.FillColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
			Me.map1.ScaleBar.Symbol.FillStyle = ActualMap.FillStyle.Solid
			Me.map1.ScaleBar.Symbol.InnerColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
			Me.map1.ScaleBar.Symbol.LineColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))))
			Me.map1.ScaleBar.Symbol.LineStyle = ActualMap.LineStyle.Solid
			Me.map1.ScaleBar.Symbol.PointStyle = ActualMap.PointStyle.Circle
			Me.map1.ScaleBar.Symbol.Rotation = 0
			Me.map1.ScaleBar.Symbol.Size = 1
			Me.map1.ScaleBar.Symbol.TransparentColor = System.Drawing.Color.Empty
			Me.map1.ScaleBar.Visible = True
			Me.map1.Size = New System.Drawing.Size(789, 412)
			Me.map1.SmoothingMode = ActualMap.SmoothingMode.AntiAlias
			Me.map1.TabIndex = 15
			Me.map1.ToolShape.FillColor = System.Drawing.Color.Silver
			Me.map1.ToolShape.LineColor = System.Drawing.Color.Red
'			Me.map1.PolylineToolFinished += New ActualMap.Windows.PolylineToolEventHandler(Me.map1_PolylineToolFinished);
'			Me.map1.DistanceToolMove += New ActualMap.Windows.DistanceToolEventHandler(Me.map1_DistanceToolMove);
'			Me.map1.PolygonToolFinished += New ActualMap.Windows.PolygonToolEventHandler(Me.map1_PolygonToolFinished);
'			Me.map1.CircleToolFinished += New ActualMap.Windows.CircleToolEventHandler(Me.map1_CircleToolFinished);
'			Me.map1.RectangleToolFinished += New ActualMap.Windows.RectangleToolEventHandler(Me.map1_RectangleToolFinished);
'			Me.map1.LineToolFinished += New ActualMap.Windows.LineToolEventHandler(Me.map1_LineToolFinished);
'			Me.map1.InfoTool += New ActualMap.Windows.InfoToolEventHandler(Me.map1_InfoTool);
'			Me.map1.PointTool += New ActualMap.Windows.PointToolEventHandler(Me.map1_PointTool);
			' 
			' printPreview
			' 
			Me.printPreview.AutoScrollMargin = New System.Drawing.Size(0, 0)
			Me.printPreview.AutoScrollMinSize = New System.Drawing.Size(0, 0)
			Me.printPreview.ClientSize = New System.Drawing.Size(400, 300)
			Me.printPreview.Document = Me.printDocument
			Me.printPreview.Enabled = True
			Me.printPreview.Icon = (CType(resources.GetObject("printPreview.Icon"), System.Drawing.Icon))
			Me.printPreview.Name = "printPreview"
			Me.printPreview.Visible = False
			' 
			' printDocument
			' 
'			Me.printDocument.PrintPage += New System.Drawing.Printing.PrintPageEventHandler(Me.printDocument_PrintPage);
			' 
			' mainMenu1
			' 
			Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() { Me.menuItem1})
			' 
			' menuItem1
			' 
			Me.menuItem1.Index = 0
			Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() { Me.menuItem2})
			Me.menuItem1.Text = "File"
			' 
			' menuItem2
			' 
			Me.menuItem2.Index = 0
			Me.menuItem2.Text = "Print Map..."
'			Me.menuItem2.Click += New System.EventHandler(Me.menuItem2_Click);
			' 
			' MapTools
			' 
			Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
			Me.BackColor = System.Drawing.SystemColors.Control
			Me.ClientSize = New System.Drawing.Size(994, 601)
			Me.Controls.Add(Me.map1)
			Me.Controls.Add(Me.splitter3)
			Me.Controls.Add(Me.dataGrid)
			Me.Controls.Add(Me.splitter1)
			Me.Controls.Add(Me.panel1)
			Me.Controls.Add(Me.statusBar1)
			Me.Controls.Add(Me.toolBar)
			Me.Menu = Me.mainMenu1
			Me.Name = "MapTools"
			Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
			Me.Text = "MapTools"
'			Me.Load += New System.EventHandler(Me.Form1_Load);
			Me.panel1.ResumeLayout(False)
			Me.panel2.ResumeLayout(False)
			Me.panel2.PerformLayout()
			CType(Me.dataGrid, System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
			Me.PerformLayout()

		End Sub
		#End Region

		Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
			AddMapLayers()

			For Each layer As Layer In map1
				layerList.Items.Add(layer.Name)
			Next layer
			layerList.SelectedIndex = 0
		End Sub

		Private Sub AddMapLayers()
			Dim layer As Layer
			Dim feature As Feature
			Dim renderer As FeatureRenderer

			Dim LayerFolder As String = Application.StartupPath & "\..\..\MAPS\STREETS\"
			Dim SymbolFolder As String = Application.StartupPath & "\..\..\SYMBOLS\"

			'- COUNTY -------------------------------------------
			layer = map1.AddLayer(LayerFolder & "County.shp")

			layer.LabelField = "NAME"
			layer.Symbol.Size = 2
			layer.Symbol.LineColor = Color.FromArgb(199, 172, 116)
			layer.Symbol.FillColor = Color.FromArgb(242, 236, 223)

			'- PARKS --------------------------------------------
			layer = map1.AddLayer(LayerFolder & "Park.shp")

			layer.LabelField = "NAME"
			layer.ShowLabels = True
			layer.LabelFont.Outline = True
			layer.LabelFont.Size = 11
			layer.LabelFont.Bold = True
			layer.Symbol.FillColor = Color.FromArgb(143, 175, 47)
			layer.Symbol.LineColor = layer.Symbol.FillColor

			'- WATER AREAS --------------------------------------
			layer = map1.AddLayer(LayerFolder & "WaterArea.shp")
			layer.MaxScale = 300000

			layer.LabelField = "NAME"
			layer.ShowLabels = True
			layer.LabelFont.Outline = True
			layer.LabelFont.Size = 12
			layer.Symbol.FillColor = Color.FromArgb(159, 159, 223)
			layer.Symbol.LineColor = layer.Symbol.FillColor

			'- RIVERS -------------------------------------------
			layer = map1.AddLayer(LayerFolder & "Water.shp")
			layer.MaxScale = 300000

			layer.LabelField = "NAME"
			layer.ShowLabels = True
			layer.LabelFont.Size = 9
			layer.Symbol.FillColor = Color.FromArgb(159, 159, 223)
			layer.Symbol.LineColor = layer.Symbol.FillColor
			layer.LabelFont.Color = Color.FromArgb(0, 0, 128)

			'- AIRPORTS -----------------------------------------
			layer = map1.AddLayer(LayerFolder & "Airport.shp")

			layer.LabelField = "NAME"
			layer.ShowLabels = True
			layer.LabelFont.Outline = True
			layer.LabelFont.Size = 11
			layer.Symbol.FillColor = Color.FromArgb(43, 147, 43)

			'- STREETS ------------------------------------------
			layer = map1.AddLayer(LayerFolder & "Street.shp")
			layer.MaxScale = 150000

			layer.LabelField = "NAME"
			layer.LabelFont.Size = 10
			layer.ShowLabels = True
            layer.Symbol.LineStyle = ActualMap.LineStyle.Road
			layer.Symbol.LineColor = Color.FromArgb(171, 158, 137)
			layer.Symbol.InnerColor = Color.White

			' set different line width of the streets for different scales
			feature = New ActualMap.Feature()
			feature.MaxScale = 75000
			feature.MinScale = 37000
            feature.Symbol.LineStyle = ActualMap.LineStyle.Road
			feature.Symbol.LineColor = Color.FromArgb(171, 158, 137)
			feature.Symbol.InnerColor = Color.White
			feature.Symbol.Size = 3
			layer.Renderer.Add(feature)

			feature = feature.Clone()
			feature.MaxScale = 37000
			feature.MinScale = 16000
			feature.Symbol.Size = 4
			feature.LabelFont.Outline = True
			layer.Renderer.Add(feature)

			feature = feature.Clone()
			feature.MaxScale = 16000
			feature.MinScale = -1 ' no minimum scale
			feature.Symbol.Size = 6
			layer.Renderer.Add(feature)

			'- RAILROADS ----------------------------------------
			layer = map1.AddLayer(LayerFolder & "Railroad.shp")
			layer.MaxScale = 200000

			layer.LabelField = "NAME"
			layer.ShowLabels = True
			layer.LabelFont.Outline = True
			layer.LabelFont.Size = 10
            layer.Symbol.LineStyle = ActualMap.LineStyle.Railroad

			'- INSTITUTIONS -------------------------------------
			layer = map1.AddLayer(LayerFolder & "Institution.shp")

			layer.LabelField = "NAME"
			layer.ShowLabels = True
			layer.LabelFont.Name = "Times New Roman"
			layer.LabelFont.Outline = True
			layer.LabelFont.Size = 12
			layer.UseDefaultSymbol = False

			renderer = layer.Renderer
			renderer.Field = "FCC"

			' cemetery symbol
			feature = renderer.Add()
			feature.Value = "D82"
            feature.Symbol.PointStyle = ActualMap.PointStyle.Bitmap
			feature.Symbol.Bitmap = SymbolFolder & "cemetery.bmp"
			feature.Symbol.Size = 16
			feature.Symbol.TransparentColor = Color.White
			feature.Description = "Cemetery"

			' school symbol
			feature = renderer.Add()
			feature.Value = "D43"
            feature.Symbol.PointStyle = ActualMap.PointStyle.Bitmap
			feature.Symbol.Bitmap = SymbolFolder & "school.bmp"
			feature.Symbol.Size = 16
			feature.Symbol.TransparentColor = Color.White
			feature.Description = "School"

			' church symbol
			feature = renderer.Add()
			feature.Value = "D44"
            feature.Symbol.PointStyle = ActualMap.PointStyle.Bitmap
			feature.Symbol.Bitmap = SymbolFolder & "church.bmp"
			feature.Symbol.Size = 16
			feature.Symbol.TransparentColor = Color.White
			feature.Description = "Church"

			' hospital symbol
			feature = renderer.Add()
			feature.Value = "D31"
            feature.Symbol.PointStyle = ActualMap.PointStyle.Bitmap
			feature.Symbol.Bitmap = SymbolFolder & "hospital.bmp"
			feature.Symbol.Size = 16
			feature.Symbol.TransparentColor = Color.White
			feature.Description = "Hospital"
		End Sub

		Private Sub toolBar_ButtonClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles toolBar.ButtonClick
			If e.Button.Style = ToolBarButtonStyle.ToggleButton Then
				For Each b As ToolBarButton In toolBar.Buttons
				b.Pushed = False
				Next b
				e.Button.Pushed = True
			End If

			map1.Cursor = Cursors.Default

			If e.Button Is zoomFull Then
				map1.ZoomFull()
				map1.Refresh()
			End If
			If e.Button Is clearShapes Then
				map1.MapShapes.Clear()
				map1.Callouts.Clear()
				dataGrid.DataSource = Nothing
				dataGrid.CaptionText = String.Empty
				map1.Refresh()
			ElseIf e.Button Is zoomInTool Then
			map1.MapTool = MapTool.ZoomIn
			ElseIf e.Button Is zoomOutTool Then
			map1.MapTool = MapTool.ZoomOut
			ElseIf e.Button Is panTool Then
				map1.MapTool = MapTool.Pan
				map1.Cursor = Cursors.SizeAll
			ElseIf e.Button Is centerTool Then
			map1.MapTool = MapTool.Center
			ElseIf e.Button Is distanceTool Then
			map1.MapTool = MapTool.Distance
			ElseIf e.Button Is infoTool Then
			map1.MapTool = MapTool.Info
			ElseIf e.Button Is pointTool Then
			map1.MapTool = MapTool.Point
			ElseIf e.Button Is rectangleTool Then
			map1.MapTool = MapTool.Rectangle
			ElseIf e.Button Is lineTool Then
			map1.MapTool = MapTool.Line
			ElseIf e.Button Is polylineTool Then
			map1.MapTool = MapTool.Polyline
			ElseIf e.Button Is polygonTool Then
			map1.MapTool = MapTool.Polygon
			ElseIf e.Button Is circleTool Then
			map1.MapTool = MapTool.Circle
			End If
		End Sub

		Private Sub map1_PointTool(ByVal sender As Object, ByVal e As ActualMap.Windows.PointToolEventArgs) Handles map1.PointTool
			map1.MapShapes.Clear()

			Dim mapShape As MapShape = map1.MapShapes.Add(e.Point)
			mapShape.Symbol.Size = 6
			mapShape.Symbol.FillColor = Color.Red

			Dim activeLayer As Layer = map1.FindLayer(layerList.SelectedItem.ToString())

            If activeLayer IsNot Nothing AndAlso activeLayer.LayerType = ActualMap.LayerType.Polygon Then
                Dim records As ActualMap.Recordset = activeLayer.SearchShape(e.Point, ActualMap.SearchMethod.PointInPolygon)

                If (Not records.EOF) Then
                    dataGrid.DataSource = records
                    dataGrid.CaptionText = records.Layer.Name.ToUpper()
                End If
            End If

			map1.Refresh()
		End Sub

		Private Sub map1_LineToolFinished(ByVal sender As Object, ByVal e As ActualMap.Windows.LineToolEventArgs) Handles map1.LineToolFinished
			map1.MapShapes.Clear()

			Dim mapShape As MapShape = map1.MapShapes.Add(e.Line)
			mapShape.Symbol.Size = 2
			mapShape.Symbol.LineColor = Color.Red

			Dim activeLayer As ActualMap.Layer = map1.FindLayer(layerList.SelectedItem.ToString())

			If activeLayer IsNot Nothing Then
                Dim records As ActualMap.Recordset = activeLayer.SearchShape(e.Line, ActualMap.SearchMethod.Intersect)

				If (Not records.EOF) Then
					dataGrid.DataSource = records
					dataGrid.CaptionText = records.Layer.Name.ToUpper()
				End If
			End If
			map1.Refresh()
		End Sub

		Private Sub map1_CircleToolFinished(ByVal sender As Object, ByVal e As ActualMap.Windows.CircleToolEventArgs) Handles map1.CircleToolFinished
			map1.MapShapes.Clear()

			Dim mapShape As MapShape = map1.MapShapes.Add(e.Circle)
			mapShape.Symbol.Size = 2
			mapShape.Symbol.LineColor = Color.Red
            mapShape.Symbol.FillStyle = ActualMap.FillStyle.Invisible

			Dim activeLayer As ActualMap.Layer = map1.FindLayer(layerList.SelectedItem.ToString())

			If activeLayer IsNot Nothing Then
                Dim records As ActualMap.Recordset = activeLayer.SearchShape(e.Circle, ActualMap.SearchMethod.Inside)

				If (Not records.EOF) Then
					dataGrid.DataSource = records
					dataGrid.CaptionText = records.Layer.Name.ToUpper()
				End If
			End If

			map1.Refresh()
		End Sub

		Private Sub map1_InfoTool(ByVal sender As Object, ByVal e As ActualMap.Windows.InfoToolEventArgs) Handles map1.InfoTool
			map1.Callouts.Clear()

			Dim records As ActualMap.Recordset = map1.Identify(e.InfoPoint, 5)

			If (Not records.EOF) Then
				dataGrid.DataSource = records
				dataGrid.CaptionText = records.Layer.Name

				Dim callout As Callout = map1.Callouts.Add()
				callout.X = e.InfoPoint.X
				callout.Y = e.InfoPoint.Y
				callout.Text = GetCalloutText(records)
				callout.Font.Size = 16

				map1.Refresh()
			End If
		End Sub

		Private Sub map1_PolygonToolFinished(ByVal sender As Object, ByVal e As ActualMap.Windows.PolygonToolEventArgs) Handles map1.PolygonToolFinished
			map1.MapShapes.Clear()

			Dim mapShape As MapShape = map1.MapShapes.Add(e.Polygon)
			mapShape.Symbol.Size = 2
			mapShape.Symbol.LineColor = Color.Red
            mapShape.Symbol.FillStyle = ActualMap.FillStyle.Invisible

			Dim activeLayer As ActualMap.Layer = map1.FindLayer(layerList.SelectedItem.ToString())

			If activeLayer IsNot Nothing Then
                Dim records As ActualMap.Recordset = activeLayer.SearchShape(e.Polygon, ActualMap.SearchMethod.Inside)

				If (Not records.EOF) Then
					dataGrid.DataSource = records
					dataGrid.CaptionText = records.Layer.Name.ToUpper()
				End If
			End If

			map1.Refresh()
		End Sub

		Private Sub map1_PolylineToolFinished(ByVal sender As Object, ByVal e As ActualMap.Windows.PolylineToolEventArgs) Handles map1.PolylineToolFinished
			map1.MapShapes.Clear()

			Dim mapShape As MapShape = map1.MapShapes.Add(e.Polyline)
			mapShape.Symbol.Size = 2
			mapShape.Symbol.LineColor = Color.Red

			Dim activeLayer As ActualMap.Layer = map1.FindLayer(layerList.SelectedItem.ToString())

			If activeLayer IsNot Nothing Then
                Dim records As ActualMap.Recordset = activeLayer.SearchShape(e.Polyline, ActualMap.SearchMethod.Intersect)

				If (Not records.EOF) Then
					dataGrid.DataSource = records
					dataGrid.CaptionText = records.Layer.Name.ToUpper()
				End If
			End If

			map1.Refresh()
		End Sub

		Private Sub map1_RectangleToolFinished(ByVal sender As Object, ByVal e As ActualMap.Windows.RectangleToolEventArgs) Handles map1.RectangleToolFinished
			map1.MapShapes.Clear()

			Dim mapShape As MapShape = map1.MapShapes.Add(e.Rectangle)
			mapShape.Symbol.Size = 2
			mapShape.Symbol.LineColor = Color.Red
            mapShape.Symbol.FillStyle = ActualMap.FillStyle.Invisible

			Dim activeLayer As ActualMap.Layer = map1.FindLayer(layerList.SelectedItem.ToString())

			If activeLayer IsNot Nothing Then
                Dim records As ActualMap.Recordset = activeLayer.SearchShape(e.Rectangle, ActualMap.SearchMethod.Inside)

				If (Not records.EOF) Then
					dataGrid.DataSource = records
					dataGrid.CaptionText = records.Layer.Name.ToUpper()
				End If
			End If

			map1.Refresh()
		End Sub

		Private Sub map1_DistanceToolMove(ByVal sender As Object, ByVal e As ActualMap.Windows.DistanceToolEventArgs) Handles map1.DistanceToolMove
			Dim distanceInMapUnits As Double = e.Distance
            Dim distanceInMiles As Double = Math.Round(map1.ConvertDistance(distanceInMapUnits, map1.MapUnit, ActualMap.MeasureUnit.Mile), 3)
            Dim distanceInKilometers As Double = Math.Round(map1.ConvertDistance(distanceInMapUnits, map1.MapUnit, ActualMap.MeasureUnit.Kilometer), 3)
			distanceMi.Text = distanceInMiles.ToString() & " mi"
			distanceKm.Text = distanceInKilometers.ToString() & " km"
		End Sub

		Private Sub menuItem2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles menuItem2.Click
			printPreview.ShowDialog()
		End Sub

		Private Sub printDocument_PrintPage(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles printDocument.PrintPage
			Dim mapImage As Bitmap = map1.GetBitmap(700, 600)
			e.Graphics.DrawImageUnscaled(mapImage, 50, 50)
		End Sub

		Private Function GetCalloutText(ByVal rs As ActualMap.Recordset) As String
			Dim index As Integer = rs.Fields.GetFieldIndex("NAME")
			If index < 0 Then
			index = rs.Fields.GetFieldIndex(rs.Layer.LabelField)
			End If
			If index < 0 Then
			index = 0
			End If
			Return rs(index).ToString()
		End Function
	End Class
End Namespace
