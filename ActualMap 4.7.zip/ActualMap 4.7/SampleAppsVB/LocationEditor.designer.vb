Imports Microsoft.VisualBasic
Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports ActualMap
Imports ActualMap.Windows

Namespace SampleApps
    Partial Public Class LocationEditor
        ''' <summary>
        ''' Required designer variable.
        ''' </summary>
        Private components As System.ComponentModel.IContainer = Nothing

        ''' <summary>
        ''' Clean up any resources being used.
        ''' </summary>
        ''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing AndAlso (components IsNot Nothing) Then
                components.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub

#Region "Windows Form Designer generated code"

        ''' <summary>
        ''' Required method for Designer support - do not modify
        ''' the contents of this method with the code editor.
        ''' </summary>
        Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(LocationEditor))
            Me.panel1 = New System.Windows.Forms.Panel()
            Me.panel3 = New System.Windows.Forms.Panel()
            Me.locationPanel = New System.Windows.Forms.Panel()
            Me.remove = New System.Windows.Forms.Button()
            Me.cancel = New System.Windows.Forms.Button()
            Me.save = New System.Windows.Forms.Button()
            Me.locationTitle = New System.Windows.Forms.TextBox()
            Me.operation = New System.Windows.Forms.Label()
            Me.textBox1 = New System.Windows.Forms.TextBox()
            Me.splitter1 = New System.Windows.Forms.Splitter()
            Me.splitter3 = New System.Windows.Forms.Splitter()
            Me.map1 = New ActualMap.Windows.Map()
            Me.toolStrip1 = New System.Windows.Forms.ToolStrip()
            Me.toolStripButton1 = New System.Windows.Forms.ToolStripButton()
            Me.panel1.SuspendLayout()
            Me.panel3.SuspendLayout()
            Me.locationPanel.SuspendLayout()
            Me.toolStrip1.SuspendLayout()
            Me.SuspendLayout()
            ' 
            ' panel1
            ' 
            Me.panel1.Controls.Add(Me.panel3)
            Me.panel1.Dock = System.Windows.Forms.DockStyle.Right
            Me.panel1.Location = New System.Drawing.Point(774, 0)
            Me.panel1.Name = "panel1"
            Me.panel1.Size = New System.Drawing.Size(202, 582)
            Me.panel1.TabIndex = 11
            ' 
            ' panel3
            ' 
            Me.panel3.Controls.Add(Me.locationPanel)
            Me.panel3.Controls.Add(Me.textBox1)
            Me.panel3.Dock = System.Windows.Forms.DockStyle.Fill
            Me.panel3.Location = New System.Drawing.Point(0, 0)
            Me.panel3.Name = "panel3"
            Me.panel3.Size = New System.Drawing.Size(202, 582)
            Me.panel3.TabIndex = 2
            ' 
            ' locationPanel
            ' 
            Me.locationPanel.Controls.Add(Me.remove)
            Me.locationPanel.Controls.Add(Me.cancel)
            Me.locationPanel.Controls.Add(Me.save)
            Me.locationPanel.Controls.Add(Me.locationTitle)
            Me.locationPanel.Controls.Add(Me.operation)
            Me.locationPanel.Dock = System.Windows.Forms.DockStyle.Fill
            Me.locationPanel.Location = New System.Drawing.Point(0, 90)
            Me.locationPanel.Name = "locationPanel"
            Me.locationPanel.Size = New System.Drawing.Size(202, 492)
            Me.locationPanel.TabIndex = 21
            Me.locationPanel.Visible = False
            ' 
            ' remove
            ' 
            Me.remove.Location = New System.Drawing.Point(115, 98)
            Me.remove.Name = "remove"
            Me.remove.Size = New System.Drawing.Size(75, 23)
            Me.remove.TabIndex = 34
            Me.remove.Text = "Remove"
            Me.remove.UseVisualStyleBackColor = True
            '			Me.remove.Click += New System.EventHandler(Me.remove_Click);
            ' 
            ' cancel
            ' 
            Me.cancel.Location = New System.Drawing.Point(115, 58)
            Me.cancel.Name = "cancel"
            Me.cancel.Size = New System.Drawing.Size(75, 23)
            Me.cancel.TabIndex = 33
            Me.cancel.Text = "Cancel"
            Me.cancel.UseVisualStyleBackColor = True
            '			Me.cancel.Click += New System.EventHandler(Me.cancel_Click);
            ' 
            ' save
            ' 
            Me.save.Location = New System.Drawing.Point(9, 58)
            Me.save.Name = "save"
            Me.save.Size = New System.Drawing.Size(75, 23)
            Me.save.TabIndex = 32
            Me.save.Text = "Save"
            Me.save.UseVisualStyleBackColor = True
            '			Me.save.Click += New System.EventHandler(Me.save_Click);
            ' 
            ' locationTitle
            ' 
            Me.locationTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, (CByte(204)))
            Me.locationTitle.Location = New System.Drawing.Point(9, 26)
            Me.locationTitle.Name = "locationTitle"
            Me.locationTitle.Size = New System.Drawing.Size(184, 22)
            Me.locationTitle.TabIndex = 29
            Me.locationTitle.Text = "Title"
            ' 
            ' operation
            ' 
            Me.operation.AutoSize = True
            Me.operation.Location = New System.Drawing.Point(9, 6)
            Me.operation.Name = "operation"
            Me.operation.Size = New System.Drawing.Size(90, 17)
            Me.operation.TabIndex = 28
            Me.operation.Text = "Add location:"
            ' 
            ' textBox1
            ' 
            Me.textBox1.BackColor = System.Drawing.SystemColors.Info
            Me.textBox1.Dock = System.Windows.Forms.DockStyle.Top
            Me.textBox1.Location = New System.Drawing.Point(0, 0)
            Me.textBox1.Multiline = True
            Me.textBox1.Name = "textBox1"
            Me.textBox1.ReadOnly = True
            Me.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both
            Me.textBox1.Size = New System.Drawing.Size(202, 90)
            Me.textBox1.TabIndex = 20
            Me.textBox1.TabStop = False
            Me.textBox1.Text = "Click anywhere on the map to add a location. Click on a location to move it, modi" & "fy its attributes or remove it."
            ' 
            ' splitter1
            ' 
            Me.splitter1.Dock = System.Windows.Forms.DockStyle.Right
            Me.splitter1.Location = New System.Drawing.Point(771, 0)
            Me.splitter1.Name = "splitter1"
            Me.splitter1.Size = New System.Drawing.Size(3, 582)
            Me.splitter1.TabIndex = 12
            Me.splitter1.TabStop = False
            ' 
            ' splitter3
            ' 
            Me.splitter3.Dock = System.Windows.Forms.DockStyle.Bottom
            Me.splitter3.Location = New System.Drawing.Point(0, 579)
            Me.splitter3.Name = "splitter3"
            Me.splitter3.Size = New System.Drawing.Size(771, 3)
            Me.splitter3.TabIndex = 14
            Me.splitter3.TabStop = False
            ' 
            ' map1
            ' 
            Me.map1.BackColor = System.Drawing.Color.White
            Me.map1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
            Me.map1.Dock = System.Windows.Forms.DockStyle.Fill
            Me.map1.FontQuality = ActualMap.FontQuality.ClearType
            Me.map1.Location = New System.Drawing.Point(0, 0)
            Me.map1.MapTool = ActualMap.Windows.MapTool.Pan
            Me.map1.Name = "map1"
            Me.map1.PixelPerInch = 96
            Me.map1.ScaleBar.BarUnit = ActualMap.UnitSystem.Imperial
            Me.map1.ScaleBar.FeetString = "ft"
            Me.map1.ScaleBar.Font.Alignment = ActualMap.TextAlign.Left
            Me.map1.ScaleBar.Font.Bold = False
            Me.map1.ScaleBar.Font.Charset = 1
            Me.map1.ScaleBar.Font.Color = System.Drawing.Color.FromArgb((CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))))
            Me.map1.ScaleBar.Font.Italic = False
            Me.map1.ScaleBar.Font.Name = "Arial"
            Me.map1.ScaleBar.Font.Outline = False
            Me.map1.ScaleBar.Font.OutlineColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
            Me.map1.ScaleBar.Font.Size = 12
            Me.map1.ScaleBar.Font.StrikeThrough = False
            Me.map1.ScaleBar.Font.Underline = False
            Me.map1.ScaleBar.KilometersString = "km"
            Me.map1.ScaleBar.MaxWidth = 0
            Me.map1.ScaleBar.MetersString = "m"
            Me.map1.ScaleBar.MilesString = "mi"
            Me.map1.ScaleBar.Position = ActualMap.ScaleBarPosition.BottomRight
            Me.map1.ScaleBar.Symbol.Bitmap = ""
            Me.map1.ScaleBar.Symbol.FillColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
            Me.map1.ScaleBar.Symbol.FillStyle = ActualMap.FillStyle.Solid
            Me.map1.ScaleBar.Symbol.InnerColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
            Me.map1.ScaleBar.Symbol.LineColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))))
            Me.map1.ScaleBar.Symbol.LineStyle = ActualMap.LineStyle.Solid
            Me.map1.ScaleBar.Symbol.PointStyle = ActualMap.PointStyle.Circle
            Me.map1.ScaleBar.Symbol.Rotation = 0
            Me.map1.ScaleBar.Symbol.Size = 1
            Me.map1.ScaleBar.Symbol.TransparentColor = System.Drawing.Color.Empty
            Me.map1.ScaleBar.Visible = True
            Me.map1.Size = New System.Drawing.Size(771, 579)
            Me.map1.SmoothingMode = ActualMap.SmoothingMode.AntiAlias
            Me.map1.TabIndex = 15
            Me.map1.ToolShape.FillColor = System.Drawing.Color.Yellow
            Me.map1.ToolShape.LineColor = System.Drawing.Color.Red
            Me.map1.ToolShape.LineWidth = 1
            Me.map1.ToolShape.VertexColor = System.Drawing.Color.Tan
            Me.map1.ToolShape.VertexSize = 13
            Me.map1.ToolShape.VirtualVertexColor = System.Drawing.Color.Green
            '			Me.map1.PanToolClick += New ActualMap.Windows.PanToolClickEventHandler(Me.map1_PanToolClick);
            ' 
            ' toolStrip1
            ' 
            Me.toolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.toolStripButton1})
            Me.toolStrip1.Location = New System.Drawing.Point(0, 0)
            Me.toolStrip1.Name = "toolStrip1"
            Me.toolStrip1.Size = New System.Drawing.Size(771, 27)
            Me.toolStrip1.TabIndex = 16
            Me.toolStrip1.Text = "toolStrip1"
            ' 
            ' toolStripButton1
            ' 
            Me.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
            Me.toolStripButton1.Image = (CType(resources.GetObject("toolStripButton1.Image"), System.Drawing.Image))
            Me.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
            Me.toolStripButton1.Name = "toolStripButton1"
            Me.toolStripButton1.Size = New System.Drawing.Size(80, 24)
            Me.toolStripButton1.Text = "Zoom Full"
            '			Me.toolStripButton1.Click += New System.EventHandler(Me.toolStripButton1_Click);
            ' 
            ' LocationEditor
            ' 
            Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
            Me.BackColor = System.Drawing.SystemColors.Control
            Me.ClientSize = New System.Drawing.Size(976, 582)
            Me.Controls.Add(Me.toolStrip1)
            Me.Controls.Add(Me.map1)
            Me.Controls.Add(Me.splitter3)
            Me.Controls.Add(Me.splitter1)
            Me.Controls.Add(Me.panel1)
            Me.Name = "LocationEditor"
            Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
            Me.Text = "Location Editor"
            '			Me.Load += New System.EventHandler(Me.Form1_Load);
            Me.panel1.ResumeLayout(False)
            Me.panel3.ResumeLayout(False)
            Me.panel3.PerformLayout()
            Me.locationPanel.ResumeLayout(False)
            Me.locationPanel.PerformLayout()
            Me.toolStrip1.ResumeLayout(False)
            Me.toolStrip1.PerformLayout()
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

#End Region

        Private panel1 As System.Windows.Forms.Panel
        Private splitter1 As System.Windows.Forms.Splitter
        Private panel3 As System.Windows.Forms.Panel
        Private splitter3 As System.Windows.Forms.Splitter
        Private WithEvents map1 As ActualMap.Windows.Map
        Private textBox1 As TextBox
        Private locationPanel As Panel
        Private WithEvents remove As Button
        Private WithEvents cancel As Button
        Private WithEvents save As Button
        Private locationTitle As TextBox
        Private operation As Label
        Private toolStrip1 As ToolStrip
        Private WithEvents toolStripButton1 As ToolStripButton

    End Class
End Namespace