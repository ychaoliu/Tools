Imports Microsoft.VisualBasic
Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports ActualMap
Imports ActualMap.Windows

Namespace SampleApps
	Partial Public Class ProjectedWorldMap
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(ByVal disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.statusBar1 = New System.Windows.Forms.StatusBar()
			Me.panel1 = New System.Windows.Forms.Panel()
			Me.panel2 = New System.Windows.Forms.Panel()
			Me.label1 = New System.Windows.Forms.Label()
			Me.coordSystemList = New System.Windows.Forms.ComboBox()
			Me.textBox1 = New System.Windows.Forms.TextBox()
			Me.splitter1 = New System.Windows.Forms.Splitter()
			Me.dataGrid = New System.Windows.Forms.DataGrid()
			Me.splitter3 = New System.Windows.Forms.Splitter()
			Me.map1 = New ActualMap.Windows.Map()
			Me.panel1.SuspendLayout()
			Me.panel2.SuspendLayout()
			CType(Me.dataGrid, System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			' 
			' statusBar1
			' 
			Me.statusBar1.Location = New System.Drawing.Point(0, 477)
			Me.statusBar1.Name = "statusBar1"
			Me.statusBar1.Size = New System.Drawing.Size(879, 22)
			Me.statusBar1.TabIndex = 10
			' 
			' panel1
			' 
			Me.panel1.Controls.Add(Me.panel2)
			Me.panel1.Dock = System.Windows.Forms.DockStyle.Right
			Me.panel1.Location = New System.Drawing.Point(711, 0)
			Me.panel1.Name = "panel1"
			Me.panel1.Size = New System.Drawing.Size(168, 477)
			Me.panel1.TabIndex = 11
			' 
			' panel2
			' 
			Me.panel2.Controls.Add(Me.label1)
			Me.panel2.Controls.Add(Me.coordSystemList)
			Me.panel2.Controls.Add(Me.textBox1)
			Me.panel2.Dock = System.Windows.Forms.DockStyle.Fill
			Me.panel2.Location = New System.Drawing.Point(0, 0)
			Me.panel2.Name = "panel2"
			Me.panel2.Size = New System.Drawing.Size(168, 477)
			Me.panel2.TabIndex = 2
			' 
			' label1
			' 
			Me.label1.AutoSize = True
			Me.label1.Location = New System.Drawing.Point(6, 9)
			Me.label1.Name = "label1"
			Me.label1.Size = New System.Drawing.Size(98, 13)
			Me.label1.TabIndex = 22
			Me.label1.Text = "Coordinate System:"
			' 
			' coordSystemList
			' 
			Me.coordSystemList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
			Me.coordSystemList.FormattingEnabled = True
			Me.coordSystemList.Location = New System.Drawing.Point(6, 28)
			Me.coordSystemList.Name = "coordSystemList"
			Me.coordSystemList.Size = New System.Drawing.Size(150, 21)
			Me.coordSystemList.TabIndex = 21
'			Me.coordSystemList.SelectedIndexChanged += New System.EventHandler(Me.coordSystemList_SelectedIndexChanged);
			' 
			' textBox1
			' 
			Me.textBox1.BackColor = System.Drawing.SystemColors.Info
			Me.textBox1.Dock = System.Windows.Forms.DockStyle.Bottom
			Me.textBox1.Location = New System.Drawing.Point(0, 366)
			Me.textBox1.Multiline = True
			Me.textBox1.Name = "textBox1"
			Me.textBox1.ReadOnly = True
			Me.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both
			Me.textBox1.Size = New System.Drawing.Size(168, 111)
			Me.textBox1.TabIndex = 20
			Me.textBox1.TabStop = False
			Me.textBox1.Text = "This sample uses a CoordSystem object to project a world map into various coordin" & "ate systems."
			' 
			' splitter1
			' 
			Me.splitter1.Dock = System.Windows.Forms.DockStyle.Right
			Me.splitter1.Location = New System.Drawing.Point(708, 0)
			Me.splitter1.Name = "splitter1"
			Me.splitter1.Size = New System.Drawing.Size(3, 477)
			Me.splitter1.TabIndex = 12
			Me.splitter1.TabStop = False
			' 
			' dataGrid
			' 
			Me.dataGrid.DataMember = ""
			Me.dataGrid.Dock = System.Windows.Forms.DockStyle.Bottom
			Me.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText
			Me.dataGrid.Location = New System.Drawing.Point(0, 366)
			Me.dataGrid.Name = "dataGrid"
			Me.dataGrid.RowHeadersVisible = False
			Me.dataGrid.Size = New System.Drawing.Size(708, 111)
			Me.dataGrid.TabIndex = 13
			' 
			' splitter3
			' 
			Me.splitter3.Dock = System.Windows.Forms.DockStyle.Bottom
			Me.splitter3.Location = New System.Drawing.Point(0, 363)
			Me.splitter3.Name = "splitter3"
			Me.splitter3.Size = New System.Drawing.Size(708, 3)
			Me.splitter3.TabIndex = 14
			Me.splitter3.TabStop = False
			' 
			' map1
			' 
			Me.map1.BackColor = System.Drawing.Color.White
			Me.map1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
			Me.map1.Dock = System.Windows.Forms.DockStyle.Fill
			Me.map1.FontQuality = ActualMap.FontQuality.ClearType
			Me.map1.Location = New System.Drawing.Point(0, 0)
			Me.map1.MapTool = ActualMap.Windows.MapTool.ZoomIn
			Me.map1.MapUnit = ActualMap.MeasureUnit.Degree
			Me.map1.Name = "map1"
			Me.map1.PixelPerInch = 96
			Me.map1.ScaleBar.BarUnit = ActualMap.UnitSystem.Imperial
			Me.map1.ScaleBar.FeetString = "ft"
			Me.map1.ScaleBar.Font.Alignment = ActualMap.TextAlign.Left
			Me.map1.ScaleBar.Font.Bold = False
			Me.map1.ScaleBar.Font.Charset = 1
			Me.map1.ScaleBar.Font.Color = System.Drawing.Color.FromArgb((CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))))
			Me.map1.ScaleBar.Font.Italic = False
			Me.map1.ScaleBar.Font.Name = "Arial"
			Me.map1.ScaleBar.Font.Outline = False
			Me.map1.ScaleBar.Font.OutlineColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
			Me.map1.ScaleBar.Font.Size = 12
			Me.map1.ScaleBar.Font.StrikeThrough = False
			Me.map1.ScaleBar.Font.Underline = False
			Me.map1.ScaleBar.KilometersString = "km"
			Me.map1.ScaleBar.MaxWidth = 0
			Me.map1.ScaleBar.MetersString = "m"
			Me.map1.ScaleBar.MilesString = "mi"
			Me.map1.ScaleBar.Position = ActualMap.ScaleBarPosition.BottomRight
			Me.map1.ScaleBar.Symbol.Bitmap = ""
			Me.map1.ScaleBar.Symbol.FillColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
			Me.map1.ScaleBar.Symbol.FillStyle = ActualMap.FillStyle.Solid
			Me.map1.ScaleBar.Symbol.InnerColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
			Me.map1.ScaleBar.Symbol.LineColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))))
			Me.map1.ScaleBar.Symbol.LineStyle = ActualMap.LineStyle.Solid
			Me.map1.ScaleBar.Symbol.PointStyle = ActualMap.PointStyle.Circle
			Me.map1.ScaleBar.Symbol.Size = 1
			Me.map1.ScaleBar.Symbol.TransparentColor = System.Drawing.Color.Empty
			Me.map1.ScaleBar.Visible = True
			Me.map1.Size = New System.Drawing.Size(708, 363)
			Me.map1.SmoothingMode = ActualMap.SmoothingMode.None
			Me.map1.TabIndex = 15
			Me.map1.ToolShape.FillColor = System.Drawing.Color.Silver
			Me.map1.ToolShape.LineColor = System.Drawing.Color.Red
			' 
			' ProjectedWorldMap
			' 
			Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
			Me.BackColor = System.Drawing.SystemColors.Control
			Me.ClientSize = New System.Drawing.Size(879, 499)
			Me.Controls.Add(Me.map1)
			Me.Controls.Add(Me.splitter3)
			Me.Controls.Add(Me.dataGrid)
			Me.Controls.Add(Me.splitter1)
			Me.Controls.Add(Me.panel1)
			Me.Controls.Add(Me.statusBar1)
			Me.Name = "ProjectedWorldMap"
			Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
			Me.Text = "Projected World Map"
'			Me.Load += New System.EventHandler(Me.Form1_Load);
			Me.panel1.ResumeLayout(False)
			Me.panel2.ResumeLayout(False)
			Me.panel2.PerformLayout()
			CType(Me.dataGrid, System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)

		End Sub

		#End Region

		Private statusBar1 As System.Windows.Forms.StatusBar
		Private panel1 As System.Windows.Forms.Panel
		Private splitter1 As System.Windows.Forms.Splitter
		Private panel2 As System.Windows.Forms.Panel
		Private splitter3 As System.Windows.Forms.Splitter
		Private map1 As ActualMap.Windows.Map
		Private dataGrid As System.Windows.Forms.DataGrid
		Private textBox1 As TextBox
		Private label1 As Label
		Private WithEvents coordSystemList As ComboBox

	End Class
End Namespace