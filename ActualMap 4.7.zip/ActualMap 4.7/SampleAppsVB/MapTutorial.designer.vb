Imports Microsoft.VisualBasic
Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports ActualMap
Imports ActualMap.Windows

Namespace SampleApps
	Partial Public Class MapTutorial
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(ByVal disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.components = New System.ComponentModel.Container()
			Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MapTutorial))
			Me.imageList1 = New System.Windows.Forms.ImageList(Me.components)
			Me.splitter1 = New System.Windows.Forms.Splitter()
			Me.dataGridView1 = New System.Windows.Forms.DataGridView()
			Me.splitter3 = New System.Windows.Forms.Splitter()
			Me.toolStrip1 = New System.Windows.Forms.ToolStrip()
			Me.map1 = New ActualMap.Windows.Map()
			Me.zoomFull = New System.Windows.Forms.ToolStripButton()
			Me.zoomInTool = New System.Windows.Forms.ToolStripButton()
			Me.zoomOutTool = New System.Windows.Forms.ToolStripButton()
			Me.panTool = New System.Windows.Forms.ToolStripButton()
			Me.infoTool = New System.Windows.Forms.ToolStripButton()
			CType(Me.dataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
			Me.toolStrip1.SuspendLayout()
			Me.SuspendLayout()
			' 
			' imageList1
			' 
			Me.imageList1.ImageStream = (CType(resources.GetObject("imageList1.ImageStream"), System.Windows.Forms.ImageListStreamer))
			Me.imageList1.TransparentColor = System.Drawing.Color.Transparent
			Me.imageList1.Images.SetKeyName(0, "")
			Me.imageList1.Images.SetKeyName(1, "")
			Me.imageList1.Images.SetKeyName(2, "")
			Me.imageList1.Images.SetKeyName(3, "")
			Me.imageList1.Images.SetKeyName(4, "")
			Me.imageList1.Images.SetKeyName(5, "")
			Me.imageList1.Images.SetKeyName(6, "")
			Me.imageList1.Images.SetKeyName(7, "")
			Me.imageList1.Images.SetKeyName(8, "")
			Me.imageList1.Images.SetKeyName(9, "")
			Me.imageList1.Images.SetKeyName(10, "")
			Me.imageList1.Images.SetKeyName(11, "")
			Me.imageList1.Images.SetKeyName(12, "")
			Me.imageList1.Images.SetKeyName(13, "clear.gif")
			' 
			' splitter1
			' 
			Me.splitter1.Dock = System.Windows.Forms.DockStyle.Right
			Me.splitter1.Location = New System.Drawing.Point(876, 0)
			Me.splitter1.Name = "splitter1"
			Me.splitter1.Size = New System.Drawing.Size(3, 499)
			Me.splitter1.TabIndex = 12
			Me.splitter1.TabStop = False
			' 
			' dataGridView1
			' 
			Me.dataGridView1.Dock = System.Windows.Forms.DockStyle.Bottom
			Me.dataGridView1.Location = New System.Drawing.Point(0, 388)
			Me.dataGridView1.Name = "dataGridView1"
			Me.dataGridView1.RowHeadersVisible = False
			Me.dataGridView1.Size = New System.Drawing.Size(876, 111)
			Me.dataGridView1.TabIndex = 13
			' 
			' splitter3
			' 
			Me.splitter3.Dock = System.Windows.Forms.DockStyle.Bottom
			Me.splitter3.Location = New System.Drawing.Point(0, 385)
			Me.splitter3.Name = "splitter3"
			Me.splitter3.Size = New System.Drawing.Size(876, 3)
			Me.splitter3.TabIndex = 14
			Me.splitter3.TabStop = False
			' 
			' toolStrip1
			' 
			Me.toolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() { Me.zoomFull, Me.zoomInTool, Me.zoomOutTool, Me.panTool, Me.infoTool})
			Me.toolStrip1.Location = New System.Drawing.Point(0, 0)
			Me.toolStrip1.Name = "toolStrip1"
			Me.toolStrip1.Size = New System.Drawing.Size(876, 25)
			Me.toolStrip1.TabIndex = 16
			Me.toolStrip1.Text = "toolStrip1"
			' 
			' map1
			' 
			Me.map1.BackColor = System.Drawing.Color.White
			Me.map1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
			Me.map1.Dock = System.Windows.Forms.DockStyle.Fill
			Me.map1.FontQuality = ActualMap.FontQuality.Default
			Me.map1.Location = New System.Drawing.Point(0, 25)
			Me.map1.MapTool = ActualMap.Windows.MapTool.ZoomIn
			Me.map1.MapUnit = ActualMap.MeasureUnit.Degree
			Me.map1.Name = "map1"
			Me.map1.PixelPerInch = 96
			Me.map1.ScaleBar.BarUnit = ActualMap.UnitSystem.Imperial
			Me.map1.ScaleBar.FeetString = "ft"
			Me.map1.ScaleBar.Font.Alignment = ActualMap.TextAlign.Left
			Me.map1.ScaleBar.Font.Bold = False
			Me.map1.ScaleBar.Font.Charset = 1
			Me.map1.ScaleBar.Font.Color = System.Drawing.Color.FromArgb((CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))))
			Me.map1.ScaleBar.Font.Italic = False
			Me.map1.ScaleBar.Font.Name = "Arial"
			Me.map1.ScaleBar.Font.Outline = False
			Me.map1.ScaleBar.Font.OutlineColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
			Me.map1.ScaleBar.Font.Size = 12
			Me.map1.ScaleBar.Font.StrikeThrough = False
			Me.map1.ScaleBar.Font.Underline = False
			Me.map1.ScaleBar.KilometersString = "km"
			Me.map1.ScaleBar.MaxWidth = 0
			Me.map1.ScaleBar.MetersString = "m"
			Me.map1.ScaleBar.MilesString = "mi"
			Me.map1.ScaleBar.Position = ActualMap.ScaleBarPosition.BottomRight
			Me.map1.ScaleBar.Symbol.Bitmap = ""
			Me.map1.ScaleBar.Symbol.FillColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
			Me.map1.ScaleBar.Symbol.FillStyle = ActualMap.FillStyle.Solid
			Me.map1.ScaleBar.Symbol.InnerColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))), (CInt(Fix((CByte(255))))))
			Me.map1.ScaleBar.Symbol.LineColor = System.Drawing.Color.FromArgb((CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))), (CInt(Fix((CByte(0))))))
			Me.map1.ScaleBar.Symbol.LineStyle = ActualMap.LineStyle.Solid
			Me.map1.ScaleBar.Symbol.PointStyle = ActualMap.PointStyle.Circle
			Me.map1.ScaleBar.Symbol.Size = 1
			Me.map1.ScaleBar.Symbol.TransparentColor = System.Drawing.Color.Empty
			Me.map1.ScaleBar.Visible = False
			Me.map1.Size = New System.Drawing.Size(876, 360)
			Me.map1.SmoothingMode = ActualMap.SmoothingMode.None
			Me.map1.TabIndex = 17
			Me.map1.ToolShape.FillColor = System.Drawing.Color.Transparent
			Me.map1.ToolShape.LineColor = System.Drawing.Color.Red
'			Me.map1.InfoTool += New ActualMap.Windows.InfoToolEventHandler(Me.map1_InfoTool);
			' 
			' zoomFull
			' 
			Me.zoomFull.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
			Me.zoomFull.Image = (CType(resources.GetObject("zoomFull.Image"), System.Drawing.Image))
			Me.zoomFull.ImageTransparentColor = System.Drawing.Color.Magenta
			Me.zoomFull.Name = "zoomFull"
			Me.zoomFull.Size = New System.Drawing.Size(23, 22)
			Me.zoomFull.Text = "toolStripButton1"
'			Me.zoomFull.Click += New System.EventHandler(Me.zoomFull_Click);
			' 
			' zoomInTool
			' 
			Me.zoomInTool.Checked = True
			Me.zoomInTool.CheckState = System.Windows.Forms.CheckState.Checked
			Me.zoomInTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
			Me.zoomInTool.Image = (CType(resources.GetObject("zoomInTool.Image"), System.Drawing.Image))
			Me.zoomInTool.ImageTransparentColor = System.Drawing.Color.Magenta
			Me.zoomInTool.Name = "zoomInTool"
			Me.zoomInTool.Size = New System.Drawing.Size(23, 22)
			Me.zoomInTool.Text = "toolStripButton1"
'			Me.zoomInTool.Click += New System.EventHandler(Me.zoomInTool_Click);
			' 
			' zoomOutTool
			' 
			Me.zoomOutTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
			Me.zoomOutTool.Image = (CType(resources.GetObject("zoomOutTool.Image"), System.Drawing.Image))
			Me.zoomOutTool.ImageTransparentColor = System.Drawing.Color.Magenta
			Me.zoomOutTool.Name = "zoomOutTool"
			Me.zoomOutTool.Size = New System.Drawing.Size(23, 22)
			Me.zoomOutTool.Text = "toolStripButton1"
'			Me.zoomOutTool.Click += New System.EventHandler(Me.zoomOutTool_Click);
			' 
			' panTool
			' 
			Me.panTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
			Me.panTool.Image = (CType(resources.GetObject("panTool.Image"), System.Drawing.Image))
			Me.panTool.ImageTransparentColor = System.Drawing.Color.Magenta
			Me.panTool.Name = "panTool"
			Me.panTool.Size = New System.Drawing.Size(23, 22)
			Me.panTool.Text = "toolStripButton1"
'			Me.panTool.Click += New System.EventHandler(Me.panTool_Click);
			' 
			' infoTool
			' 
			Me.infoTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
			Me.infoTool.Image = (CType(resources.GetObject("infoTool.Image"), System.Drawing.Image))
			Me.infoTool.ImageTransparentColor = System.Drawing.Color.Magenta
			Me.infoTool.Name = "infoTool"
			Me.infoTool.Size = New System.Drawing.Size(23, 22)
			Me.infoTool.Text = "toolStripButton1"
'			Me.infoTool.Click += New System.EventHandler(Me.infoTool_Click);
			' 
			' MapTutorial
			' 
			Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
			Me.BackColor = System.Drawing.SystemColors.Control
			Me.ClientSize = New System.Drawing.Size(879, 499)
			Me.Controls.Add(Me.map1)
			Me.Controls.Add(Me.toolStrip1)
			Me.Controls.Add(Me.splitter3)
			Me.Controls.Add(Me.dataGridView1)
			Me.Controls.Add(Me.splitter1)
			Me.Name = "MapTutorial"
			Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
			Me.Text = "Map Tutorial"
'			Me.Load += New System.EventHandler(Me.Form1_Load);
			CType(Me.dataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
			Me.toolStrip1.ResumeLayout(False)
			Me.toolStrip1.PerformLayout()
			Me.ResumeLayout(False)
			Me.PerformLayout()

		End Sub

		#End Region

		Private imageList1 As System.Windows.Forms.ImageList
		Private splitter1 As System.Windows.Forms.Splitter
		Private splitter3 As System.Windows.Forms.Splitter
		Private dataGridView1 As System.Windows.Forms.DataGridView
		Private toolStrip1 As ToolStrip
		Private WithEvents map1 As Map
		Private WithEvents zoomFull As ToolStripButton
		Private WithEvents zoomInTool As ToolStripButton
		Private WithEvents zoomOutTool As ToolStripButton
		Private WithEvents panTool As ToolStripButton
		Private WithEvents infoTool As ToolStripButton

	End Class
End Namespace