Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Data.OleDb
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports ActualMap
Imports ActualMap.Data
Imports ActualMap.Windows

Namespace SampleApps
	Partial Public Class Airports
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub

		Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
			AddMapLayers()
			AddDatabase()
		End Sub

		Private Sub AddDatabase()
            Dim SymbolFolder As String = Application.StartupPath & "\..\..\SYMBOLS\"

            Dim dataFile As String = Application.StartupPath & "\..\..\DATA\airports.mdb"
            Dim connectionString As String = "PROVIDER=Microsoft.Jet.OLEDB.4.0;DATA Source=" & dataFile

            Dim pointData As PointDataLayer = New PointDataLayer("System.Data.OleDb", connectionString, "airports", "LONGITUDE", "LATITUDE")

            Dim dbLayer As Layer = map1.AddLayer(pointData)
			If dbLayer Is Nothing Then
				MessageBox.Show("Cannot add airports.mdb database.")
				Return
			End If

			dbLayer.Name = "database"
			dbLayer.Symbol.Size = 16 ' default symbol size

			' render airports depenfing on the value of the AVAILABLE field
			dbLayer.Renderer.Field = "AVAILABLE"

			' available airports
			Dim feature As Feature = dbLayer.Renderer.Add()
			feature.Value = "Yes"
			feature.Symbol.Size = 16
            feature.Symbol.PointStyle = ActualMap.PointStyle.Bitmap
			feature.Symbol.Bitmap = SymbolFolder & "airport.bmp"
			feature.LabelFont.Color = Color.Green
			feature.LabelFont.Bold = True

			' closed airports
			feature = dbLayer.Renderer.Add()
			feature.Value = "No"
			feature.Symbol.Size = 16
            feature.Symbol.PointStyle = ActualMap.PointStyle.Bitmap
			feature.Symbol.Bitmap = SymbolFolder & "airport_closed.bmp"
			feature.LabelFont.Color = Color.Red
			feature.LabelFont.Bold = True
		End Sub

		Private Sub AddMapLayers()
			Dim layer As Layer
			Dim feature As Feature
			Dim renderer As FeatureRenderer

			Dim LayerFolder As String = Application.StartupPath & "\..\..\MAPS\USA\"

			'- STATES -------------------------------------------
			layer = map1.AddLayer(LayerFolder & "states.shp")

			layer.LabelField = "STATE_ABBR"
			layer.ShowLabels = True
			layer.LabelFont.Name = "Verdana"
			layer.LabelFont.Size = 12
			layer.LabelFont.Bold = True
            layer.LabelStyle = ActualMap.LabelStyle.PolygonCenter

			'- ROADS -------------------------------------------
			layer = map1.AddLayer(LayerFolder & "roads.shp")

			' default symbol
			layer.LabelField = "NUMBER"
			layer.ShowLabels = True
			layer.DuplicateLabels = False
			layer.LabelFont.Size = 12
			layer.Symbol.LineColor = Color.FromArgb(255, 0, 0)
			layer.Symbol.Size = 2

			'- CITIES --------------------------------------------
			layer = map1.AddLayer(LayerFolder & "cities.shp")

			layer.LabelField = "CITY_NAME"
			layer.ShowLabels = True

			' render state capitals only
			layer.UseDefaultSymbol = False
			renderer = map1("cities").Renderer
			feature = renderer.Add()
			feature.Expression = "CAPITAL = ""Y"""
            feature.Symbol.PointStyle = ActualMap.PointStyle.CircleWithLargeCenter
			feature.Symbol.Size = 10
			feature.Symbol.FillColor = Color.FromArgb(255, 255, 0)
			feature.LabelFont.Name = "Arial"
			feature.LabelFont.Bold = True
			feature.LabelFont.Size = 14
			feature.LabelFont.Outline = True
			feature.LabelFont.OutlineColor = Color.FromArgb(255, 255, 0)
		End Sub

		Private SymbolFolder As String = Application.StartupPath & "\..\..\SYMBOLS\"

		Private Sub toolBar_ButtonClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles toolBar.ButtonClick
			If e.Button.Style = ToolBarButtonStyle.ToggleButton Then
				For Each b As ToolBarButton In toolBar.Buttons
				b.Pushed = False
				Next b
				e.Button.Pushed = True
			End If

			If e.Button Is zoomFull Then
				map1.ZoomFull()
				map1.Refresh()
			End If
			If e.Button Is clearShapes Then
				map1.MapShapes.Clear()
				map1.Callouts.Clear()
				dataGrid.DataSource = Nothing
				dataGrid.CaptionText = String.Empty
				map1.Refresh()
			ElseIf e.Button Is zoomInTool Then
			map1.MapTool = MapTool.ZoomIn
			ElseIf e.Button Is zoomOutTool Then
			map1.MapTool = MapTool.ZoomOut
			ElseIf e.Button Is panTool Then
			map1.MapTool = MapTool.Pan
			ElseIf e.Button Is centerTool Then
			map1.MapTool = MapTool.Center
			ElseIf e.Button Is infoTool Then
			map1.MapTool = MapTool.Info
			End If
		End Sub

		Private Sub map1_InfoTool(ByVal sender As Object, ByVal e As ActualMap.Windows.InfoToolEventArgs) Handles map1.InfoTool
			map1.Callouts.Clear()
			dataGrid.DataSource = Nothing

			Dim records As ActualMap.Recordset = map1("database").SearchByDistance(e.InfoPoint, map1.ToMapDistance(6))

			If (Not records.EOF) Then
				dataGrid.DataSource = records
				dataGrid.CaptionText = records.Layer.Name

				Dim callout As Callout = map1.Callouts.Add()
				callout.X = e.InfoPoint.X
				callout.Y = e.InfoPoint.Y
				callout.Text = records("DESCRIP").ToString()
				callout.Font.Size = 16
			End If

			map1.Refresh()
		End Sub

		Private Sub menuItem2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles menuItem2.Click
			printPreview.ShowDialog()
		End Sub

		Private Sub printDocument_PrintPage(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles printDocument.PrintPage
			Dim mapImage As Bitmap = map1.GetBitmap(700, 600)
			e.Graphics.DrawImageUnscaled(mapImage, 50, 50)
		End Sub
	End Class
End Namespace