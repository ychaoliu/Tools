using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using ActualMap;
using ActualMap.Windows;

namespace SampleApps
{
    partial class ProjectedWorldMap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.statusBar1 = new System.Windows.Forms.StatusBar();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.coordSystemList = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.dataGrid = new System.Windows.Forms.DataGrid();
            this.splitter3 = new System.Windows.Forms.Splitter();
            this.map1 = new ActualMap.Windows.Map();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // statusBar1
            // 
            this.statusBar1.Location = new System.Drawing.Point(0, 477);
            this.statusBar1.Name = "statusBar1";
            this.statusBar1.Size = new System.Drawing.Size(879, 22);
            this.statusBar1.TabIndex = 10;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(711, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(168, 477);
            this.panel1.TabIndex = 11;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.coordSystemList);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(168, 477);
            this.panel2.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 13);
            this.label1.TabIndex = 22;
            this.label1.Text = "Coordinate System:";
            // 
            // coordSystemList
            // 
            this.coordSystemList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.coordSystemList.FormattingEnabled = true;
            this.coordSystemList.Location = new System.Drawing.Point(6, 28);
            this.coordSystemList.Name = "coordSystemList";
            this.coordSystemList.Size = new System.Drawing.Size(150, 21);
            this.coordSystemList.TabIndex = 21;
            this.coordSystemList.SelectedIndexChanged += new System.EventHandler(this.coordSystemList_SelectedIndexChanged);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Info;
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.textBox1.Location = new System.Drawing.Point(0, 366);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(168, 111);
            this.textBox1.TabIndex = 20;
            this.textBox1.TabStop = false;
            this.textBox1.Text = "This sample uses a CoordSystem object to project a world map into various coordin" +
                "ate systems.";
            // 
            // splitter1
            // 
            this.splitter1.Dock = System.Windows.Forms.DockStyle.Right;
            this.splitter1.Location = new System.Drawing.Point(708, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 477);
            this.splitter1.TabIndex = 12;
            this.splitter1.TabStop = false;
            // 
            // dataGrid
            // 
            this.dataGrid.DataMember = "";
            this.dataGrid.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dataGrid.Location = new System.Drawing.Point(0, 366);
            this.dataGrid.Name = "dataGrid";
            this.dataGrid.RowHeadersVisible = false;
            this.dataGrid.Size = new System.Drawing.Size(708, 111);
            this.dataGrid.TabIndex = 13;
            // 
            // splitter3
            // 
            this.splitter3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter3.Location = new System.Drawing.Point(0, 363);
            this.splitter3.Name = "splitter3";
            this.splitter3.Size = new System.Drawing.Size(708, 3);
            this.splitter3.TabIndex = 14;
            this.splitter3.TabStop = false;
            // 
            // map1
            // 
            this.map1.BackColor = System.Drawing.Color.White;
            this.map1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.map1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.map1.FontQuality = ActualMap.FontQuality.ClearType;
            this.map1.Location = new System.Drawing.Point(0, 0);
            this.map1.MapTool = ActualMap.Windows.MapTool.ZoomIn;
            this.map1.MapUnit = ActualMap.MeasureUnit.Degree;
            this.map1.Name = "map1";
            this.map1.PixelPerInch = 96;
            this.map1.ScaleBar.BarUnit = ActualMap.UnitSystem.Imperial;
            this.map1.ScaleBar.FeetString = "ft";
            this.map1.ScaleBar.Font.Alignment = ActualMap.TextAlign.Left;
            this.map1.ScaleBar.Font.Bold = false;
            this.map1.ScaleBar.Font.Charset = 1;
            this.map1.ScaleBar.Font.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.map1.ScaleBar.Font.Italic = false;
            this.map1.ScaleBar.Font.Name = "Arial";
            this.map1.ScaleBar.Font.Outline = false;
            this.map1.ScaleBar.Font.OutlineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Font.Size = 12;
            this.map1.ScaleBar.Font.StrikeThrough = false;
            this.map1.ScaleBar.Font.Underline = false;
            this.map1.ScaleBar.KilometersString = "km";
            this.map1.ScaleBar.MaxWidth = 0;
            this.map1.ScaleBar.MetersString = "m";
            this.map1.ScaleBar.MilesString = "mi";
            this.map1.ScaleBar.Position = ActualMap.ScaleBarPosition.BottomRight;
            this.map1.ScaleBar.Symbol.Bitmap = "";
            this.map1.ScaleBar.Symbol.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Symbol.FillStyle = ActualMap.FillStyle.Solid;
            this.map1.ScaleBar.Symbol.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Symbol.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.map1.ScaleBar.Symbol.LineStyle = ActualMap.LineStyle.Solid;
            this.map1.ScaleBar.Symbol.PointStyle = ActualMap.PointStyle.Circle;
            this.map1.ScaleBar.Symbol.Size = 1;
            this.map1.ScaleBar.Symbol.TransparentColor = System.Drawing.Color.Empty;
            this.map1.ScaleBar.Visible = true;
            this.map1.Size = new System.Drawing.Size(708, 363);
            this.map1.SmoothingMode = ActualMap.SmoothingMode.None;
            this.map1.TabIndex = 15;
            this.map1.ToolShape.FillColor = System.Drawing.Color.Silver;
            this.map1.ToolShape.LineColor = System.Drawing.Color.Red;
            // 
            // ProjectedWorldMap
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(879, 499);
            this.Controls.Add(this.map1);
            this.Controls.Add(this.splitter3);
            this.Controls.Add(this.dataGrid);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusBar1);
            this.Name = "ProjectedWorldMap";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "Projected World Map";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Splitter splitter1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Splitter splitter3;
		private ActualMap.Windows.Map map1;
        private System.Windows.Forms.DataGrid dataGrid;
        private TextBox textBox1;
        private Label label1;
        private ComboBox coordSystemList;

    }
}