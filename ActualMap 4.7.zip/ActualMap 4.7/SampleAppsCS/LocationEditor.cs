using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ActualMap;
using ActualMap.Data;
using ActualMap.Windows;

namespace SampleApps
{
    public partial class LocationEditor : Form
    {
        string locationID = null;

        public LocationEditor()
        {
            InitializeComponent();
        }

		private void Form1_Load(object sender, System.EventArgs e)
		{
            AddMapLayers();
            AddLocationsDatabase();
		}

        private void map1_PanToolClick(object sender, PanToolClickEventArgs e)
        {
            RestoreState();

            Recordset rs = map1["locations"].SearchNearest(e.Point, map1.ToMapDistance(8));

            if (rs.EOF)
            {
                // add new location
                map1.EditShape(e.Point);
            }
            else
            {
                // edit the location
                locationTitle.Text = rs["TITLE"].ToString();
                locationID = rs["ID"].ToString();
                remove.Visible = true;
                operation.Text = "Edit location:";

                map1.EditShape(rs.Shape);
            }

            map1.Refresh();
            locationPanel.Visible = true;
        }

        private void save_Click(object sender, EventArgs e)
        {
            if (!map1.IsEdit) return;

            if (locationID != null)
            {
                // update location
                UpdateLocation(locationID, locationTitle.Text, map1.GetEditedShape());
            }
            else
            {
                // add new location
                AddNewLocation(locationTitle.Text, map1.GetEditedShape());
            }

            RestoreState();
            map1.Refresh();
        }

        private void remove_Click(object sender, EventArgs e)
        {
            if (locationID != null)
            {
                RemoveLocation(locationID);
                RestoreState();
                map1.Refresh();
            }
        }

        void AddNewLocation(string title, Shape shape)
        {
            Layer layer = map1["locations"];

            Recordset rs = layer.NewRecord();

            if (!rs.EOF)
            {
                rs["TITLE"] = title;
                rs.Shape = shape;
                rs.Update();
            }
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            RestoreState();
            map1.Refresh();
        }

        void UpdateLocation(string id, string title, Shape shape)
        {
            Layer layer = map1["locations"];
            layer.EnablePassthroughQuery = true;

            Recordset rs = layer.SearchExpression("ID = " + id + "");

            if (!rs.EOF)
            {
                rs["TITLE"] = title;
                rs.Shape = shape;
                rs.Update();
            }
        }

        void RemoveLocation(string id)
        {
            Layer layer = map1["locations"];
            layer.EnablePassthroughQuery = true;

            Recordset rs = layer.SearchExpression("ID = " + id + "");

            if (!rs.EOF)
            {
                rs.Delete();
            }        
        }

        void AddLocationsDatabase()
        {
            string connectionString = "PROVIDER=Microsoft.Jet.OLEDB.4.0;DATA Source=" + 
                Application.StartupPath + @"\..\..\DATA\locations.mdb";

            PointDataLayer pointData = new PointDataLayer("System.Data.OleDb", connectionString, "locations", "LONGITUDE", "LATITUDE");

            Layer dbLayer = map1.AddLayer(pointData);

            if (dbLayer == null)
            {
                MessageBox.Show("Cannot add locations.mdb database.");
                return;
            }

            dbLayer.Name = "locations";
            dbLayer.Symbol.FillColor = Color.LightGreen;
            dbLayer.Symbol.LineColor = Color.Gray;
            dbLayer.Symbol.Size = 11;
            dbLayer.ShowLabels = true;
            dbLayer.LabelField = "TITLE";
            dbLayer.LabelFont.Name = "Verdana";
            dbLayer.LabelFont.Size = 14;
            dbLayer.LabelFont.Color = Color.White;
            dbLayer.LabelFont.OutlineColor = Color.Black;
            dbLayer.LabelFont.Outline = true;
        }

        protected void RestoreState()
        {
            map1.CancelEdit();
            locationPanel.Visible = false;
            locationID = null;
            remove.Visible = false;
            operation.Text = "Add location:";
        }

		private void AddMapLayers()
		{
            string LayerFolder = Application.StartupPath + @"\..\..\MAPS\WORLD\";
                                           
            Layer layer = map1.AddLayer(LayerFolder + "world.shp");
            layer.Symbol.LineColor = Color.Gray;
		}

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            map1.ZoomFull();
            map1.Refresh();
        }

	}
}