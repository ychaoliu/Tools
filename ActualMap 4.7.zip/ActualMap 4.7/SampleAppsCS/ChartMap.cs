using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ActualMap;
using ActualMap.Windows;

namespace SampleApps
{
    public partial class ChartMap : Form
    {
        public ChartMap()
        {
            InitializeComponent();
        }

		private void Form1_Load(object sender, System.EventArgs e)
		{
            AddMapLayers();

            chartType.SelectedIndex = 0;
            
            DoThematicMapping();                       
		}

        void DoThematicMapping()
        {
            ActualMap.Layer layer = map1["USA"];
            ActualMap.ChartRenderer chartRenderer = layer.ChartRenderer;
            
            chartRenderer.Clear();

            // population 1990
            chartRenderer.Add("POP1990", Color.Red);
            // population 1997
            chartRenderer.Add("POP1997", Color.Green);

            if (chartType.SelectedItem.ToString() == "Bar")
            {
                chartRenderer.ChartType = ActualMap.ChartType.Bar;
                chartRenderer.BarHeight = 40;
                chartRenderer.BarWidth = 30;
            }
            else // Pie
            {
                chartRenderer.ChartType = ActualMap.ChartType.Pie;
                chartRenderer.MinPieSize = 40;
                chartRenderer.MaxPieSize = 60;
            }

            chartRenderer.OutlineColor = Color.Black;
            chartRenderer.OutlineWidth = 1;

            // populate the legend
            legend1.Clear();

            foreach (ChartItem item in chartRenderer)
            {
                legend1.Add(item.Field, chartRenderer.OutlineColor, item.FillColor);
            }
            
            map1.Refresh();
        }

		private void AddMapLayers()
		{
            ActualMap.DataSource dataSource = new ActualMap.DataSource();
            string LayerFolder = Application.StartupPath + @"\..\..\MAPS\USA\";

            ActualMap.Layer layer = map1.AddLayer(LayerFolder + "USA.shp");

            layer.ShowLabels = true;
            layer.LabelField = "STATE_ABBR";
            layer.LabelStyle = LabelStyle.PolygonCenter;

            string dataFile = Application.StartupPath + @"\..\..\DATA\demography.mdb";

            dataSource.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + dataFile;
            dataSource.CommandText = "SELECT * FROM demography";

            // create a relation between the USA shapefile and the 
            // database by the state abbreviation field
            if (!map1["USA"].AddRelate("STATE_ABBR", dataSource, "STATE_ABBR"))
            {
                MessageBox.Show("Cannot add a relate to the database: " + dataFile);
            }
		}

        private void chartType_SelectedIndexChanged(object sender, EventArgs e)
        {
            DoThematicMapping();
        }       
	}
}