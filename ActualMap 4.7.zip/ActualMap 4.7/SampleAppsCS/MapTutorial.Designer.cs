using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using ActualMap;
using ActualMap.Windows;

namespace SampleApps
{
    partial class MapTutorial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MapTutorial));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.splitter3 = new System.Windows.Forms.Splitter();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.map1 = new ActualMap.Windows.Map();
            this.zoomFull = new System.Windows.Forms.ToolStripButton();
            this.zoomInTool = new System.Windows.Forms.ToolStripButton();
            this.zoomOutTool = new System.Windows.Forms.ToolStripButton();
            this.panTool = new System.Windows.Forms.ToolStripButton();
            this.infoTool = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "");
            this.imageList1.Images.SetKeyName(1, "");
            this.imageList1.Images.SetKeyName(2, "");
            this.imageList1.Images.SetKeyName(3, "");
            this.imageList1.Images.SetKeyName(4, "");
            this.imageList1.Images.SetKeyName(5, "");
            this.imageList1.Images.SetKeyName(6, "");
            this.imageList1.Images.SetKeyName(7, "");
            this.imageList1.Images.SetKeyName(8, "");
            this.imageList1.Images.SetKeyName(9, "");
            this.imageList1.Images.SetKeyName(10, "");
            this.imageList1.Images.SetKeyName(11, "");
            this.imageList1.Images.SetKeyName(12, "");
            this.imageList1.Images.SetKeyName(13, "clear.gif");
            // 
            // splitter1
            // 
            this.splitter1.Dock = System.Windows.Forms.DockStyle.Right;
            this.splitter1.Location = new System.Drawing.Point(876, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 499);
            this.splitter1.TabIndex = 12;
            this.splitter1.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridView1.Location = new System.Drawing.Point(0, 388);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.Size = new System.Drawing.Size(876, 111);
            this.dataGridView1.TabIndex = 13;
            // 
            // splitter3
            // 
            this.splitter3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter3.Location = new System.Drawing.Point(0, 385);
            this.splitter3.Name = "splitter3";
            this.splitter3.Size = new System.Drawing.Size(876, 3);
            this.splitter3.TabIndex = 14;
            this.splitter3.TabStop = false;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.zoomFull,
            this.zoomInTool,
            this.zoomOutTool,
            this.panTool,
            this.infoTool});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(876, 25);
            this.toolStrip1.TabIndex = 16;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // map1
            // 
            this.map1.BackColor = System.Drawing.Color.White;
            this.map1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.map1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.map1.FontQuality = ActualMap.FontQuality.Default;
            this.map1.Location = new System.Drawing.Point(0, 25);
            this.map1.MapTool = ActualMap.Windows.MapTool.ZoomIn;
            this.map1.MapUnit = ActualMap.MeasureUnit.Degree;
            this.map1.Name = "map1";
            this.map1.PixelPerInch = 96;
            this.map1.ScaleBar.BarUnit = ActualMap.UnitSystem.Imperial;
            this.map1.ScaleBar.FeetString = "ft";
            this.map1.ScaleBar.Font.Alignment = ActualMap.TextAlign.Left;
            this.map1.ScaleBar.Font.Bold = false;
            this.map1.ScaleBar.Font.Charset = 1;
            this.map1.ScaleBar.Font.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.map1.ScaleBar.Font.Italic = false;
            this.map1.ScaleBar.Font.Name = "Arial";
            this.map1.ScaleBar.Font.Outline = false;
            this.map1.ScaleBar.Font.OutlineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Font.Size = 12;
            this.map1.ScaleBar.Font.StrikeThrough = false;
            this.map1.ScaleBar.Font.Underline = false;
            this.map1.ScaleBar.KilometersString = "km";
            this.map1.ScaleBar.MaxWidth = 0;
            this.map1.ScaleBar.MetersString = "m";
            this.map1.ScaleBar.MilesString = "mi";
            this.map1.ScaleBar.Position = ActualMap.ScaleBarPosition.BottomRight;
            this.map1.ScaleBar.Symbol.Bitmap = "";
            this.map1.ScaleBar.Symbol.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Symbol.FillStyle = ActualMap.FillStyle.Solid;
            this.map1.ScaleBar.Symbol.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Symbol.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.map1.ScaleBar.Symbol.LineStyle = ActualMap.LineStyle.Solid;
            this.map1.ScaleBar.Symbol.PointStyle = ActualMap.PointStyle.Circle;
            this.map1.ScaleBar.Symbol.Size = 1;
            this.map1.ScaleBar.Symbol.TransparentColor = System.Drawing.Color.Empty;
            this.map1.ScaleBar.Visible = false;
            this.map1.Size = new System.Drawing.Size(876, 360);
            this.map1.SmoothingMode = ActualMap.SmoothingMode.None;
            this.map1.TabIndex = 17;
            this.map1.ToolShape.FillColor = System.Drawing.Color.Transparent;
            this.map1.ToolShape.LineColor = System.Drawing.Color.Red;
            this.map1.InfoTool += new ActualMap.Windows.InfoToolEventHandler(this.map1_InfoTool);
            // 
            // zoomFull
            // 
            this.zoomFull.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.zoomFull.Image = ((System.Drawing.Image)(resources.GetObject("zoomFull.Image")));
            this.zoomFull.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.zoomFull.Name = "zoomFull";
            this.zoomFull.Size = new System.Drawing.Size(23, 22);
            this.zoomFull.Text = "toolStripButton1";
            this.zoomFull.Click += new System.EventHandler(this.zoomFull_Click);
            // 
            // zoomInTool
            // 
            this.zoomInTool.Checked = true;
            this.zoomInTool.CheckState = System.Windows.Forms.CheckState.Checked;
            this.zoomInTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.zoomInTool.Image = ((System.Drawing.Image)(resources.GetObject("zoomInTool.Image")));
            this.zoomInTool.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.zoomInTool.Name = "zoomInTool";
            this.zoomInTool.Size = new System.Drawing.Size(23, 22);
            this.zoomInTool.Text = "toolStripButton1";
            this.zoomInTool.Click += new System.EventHandler(this.zoomInTool_Click);
            // 
            // zoomOutTool
            // 
            this.zoomOutTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.zoomOutTool.Image = ((System.Drawing.Image)(resources.GetObject("zoomOutTool.Image")));
            this.zoomOutTool.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.zoomOutTool.Name = "zoomOutTool";
            this.zoomOutTool.Size = new System.Drawing.Size(23, 22);
            this.zoomOutTool.Text = "toolStripButton1";
            this.zoomOutTool.Click += new System.EventHandler(this.zoomOutTool_Click);
            // 
            // panTool
            // 
            this.panTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.panTool.Image = ((System.Drawing.Image)(resources.GetObject("panTool.Image")));
            this.panTool.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.panTool.Name = "panTool";
            this.panTool.Size = new System.Drawing.Size(23, 22);
            this.panTool.Text = "toolStripButton1";
            this.panTool.Click += new System.EventHandler(this.panTool_Click);
            // 
            // infoTool
            // 
            this.infoTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.infoTool.Image = ((System.Drawing.Image)(resources.GetObject("infoTool.Image")));
            this.infoTool.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.infoTool.Name = "infoTool";
            this.infoTool.Size = new System.Drawing.Size(23, 22);
            this.infoTool.Text = "toolStripButton1";
            this.infoTool.Click += new System.EventHandler(this.infoTool_Click);
            // 
            // MapTutorial
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(879, 499);
            this.Controls.Add(this.map1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.splitter3);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.splitter1);
            this.Name = "MapTutorial";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "Map Tutorial";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Splitter splitter3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private ToolStrip toolStrip1;
        private Map map1;
        private ToolStripButton zoomFull;
        private ToolStripButton zoomInTool;
        private ToolStripButton zoomOutTool;
        private ToolStripButton panTool;
        private ToolStripButton infoTool;

    }
}