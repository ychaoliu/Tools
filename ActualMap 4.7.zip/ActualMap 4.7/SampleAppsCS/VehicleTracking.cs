using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.IO;
using System.Windows.Forms;
using ActualMap;
using ActualMap.Windows;

namespace SampleApps
{
    public partial class VehicleTracking : Form
    {
        int position = 0;

        public VehicleTracking()
        {
            InitializeComponent();
        }

		private void Form1_Load(object sender, System.EventArgs e)
		{
            AddMapLayers();
            map1.StartAnimation(1000);
		}

        private void startTracking_Click(object sender, EventArgs e)
        {
            map1.StartAnimation(1000);
        }

        private void stopTracking_Click(object sender, EventArgs e)
        {
            map1.StopAnimation();
        }

        private void map1_RefreshAnimationLayer(object sender, RefreshAnimationLayerArgs e)
        {
            TrackVehicles();
        }

        void TrackVehicles()
        {
            map1.AnimationLayer.Clear();

            ActualMap.Point vehicleLocation = GetVehicleCoordinates();

            GeoEvent geoEvent = new GeoEvent(vehicleLocation);

            geoEvent.Symbol.PointStyle = PointStyle.Bitmap;
            geoEvent.Symbol.Bitmap = Application.StartupPath + @"\..\..\SYMBOLS\vehicle.gif";
            geoEvent.Symbol.TransparentColor = Color.White;
            geoEvent.Symbol.Size = 20;
            geoEvent.Label = "Vehicle 1";

            map1.AnimationLayer.Add(geoEvent);
        }

        private void AddMapLayers()
        {
            Layer layer;

            string LayerFolder = Application.StartupPath + @"\..\..\MAPS\STREETS\";

            //- COUNTY -------------------------------------------
            layer = map1.AddLayer(LayerFolder + "County.shp");

            layer.LabelField = "NAME";
            layer.Symbol.Size = 2;
            layer.Symbol.LineColor = Color.FromArgb(199, 172, 116);
            layer.Symbol.FillColor = Color.FromArgb(242, 236, 223);

            //- STREETS ------------------------------------------
            layer = map1.AddLayer(LayerFolder + "Street.shp");

            layer.LabelField = "NAME";
            layer.LabelFont.Size = 10;
            layer.Symbol.Size = 3;
            layer.Symbol.LineStyle = LineStyle.Road;
            layer.Symbol.LineColor = Color.FromArgb(171, 158, 137);
            layer.Symbol.InnerColor = Color.White;
        }

        // For demostration purposes, obtains GPS coordinates (latitude/longitude) of the vehicle from a text file.
        ActualMap.Point GetVehicleCoordinates()
        {
            StreamReader reader = File.OpenText(Application.StartupPath + @"\..\..\DATA\vehicle_points.txt");

            string line;
            ActualMap.Points points = new ActualMap.Points();

            while ((line = reader.ReadLine()) != null)
            {
                string[] coords = line.Split(' ');
                points.Add(Convert.ToDouble(coords[0]), Convert.ToDouble(coords[1]));
            }

            reader.Close();

            if (position+1 >= points.Count)
                position = 0;
            else
	            position++;

            return points[position];
        }

		private void toolBar_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
            if (e.Button.Style == ToolBarButtonStyle.ToggleButton) 
			{
				foreach(ToolBarButton b in toolBar.Buttons) b.Pushed = false;
				e.Button.Pushed = true;
			}

			if (e.Button == zoomFull)
			{
				map1.ZoomFull();
				map1.Refresh();
			}
			else if (e.Button == zoomInTool)	map1.MapTool = MapTool.ZoomIn;
			else if (e.Button == zoomOutTool)	map1.MapTool = MapTool.ZoomOut;
			else if (e.Button == panTool)		map1.MapTool = MapTool.Pan;
		}
	}
}