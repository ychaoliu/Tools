using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ActualMap;
using ActualMap.Windows;

namespace SampleApps
{
    public partial class WMSLayer : Form
    {
        WmsLayer wmsLayer;

        public WMSLayer()
        {
            InitializeComponent();
        }

		private void Form1_Load(object sender, System.EventArgs e)
		{
            AddShapefileLayer();
            AddWmsLayer();
		}

        // add the WMS layer ( http://nationalatlas.gov/infodocs/wms_intro.html )
        private void AddWmsLayer()
        { 
            wmsLayer = new WmsLayer("http://webservices.nationalatlas.gov/wms",
                new ActualMap.Rectangle(-168.99, 70.2545,-55, 17.6895));
            wmsLayer.AddLayer("roads");
            wmsLayer.Transparent = true;
            wmsLayer.ImageFormat = ImageFormat.Png;

            map1.AddLayer(wmsLayer);
        }

        // search for features in the WMS layer
        private void map1_InfoTool(object sender, ActualMap.Windows.InfoToolEventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            map1.Callouts.Clear();

            try
            {               
                string info = map1.GetWmsFeatureInfo("http://webservices.nationalatlas.gov/wms",
                    "roads", e.InfoPoint, 1, "text/plain");

                if (info != null)
                {
                    Callout callout = map1.Callouts.Add();
                    callout.X = e.InfoPoint.X;
                    callout.Y = e.InfoPoint.Y;
                    callout.Text = info;
                    callout.Font.Size = 14;

                    map1.Refresh();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

		private void AddShapefileLayer()
		{
            Layer layer;
			
            string LayerFolder = Application.StartupPath + @"\..\..\MAPS\USA\";

            layer = map1.AddLayer(LayerFolder + "states.shp");

            layer.Symbol.Size = 1;
            layer.Symbol.LineColor = Color.FromArgb(199, 172, 116);
            layer.Symbol.FillColor = Color.FromArgb(242, 236, 223);
		}
        
		private void toolBar_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
            if (e.Button.Style == ToolBarButtonStyle.ToggleButton) 
			{
				foreach(ToolBarButton b in toolBar.Buttons) b.Pushed = false;
				e.Button.Pushed = true;
			}

            map1.Cursor = Cursors.Default;

			if (e.Button == zoomFull)
			{
				map1.ZoomFull();
				map1.Refresh();
			}
			else if (e.Button == zoomInTool)	map1.MapTool = MapTool.ZoomIn;
			else if (e.Button == zoomOutTool)	map1.MapTool = MapTool.ZoomOut;
            else if (e.Button == panTool)
            {
                map1.MapTool = MapTool.Pan;
                map1.Cursor = Cursors.SizeAll;
            }
			else if (e.Button == infoTool)		map1.MapTool = MapTool.Info;
            else if (e.Button == clearShapes)
            {
                map1.Callouts.Clear();
                map1.Refresh();
            }
		}

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			printPreview.ShowDialog();
		}

		private void printDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			Bitmap mapImage = map1.GetBitmap(700, 600);
			e.Graphics.DrawImageUnscaled(mapImage, 50, 50);
		}

        private String GetCalloutText(ActualMap.Recordset rs)
        {
            int index = rs.Fields.GetFieldIndex("NAME");
            if (index < 0) index = rs.Fields.GetFieldIndex(rs.Layer.LabelField);
            if (index < 0) index = 0;
            return rs[index].ToString();
        }

        private void map1_BeforeMapDraw(object sender, MapDrawEventArgs e)
        {
            Cursor = Cursors.WaitCursor;
        }

        private void map1_AfterMapDraw(object sender, MapDrawEventArgs e)
        {
            Cursor = Cursors.Default;
        }
	}
}