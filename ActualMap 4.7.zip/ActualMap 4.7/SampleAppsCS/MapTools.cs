using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using ActualMap;
using ActualMap.Windows;

namespace SampleApps
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class MapTools : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ToolBarButton zoomFull;
		private System.Windows.Forms.ToolBarButton sep;
		private System.Windows.Forms.ImageList toolImages;
		private System.Windows.Forms.ToolBarButton zoomInTool;
		private System.Windows.Forms.ToolBarButton zoomOutTool;
		private System.Windows.Forms.ToolBarButton panTool;
		private System.Windows.Forms.ToolBarButton centerTool;
		private System.Windows.Forms.ToolBarButton distanceTool;
		private System.Windows.Forms.ToolBarButton sep2;
		private System.Windows.Forms.ToolBarButton pointTool;
		private System.Windows.Forms.ToolBarButton rectangleTool;
		private System.Windows.Forms.ToolBarButton lineTool;
		private System.Windows.Forms.ToolBarButton polylineTool;
		private System.Windows.Forms.ToolBarButton circleTool;
		private System.Windows.Forms.ToolBarButton polygonTool;
		private System.Windows.Forms.ToolBar toolBar;
        private System.Windows.Forms.ToolBarButton infoTool;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Splitter splitter1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Splitter splitter3;
		private ActualMap.Windows.Map map1;
		private System.Windows.Forms.DataGrid dataGrid;
		private System.Windows.Forms.PrintPreviewDialog printPreview;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Drawing.Printing.PrintDocument printDocument;
        private ComboBox layerList;
        private Label label1;
        private TextBox textBox1;
        private ToolBarButton toolBarButton1;
        private ToolBarButton clearShapes;
        private Label distanceMi;
        private Label label2;
        private Label distanceKm;
		private System.ComponentModel.IContainer components;

		public MapTools()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MapTools));
            this.toolBar = new System.Windows.Forms.ToolBar();
            this.sep = new System.Windows.Forms.ToolBarButton();
            this.zoomFull = new System.Windows.Forms.ToolBarButton();
            this.zoomInTool = new System.Windows.Forms.ToolBarButton();
            this.zoomOutTool = new System.Windows.Forms.ToolBarButton();
            this.panTool = new System.Windows.Forms.ToolBarButton();
            this.centerTool = new System.Windows.Forms.ToolBarButton();
            this.distanceTool = new System.Windows.Forms.ToolBarButton();
            this.infoTool = new System.Windows.Forms.ToolBarButton();
            this.sep2 = new System.Windows.Forms.ToolBarButton();
            this.pointTool = new System.Windows.Forms.ToolBarButton();
            this.rectangleTool = new System.Windows.Forms.ToolBarButton();
            this.lineTool = new System.Windows.Forms.ToolBarButton();
            this.polylineTool = new System.Windows.Forms.ToolBarButton();
            this.circleTool = new System.Windows.Forms.ToolBarButton();
            this.polygonTool = new System.Windows.Forms.ToolBarButton();
            this.toolBarButton1 = new System.Windows.Forms.ToolBarButton();
            this.clearShapes = new System.Windows.Forms.ToolBarButton();
            this.toolImages = new System.Windows.Forms.ImageList(this.components);
            this.statusBar1 = new System.Windows.Forms.StatusBar();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.distanceKm = new System.Windows.Forms.Label();
            this.distanceMi = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.layerList = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.dataGrid = new System.Windows.Forms.DataGrid();
            this.splitter3 = new System.Windows.Forms.Splitter();
            this.map1 = new ActualMap.Windows.Map();
            this.printPreview = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument = new System.Drawing.Printing.PrintDocument();
            this.mainMenu1 = new System.Windows.Forms.MainMenu(this.components);
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.menuItem2 = new System.Windows.Forms.MenuItem();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // toolBar
            // 
            this.toolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
            this.toolBar.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
            this.sep,
            this.zoomFull,
            this.zoomInTool,
            this.zoomOutTool,
            this.panTool,
            this.centerTool,
            this.distanceTool,
            this.infoTool,
            this.sep2,
            this.pointTool,
            this.rectangleTool,
            this.lineTool,
            this.polylineTool,
            this.circleTool,
            this.polygonTool,
            this.toolBarButton1,
            this.clearShapes});
            this.toolBar.ButtonSize = new System.Drawing.Size(23, 21);
            this.toolBar.DropDownArrows = true;
            this.toolBar.ImageList = this.toolImages;
            this.toolBar.Location = new System.Drawing.Point(0, 0);
            this.toolBar.Name = "toolBar";
            this.toolBar.ShowToolTips = true;
            this.toolBar.Size = new System.Drawing.Size(994, 32);
            this.toolBar.TabIndex = 1;
            this.toolBar.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.toolBar_ButtonClick);
            // 
            // sep
            // 
            this.sep.Name = "sep";
            this.sep.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
            // 
            // zoomFull
            // 
            this.zoomFull.ImageIndex = 10;
            this.zoomFull.Name = "zoomFull";
            this.zoomFull.ToolTipText = "Zoom Full";
            // 
            // zoomInTool
            // 
            this.zoomInTool.ImageIndex = 11;
            this.zoomInTool.Name = "zoomInTool";
            this.zoomInTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.zoomInTool.Tag = "";
            this.zoomInTool.ToolTipText = "Zoom In";
            // 
            // zoomOutTool
            // 
            this.zoomOutTool.ImageIndex = 12;
            this.zoomOutTool.Name = "zoomOutTool";
            this.zoomOutTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.zoomOutTool.ToolTipText = "Zoom Out";
            // 
            // panTool
            // 
            this.panTool.ImageIndex = 5;
            this.panTool.Name = "panTool";
            this.panTool.Pushed = true;
            this.panTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.panTool.ToolTipText = "Pan";
            // 
            // centerTool
            // 
            this.centerTool.ImageIndex = 0;
            this.centerTool.Name = "centerTool";
            this.centerTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.centerTool.ToolTipText = "Center Map";
            // 
            // distanceTool
            // 
            this.distanceTool.ImageIndex = 2;
            this.distanceTool.Name = "distanceTool";
            this.distanceTool.ToolTipText = "Measure Distance";
            // 
            // infoTool
            // 
            this.infoTool.ImageIndex = 3;
            this.infoTool.Name = "infoTool";
            this.infoTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.infoTool.ToolTipText = "Identify";
            // 
            // sep2
            // 
            this.sep2.Name = "sep2";
            this.sep2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
            // 
            // pointTool
            // 
            this.pointTool.ImageIndex = 6;
            this.pointTool.Name = "pointTool";
            this.pointTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.pointTool.ToolTipText = "Point Tool";
            // 
            // rectangleTool
            // 
            this.rectangleTool.ImageIndex = 9;
            this.rectangleTool.Name = "rectangleTool";
            this.rectangleTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.rectangleTool.ToolTipText = "Rectangle Tool";
            // 
            // lineTool
            // 
            this.lineTool.ImageIndex = 4;
            this.lineTool.Name = "lineTool";
            this.lineTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.lineTool.ToolTipText = "Line Tool";
            // 
            // polylineTool
            // 
            this.polylineTool.ImageIndex = 8;
            this.polylineTool.Name = "polylineTool";
            this.polylineTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.polylineTool.ToolTipText = "Polyline Tool";
            // 
            // circleTool
            // 
            this.circleTool.ImageIndex = 1;
            this.circleTool.Name = "circleTool";
            this.circleTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.circleTool.ToolTipText = "Circle Tool";
            // 
            // polygonTool
            // 
            this.polygonTool.ImageIndex = 7;
            this.polygonTool.Name = "polygonTool";
            this.polygonTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.polygonTool.ToolTipText = "Polygon Tool";
            // 
            // toolBarButton1
            // 
            this.toolBarButton1.Name = "toolBarButton1";
            this.toolBarButton1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
            // 
            // clearShapes
            // 
            this.clearShapes.ImageIndex = 13;
            this.clearShapes.Name = "clearShapes";
            this.clearShapes.ToolTipText = "Clear Shapes";
            // 
            // toolImages
            // 
            this.toolImages.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("toolImages.ImageStream")));
            this.toolImages.TransparentColor = System.Drawing.Color.Transparent;
            this.toolImages.Images.SetKeyName(0, "");
            this.toolImages.Images.SetKeyName(1, "");
            this.toolImages.Images.SetKeyName(2, "");
            this.toolImages.Images.SetKeyName(3, "");
            this.toolImages.Images.SetKeyName(4, "");
            this.toolImages.Images.SetKeyName(5, "");
            this.toolImages.Images.SetKeyName(6, "");
            this.toolImages.Images.SetKeyName(7, "");
            this.toolImages.Images.SetKeyName(8, "");
            this.toolImages.Images.SetKeyName(9, "");
            this.toolImages.Images.SetKeyName(10, "");
            this.toolImages.Images.SetKeyName(11, "");
            this.toolImages.Images.SetKeyName(12, "");
            this.toolImages.Images.SetKeyName(13, "clear.gif");
            // 
            // statusBar1
            // 
            this.statusBar1.Location = new System.Drawing.Point(0, 575);
            this.statusBar1.Name = "statusBar1";
            this.statusBar1.Size = new System.Drawing.Size(994, 26);
            this.statusBar1.TabIndex = 10;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(792, 32);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(202, 543);
            this.panel1.TabIndex = 11;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.distanceKm);
            this.panel2.Controls.Add(this.distanceMi);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.layerList);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(202, 543);
            this.panel2.TabIndex = 2;
            // 
            // distanceKm
            // 
            this.distanceKm.Location = new System.Drawing.Point(11, 150);
            this.distanceKm.Name = "distanceKm";
            this.distanceKm.Size = new System.Drawing.Size(176, 27);
            this.distanceKm.TabIndex = 23;
            this.distanceKm.Text = "kilometers";
            // 
            // distanceMi
            // 
            this.distanceMi.Location = new System.Drawing.Point(11, 123);
            this.distanceMi.Name = "distanceMi";
            this.distanceMi.Size = new System.Drawing.Size(176, 27);
            this.distanceMi.TabIndex = 22;
            this.distanceMi.Text = "miles";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(7, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 17);
            this.label2.TabIndex = 21;
            this.label2.Text = "Distance:";
            // 
            // layerList
            // 
            this.layerList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.layerList.FormattingEnabled = true;
            this.layerList.Location = new System.Drawing.Point(11, 43);
            this.layerList.Name = "layerList";
            this.layerList.Size = new System.Drawing.Size(176, 24);
            this.layerList.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(7, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Active Layer:";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Info;
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.textBox1.Location = new System.Drawing.Point(0, 415);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(202, 128);
            this.textBox1.TabIndex = 20;
            this.textBox1.Text = "This sample demonstrates the built-in map tools and allows you to select map feat" +
                "ures by drawing points, lines, circles, rectangles or polygons directly on the m" +
                "ap.";
            // 
            // splitter1
            // 
            this.splitter1.Dock = System.Windows.Forms.DockStyle.Right;
            this.splitter1.Location = new System.Drawing.Point(789, 32);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 543);
            this.splitter1.TabIndex = 12;
            this.splitter1.TabStop = false;
            // 
            // dataGrid
            // 
            this.dataGrid.DataMember = "";
            this.dataGrid.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dataGrid.Location = new System.Drawing.Point(0, 447);
            this.dataGrid.Name = "dataGrid";
            this.dataGrid.RowHeadersVisible = false;
            this.dataGrid.Size = new System.Drawing.Size(789, 128);
            this.dataGrid.TabIndex = 13;
            // 
            // splitter3
            // 
            this.splitter3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter3.Location = new System.Drawing.Point(0, 444);
            this.splitter3.Name = "splitter3";
            this.splitter3.Size = new System.Drawing.Size(789, 3);
            this.splitter3.TabIndex = 14;
            this.splitter3.TabStop = false;
            // 
            // map1
            // 
            this.map1.BackColor = System.Drawing.Color.White;
            this.map1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.map1.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.map1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.map1.FontQuality = ActualMap.FontQuality.ClearType;
            this.map1.Location = new System.Drawing.Point(0, 32);
            this.map1.MapTool = ActualMap.Windows.MapTool.Pan;
            this.map1.MapUnit = ActualMap.MeasureUnit.Degree;
            this.map1.Name = "map1";
            this.map1.PixelPerInch = 96;
            this.map1.ScaleBar.BarUnit = ActualMap.UnitSystem.Imperial;
            this.map1.ScaleBar.FeetString = "ft";
            this.map1.ScaleBar.Font.Alignment = ActualMap.TextAlign.Left;
            this.map1.ScaleBar.Font.Bold = false;
            this.map1.ScaleBar.Font.Charset = 1;
            this.map1.ScaleBar.Font.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.map1.ScaleBar.Font.Italic = false;
            this.map1.ScaleBar.Font.Name = "Arial";
            this.map1.ScaleBar.Font.Outline = false;
            this.map1.ScaleBar.Font.OutlineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Font.Size = 12;
            this.map1.ScaleBar.Font.StrikeThrough = false;
            this.map1.ScaleBar.Font.Underline = false;
            this.map1.ScaleBar.KilometersString = "km";
            this.map1.ScaleBar.MaxWidth = 0;
            this.map1.ScaleBar.MetersString = "m";
            this.map1.ScaleBar.MilesString = "mi";
            this.map1.ScaleBar.Position = ActualMap.ScaleBarPosition.BottomRight;
            this.map1.ScaleBar.Symbol.Bitmap = "";
            this.map1.ScaleBar.Symbol.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Symbol.FillStyle = ActualMap.FillStyle.Solid;
            this.map1.ScaleBar.Symbol.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Symbol.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.map1.ScaleBar.Symbol.LineStyle = ActualMap.LineStyle.Solid;
            this.map1.ScaleBar.Symbol.PointStyle = ActualMap.PointStyle.Circle;
            this.map1.ScaleBar.Symbol.Rotation = 0;
            this.map1.ScaleBar.Symbol.Size = 1;
            this.map1.ScaleBar.Symbol.TransparentColor = System.Drawing.Color.Empty;
            this.map1.ScaleBar.Visible = true;
            this.map1.Size = new System.Drawing.Size(789, 412);
            this.map1.SmoothingMode = ActualMap.SmoothingMode.AntiAlias;
            this.map1.TabIndex = 15;
            this.map1.ToolShape.FillColor = System.Drawing.Color.Silver;
            this.map1.ToolShape.LineColor = System.Drawing.Color.Red;
            this.map1.PolylineToolFinished += new ActualMap.Windows.PolylineToolEventHandler(this.map1_PolylineToolFinished);
            this.map1.DistanceToolMove += new ActualMap.Windows.DistanceToolEventHandler(this.map1_DistanceToolMove);
            this.map1.PolygonToolFinished += new ActualMap.Windows.PolygonToolEventHandler(this.map1_PolygonToolFinished);
            this.map1.CircleToolFinished += new ActualMap.Windows.CircleToolEventHandler(this.map1_CircleToolFinished);
            this.map1.RectangleToolFinished += new ActualMap.Windows.RectangleToolEventHandler(this.map1_RectangleToolFinished);
            this.map1.LineToolFinished += new ActualMap.Windows.LineToolEventHandler(this.map1_LineToolFinished);
            this.map1.InfoTool += new ActualMap.Windows.InfoToolEventHandler(this.map1_InfoTool);
            this.map1.PointTool += new ActualMap.Windows.PointToolEventHandler(this.map1_PointTool);
            // 
            // printPreview
            // 
            this.printPreview.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreview.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreview.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreview.Document = this.printDocument;
            this.printPreview.Enabled = true;
            this.printPreview.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreview.Icon")));
            this.printPreview.Name = "printPreview";
            this.printPreview.Visible = false;
            // 
            // printDocument
            // 
            this.printDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument_PrintPage);
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem1});
            // 
            // menuItem1
            // 
            this.menuItem1.Index = 0;
            this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem2});
            this.menuItem1.Text = "File";
            // 
            // menuItem2
            // 
            this.menuItem2.Index = 0;
            this.menuItem2.Text = "Print Map...";
            this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
            // 
            // MapTools
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(994, 601);
            this.Controls.Add(this.map1);
            this.Controls.Add(this.splitter3);
            this.Controls.Add(this.dataGrid);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusBar1);
            this.Controls.Add(this.toolBar);
            this.Menu = this.mainMenu1;
            this.Name = "MapTools";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "MapTools";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		private void Form1_Load(object sender, System.EventArgs e)
		{
            AddMapLayers();

            foreach (Layer layer in map1)
                layerList.Items.Add(layer.Name);
            layerList.SelectedIndex = 0;
		}

		private void AddMapLayers()
		{
            Layer layer;
            Feature feature;
            FeatureRenderer renderer;
			
            string LayerFolder = Application.StartupPath + @"\..\..\MAPS\STREETS\";
            string SymbolFolder = Application.StartupPath + @"\..\..\SYMBOLS\";

            //- COUNTY -------------------------------------------
            layer = map1.AddLayer(LayerFolder + "County.shp");

            layer.LabelField = "NAME";
            layer.Symbol.Size = 2;
            layer.Symbol.LineColor = Color.FromArgb(199, 172, 116);
            layer.Symbol.FillColor = Color.FromArgb(242, 236, 223);

            //- PARKS --------------------------------------------
            layer = map1.AddLayer(LayerFolder + "Park.shp");

            layer.LabelField = "NAME";
            layer.ShowLabels = true;
            layer.LabelFont.Outline = true;
            layer.LabelFont.Size = 11;
            layer.LabelFont.Bold = true;
            layer.Symbol.FillColor = Color.FromArgb(143, 175, 47);
            layer.Symbol.LineColor = layer.Symbol.FillColor;
            
            //- WATER AREAS --------------------------------------
            layer = map1.AddLayer(LayerFolder + "WaterArea.shp");
            layer.MaxScale = 300000;

            layer.LabelField = "NAME";
            layer.ShowLabels = true;
            layer.LabelFont.Outline = true;
            layer.LabelFont.Size = 12;
            layer.Symbol.FillColor = Color.FromArgb(159, 159, 223);
            layer.Symbol.LineColor = layer.Symbol.FillColor;
            
            //- RIVERS -------------------------------------------
            layer = map1.AddLayer(LayerFolder + "Water.shp");
            layer.MaxScale = 300000;

            layer.LabelField = "NAME";
            layer.ShowLabels = true;
            layer.LabelFont.Size = 9;
            layer.Symbol.FillColor = Color.FromArgb(159, 159, 223);
            layer.Symbol.LineColor = layer.Symbol.FillColor;
            layer.LabelFont.Color = Color.FromArgb(0, 0, 128);
            
            //- AIRPORTS -----------------------------------------
            layer = map1.AddLayer(LayerFolder + "Airport.shp");

            layer.LabelField = "NAME";
            layer.ShowLabels = true;
            layer.LabelFont.Outline = true;
            layer.LabelFont.Size = 11;
            layer.Symbol.FillColor = Color.FromArgb(43, 147, 43);

            //- STREETS ------------------------------------------
            layer = map1.AddLayer(LayerFolder + "Street.shp");
            layer.MaxScale = 150000;

            layer.LabelField = "NAME";
            layer.LabelFont.Size = 10;
            layer.ShowLabels = true;
            layer.Symbol.LineStyle = LineStyle.Road;
            layer.Symbol.LineColor = Color.FromArgb(171, 158, 137);
            layer.Symbol.InnerColor = Color.White;

            // set different line width of the streets for different scales
            feature = new ActualMap.Feature();
            feature.MaxScale = 75000;
            feature.MinScale = 37000;
            feature.Symbol.LineStyle = LineStyle.Road;
            feature.Symbol.LineColor = Color.FromArgb(171, 158, 137);
            feature.Symbol.InnerColor = Color.White;
            feature.Symbol.Size = 3;
            layer.Renderer.Add(feature);

            feature = feature.Clone();
            feature.MaxScale = 37000;
            feature.MinScale = 16000;
            feature.Symbol.Size = 4;
            feature.LabelFont.Outline = true;
            layer.Renderer.Add(feature);

            feature = feature.Clone();
            feature.MaxScale = 16000;
            feature.MinScale = -1; // no minimum scale
            feature.Symbol.Size = 6;
            layer.Renderer.Add(feature);
            
            //- RAILROADS ----------------------------------------
            layer = map1.AddLayer(LayerFolder + "Railroad.shp");
            layer.MaxScale = 200000;

            layer.LabelField = "NAME";
            layer.ShowLabels = true;
            layer.LabelFont.Outline = true;
            layer.LabelFont.Size = 10;
            layer.Symbol.LineStyle = LineStyle.Railroad;

            //- INSTITUTIONS -------------------------------------
            layer = map1.AddLayer(LayerFolder + "Institution.shp");

            layer.LabelField = "NAME";
            layer.ShowLabels = true;
            layer.LabelFont.Name = "Times New Roman";
            layer.LabelFont.Outline = true;
            layer.LabelFont.Size = 12;
            layer.UseDefaultSymbol = false;

            renderer = layer.Renderer;
            renderer.Field = "FCC";

            // cemetery symbol
            feature = renderer.Add();
            feature.Value = "D82";
            feature.Symbol.PointStyle = PointStyle.Bitmap;
            feature.Symbol.Bitmap = SymbolFolder + "cemetery.bmp";
            feature.Symbol.Size = 16;
            feature.Symbol.TransparentColor = Color.White;
            feature.Description = "Cemetery";

            // school symbol
            feature = renderer.Add();
            feature.Value = "D43";
            feature.Symbol.PointStyle = PointStyle.Bitmap;
            feature.Symbol.Bitmap = SymbolFolder + "school.bmp";
            feature.Symbol.Size = 16;
            feature.Symbol.TransparentColor = Color.White;
            feature.Description = "School";

            // church symbol
            feature = renderer.Add();
            feature.Value = "D44";
            feature.Symbol.PointStyle = PointStyle.Bitmap;
            feature.Symbol.Bitmap = SymbolFolder + "church.bmp";
            feature.Symbol.Size = 16;
            feature.Symbol.TransparentColor = Color.White;
            feature.Description = "Church";

            // hospital symbol
            feature = renderer.Add();
            feature.Value = "D31";
            feature.Symbol.PointStyle = PointStyle.Bitmap;
            feature.Symbol.Bitmap = SymbolFolder + "hospital.bmp";
            feature.Symbol.Size = 16;
            feature.Symbol.TransparentColor = Color.White;
            feature.Description = "Hospital";
		}
                
		private void toolBar_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
            if (e.Button.Style == ToolBarButtonStyle.ToggleButton) 
			{
				foreach(ToolBarButton b in toolBar.Buttons) b.Pushed = false;
				e.Button.Pushed = true;
			}

            map1.Cursor = Cursors.Default;

			if (e.Button == zoomFull)
			{
				map1.ZoomFull();
				map1.Refresh();
			}
            if (e.Button == clearShapes)
            {
                map1.MapShapes.Clear();
                map1.Callouts.Clear();
                dataGrid.DataSource = null;
                dataGrid.CaptionText = String.Empty;
                map1.Refresh();
            }
			else if (e.Button == zoomInTool)	map1.MapTool = MapTool.ZoomIn;
			else if (e.Button == zoomOutTool)	map1.MapTool = MapTool.ZoomOut;
            else if (e.Button == panTool)
            {
                map1.MapTool = MapTool.Pan;
                map1.Cursor = Cursors.SizeAll;
            }
			else if (e.Button == centerTool)	map1.MapTool = MapTool.Center;
			else if (e.Button == distanceTool)	map1.MapTool = MapTool.Distance;
			else if (e.Button == infoTool)		map1.MapTool = MapTool.Info;
			else if (e.Button == pointTool)		map1.MapTool = MapTool.Point;
			else if (e.Button == rectangleTool)		map1.MapTool = MapTool.Rectangle;
			else if (e.Button == lineTool)		map1.MapTool = MapTool.Line;
			else if (e.Button == polylineTool)		map1.MapTool = MapTool.Polyline;
			else if (e.Button == polygonTool)		map1.MapTool = MapTool.Polygon;
			else if (e.Button == circleTool)		map1.MapTool = MapTool.Circle;
		}

		private void map1_PointTool(object sender, ActualMap.Windows.PointToolEventArgs e)
		{
            map1.MapShapes.Clear();

            MapShape mapShape = map1.MapShapes.Add(e.Point);
            mapShape.Symbol.Size = 6;
            mapShape.Symbol.FillColor = Color.Red;

            Layer activeLayer = map1.FindLayer(layerList.SelectedItem.ToString());

            if (activeLayer != null && activeLayer.LayerType == LayerType.Polygon)
            {
                ActualMap.Recordset records = activeLayer.SearchShape(e.Point, SearchMethod.PointInPolygon);

                if (!records.EOF)
                {
                    dataGrid.DataSource = records;
                    dataGrid.CaptionText = records.Layer.Name.ToUpper();
                }                
            }

            map1.Refresh();
		}

		private void map1_LineToolFinished(object sender, ActualMap.Windows.LineToolEventArgs e)
		{
            map1.MapShapes.Clear();

            MapShape mapShape = map1.MapShapes.Add(e.Line);
            mapShape.Symbol.Size = 2;
            mapShape.Symbol.LineColor = Color.Red;

            ActualMap.Layer activeLayer = map1.FindLayer(layerList.SelectedItem.ToString());

            if (activeLayer != null)
            {
                ActualMap.Recordset records = activeLayer.SearchShape(e.Line, SearchMethod.Intersect);

                if (!records.EOF)
                {
                    dataGrid.DataSource = records;
                    dataGrid.CaptionText = records.Layer.Name.ToUpper();
                }
            }
            map1.Refresh();
        }

		private void map1_CircleToolFinished(object sender, ActualMap.Windows.CircleToolEventArgs e)
		{
            map1.MapShapes.Clear();

            MapShape mapShape = map1.MapShapes.Add(e.Circle);
            mapShape.Symbol.Size = 2;
            mapShape.Symbol.LineColor = Color.Red;
            mapShape.Symbol.FillStyle = FillStyle.Invisible;

            ActualMap.Layer activeLayer = map1.FindLayer(layerList.SelectedItem.ToString());

            if (activeLayer != null)
            {
                ActualMap.Recordset records = activeLayer.SearchShape(e.Circle, SearchMethod.Inside);

                if (!records.EOF)
                {
                    dataGrid.DataSource = records;
                    dataGrid.CaptionText = records.Layer.Name.ToUpper();
                }
            }

            map1.Refresh();
        }

		private void map1_InfoTool(object sender, ActualMap.Windows.InfoToolEventArgs e)
		{
            map1.Callouts.Clear();

            ActualMap.Recordset records = map1.Identify(e.InfoPoint, 5);

            if (!records.EOF)
            {
                dataGrid.DataSource = records;
                dataGrid.CaptionText = records.Layer.Name;

                Callout callout = map1.Callouts.Add();
                callout.X = e.InfoPoint.X;
                callout.Y = e.InfoPoint.Y;
                callout.Text = GetCalloutText(records);
                callout.Font.Size = 16;

                map1.Refresh();
            }			
		}

		private void map1_PolygonToolFinished(object sender, ActualMap.Windows.PolygonToolEventArgs e)
		{
            map1.MapShapes.Clear();

            MapShape mapShape = map1.MapShapes.Add(e.Polygon);
            mapShape.Symbol.Size = 2;
            mapShape.Symbol.LineColor = Color.Red;
            mapShape.Symbol.FillStyle = FillStyle.Invisible;
            
            ActualMap.Layer activeLayer = map1.FindLayer(layerList.SelectedItem.ToString());

            if (activeLayer != null)
            {
                ActualMap.Recordset records = activeLayer.SearchShape(e.Polygon, SearchMethod.Inside);

                if (!records.EOF)
                {
                    dataGrid.DataSource = records;
                    dataGrid.CaptionText = records.Layer.Name.ToUpper();
                }
            }

            map1.Refresh();
        }

		private void map1_PolylineToolFinished(object sender, ActualMap.Windows.PolylineToolEventArgs e)
		{
            map1.MapShapes.Clear();

            MapShape mapShape = map1.MapShapes.Add(e.Polyline);
            mapShape.Symbol.Size = 2;
            mapShape.Symbol.LineColor = Color.Red;

            ActualMap.Layer activeLayer = map1.FindLayer(layerList.SelectedItem.ToString());

            if (activeLayer != null)
            {
                ActualMap.Recordset records = activeLayer.SearchShape(e.Polyline, SearchMethod.Intersect);

                if (!records.EOF)
                {
                    dataGrid.DataSource = records;
                    dataGrid.CaptionText = records.Layer.Name.ToUpper();
                }
            }

            map1.Refresh();
        }

		private void map1_RectangleToolFinished(object sender, ActualMap.Windows.RectangleToolEventArgs e)
		{
            map1.MapShapes.Clear();

            MapShape mapShape = map1.MapShapes.Add(e.Rectangle);
            mapShape.Symbol.Size = 2;
            mapShape.Symbol.LineColor = Color.Red;
            mapShape.Symbol.FillStyle = FillStyle.Invisible;

            ActualMap.Layer activeLayer = map1.FindLayer(layerList.SelectedItem.ToString());

            if (activeLayer != null)
            {
                ActualMap.Recordset records = activeLayer.SearchShape(e.Rectangle, SearchMethod.Inside);

                if (!records.EOF)
                {
                    dataGrid.DataSource = records;
                    dataGrid.CaptionText = records.Layer.Name.ToUpper();
                }
            }
            
            map1.Refresh();
        }

		private void map1_DistanceToolMove(object sender, ActualMap.Windows.DistanceToolEventArgs e)
		{
            double distanceInMapUnits = e.Distance;
            double distanceInMiles = Math.Round(map1.ConvertDistance(distanceInMapUnits, map1.MapUnit, MeasureUnit.Mile), 3);
            double distanceInKilometers = Math.Round(map1.ConvertDistance(distanceInMapUnits, map1.MapUnit, MeasureUnit.Kilometer), 3);
            distanceMi.Text = distanceInMiles.ToString() + " mi";
            distanceKm.Text = distanceInKilometers.ToString() + " km";
		}

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			printPreview.ShowDialog();
		}

		private void printDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			Bitmap mapImage = map1.GetBitmap(700, 600);
			e.Graphics.DrawImageUnscaled(mapImage, 50, 50);
		}

        private String GetCalloutText(ActualMap.Recordset rs)
        {
            int index = rs.Fields.GetFieldIndex("NAME");
            if (index < 0) index = rs.Fields.GetFieldIndex(rs.Layer.LabelField);
            if (index < 0) index = 0;
            return rs[index].ToString();
        }
	}
}
