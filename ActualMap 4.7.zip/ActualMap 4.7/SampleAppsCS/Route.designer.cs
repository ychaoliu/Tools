using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using ActualMap;
using ActualMap.Windows;

namespace SampleApps
{
    partial class Route
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Route));
            this.toolBar = new System.Windows.Forms.ToolBar();
            this.sep = new System.Windows.Forms.ToolBarButton();
            this.zoomFull = new System.Windows.Forms.ToolBarButton();
            this.zoomInTool = new System.Windows.Forms.ToolBarButton();
            this.zoomOutTool = new System.Windows.Forms.ToolBarButton();
            this.panTool = new System.Windows.Forms.ToolBarButton();
            this.toolImages = new System.Windows.Forms.ImageList(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnQuickest = new System.Windows.Forms.RadioButton();
            this.btnShortest = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnMiles = new System.Windows.Forms.RadioButton();
            this.btnKilometers = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.findRoute = new System.Windows.Forms.Button();
            this.endLocation = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.startLocation = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.directions = new System.Windows.Forms.ListView();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.map1 = new ActualMap.Windows.Map();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolBar
            // 
            this.toolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
            this.toolBar.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
            this.sep,
            this.zoomFull,
            this.zoomInTool,
            this.zoomOutTool,
            this.panTool});
            this.toolBar.ButtonSize = new System.Drawing.Size(23, 21);
            this.toolBar.DropDownArrows = true;
            this.toolBar.ImageList = this.toolImages;
            this.toolBar.Location = new System.Drawing.Point(0, 0);
            this.toolBar.Name = "toolBar";
            this.toolBar.ShowToolTips = true;
            this.toolBar.Size = new System.Drawing.Size(879, 32);
            this.toolBar.TabIndex = 1;
            this.toolBar.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.toolBar_ButtonClick);
            // 
            // sep
            // 
            this.sep.Name = "sep";
            this.sep.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
            // 
            // zoomFull
            // 
            this.zoomFull.ImageIndex = 10;
            this.zoomFull.Name = "zoomFull";
            this.zoomFull.ToolTipText = "Zoom Full";
            // 
            // zoomInTool
            // 
            this.zoomInTool.ImageIndex = 11;
            this.zoomInTool.Name = "zoomInTool";
            this.zoomInTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.zoomInTool.Tag = "";
            this.zoomInTool.ToolTipText = "Zoom In";
            // 
            // zoomOutTool
            // 
            this.zoomOutTool.ImageIndex = 12;
            this.zoomOutTool.Name = "zoomOutTool";
            this.zoomOutTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.zoomOutTool.ToolTipText = "Zoom Out";
            // 
            // panTool
            // 
            this.panTool.ImageIndex = 5;
            this.panTool.Name = "panTool";
            this.panTool.Pushed = true;
            this.panTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.panTool.ToolTipText = "Pan";
            // 
            // toolImages
            // 
            this.toolImages.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("toolImages.ImageStream")));
            this.toolImages.TransparentColor = System.Drawing.Color.Transparent;
            this.toolImages.Images.SetKeyName(0, "");
            this.toolImages.Images.SetKeyName(1, "");
            this.toolImages.Images.SetKeyName(2, "");
            this.toolImages.Images.SetKeyName(3, "");
            this.toolImages.Images.SetKeyName(4, "");
            this.toolImages.Images.SetKeyName(5, "");
            this.toolImages.Images.SetKeyName(6, "");
            this.toolImages.Images.SetKeyName(7, "");
            this.toolImages.Images.SetKeyName(8, "");
            this.toolImages.Images.SetKeyName(9, "");
            this.toolImages.Images.SetKeyName(10, "");
            this.toolImages.Images.SetKeyName(11, "");
            this.toolImages.Images.SetKeyName(12, "");
            this.toolImages.Images.SetKeyName(13, "clear.gif");
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(677, 32);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(202, 467);
            this.panel1.TabIndex = 11;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.findRoute);
            this.panel2.Controls.Add(this.endLocation);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.startLocation);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(202, 467);
            this.panel2.TabIndex = 2;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnQuickest);
            this.groupBox2.Controls.Add(this.btnShortest);
            this.groupBox2.Location = new System.Drawing.Point(7, 247);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(180, 51);
            this.groupBox2.TabIndex = 33;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Route Type";
            // 
            // btnQuickest
            // 
            this.btnQuickest.AutoSize = true;
            this.btnQuickest.Checked = true;
            this.btnQuickest.Location = new System.Drawing.Point(7, 22);
            this.btnQuickest.Name = "btnQuickest";
            this.btnQuickest.Size = new System.Drawing.Size(81, 21);
            this.btnQuickest.TabIndex = 29;
            this.btnQuickest.TabStop = true;
            this.btnQuickest.Text = "Quickest";
            this.btnQuickest.UseVisualStyleBackColor = true;
            // 
            // btnShortest
            // 
            this.btnShortest.AutoSize = true;
            this.btnShortest.Location = new System.Drawing.Point(95, 22);
            this.btnShortest.Name = "btnShortest";
            this.btnShortest.Size = new System.Drawing.Size(79, 21);
            this.btnShortest.TabIndex = 30;
            this.btnShortest.Text = "Shortest";
            this.btnShortest.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnMiles);
            this.groupBox1.Controls.Add(this.btnKilometers);
            this.groupBox1.Location = new System.Drawing.Point(7, 163);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(180, 50);
            this.groupBox1.TabIndex = 32;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Units";
            // 
            // btnMiles
            // 
            this.btnMiles.AutoSize = true;
            this.btnMiles.Checked = true;
            this.btnMiles.Location = new System.Drawing.Point(7, 22);
            this.btnMiles.Name = "btnMiles";
            this.btnMiles.Size = new System.Drawing.Size(58, 21);
            this.btnMiles.TabIndex = 26;
            this.btnMiles.TabStop = true;
            this.btnMiles.Text = "Miles";
            this.btnMiles.UseVisualStyleBackColor = true;
            // 
            // btnKilometers
            // 
            this.btnKilometers.AutoSize = true;
            this.btnKilometers.Location = new System.Drawing.Point(73, 22);
            this.btnKilometers.Name = "btnKilometers";
            this.btnKilometers.Size = new System.Drawing.Size(92, 21);
            this.btnKilometers.TabIndex = 27;
            this.btnKilometers.Text = "Kilometers";
            this.btnKilometers.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 217);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 17);
            this.label4.TabIndex = 31;
            this.label4.Text = "Route type:";
            // 
            // findRoute
            // 
            this.findRoute.Location = new System.Drawing.Point(54, 119);
            this.findRoute.Name = "findRoute";
            this.findRoute.Size = new System.Drawing.Size(90, 26);
            this.findRoute.TabIndex = 25;
            this.findRoute.Text = "Find Route";
            this.findRoute.UseVisualStyleBackColor = true;
            this.findRoute.Click += new System.EventHandler(this.findRoute_Click);
            // 
            // endLocation
            // 
            this.endLocation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.endLocation.FormattingEnabled = true;
            this.endLocation.Location = new System.Drawing.Point(11, 85);
            this.endLocation.Name = "endLocation";
            this.endLocation.Size = new System.Drawing.Size(176, 24);
            this.endLocation.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 17);
            this.label2.TabIndex = 23;
            this.label2.Text = "Route end:";
            // 
            // startLocation
            // 
            this.startLocation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.startLocation.FormattingEnabled = true;
            this.startLocation.Location = new System.Drawing.Point(11, 36);
            this.startLocation.Name = "startLocation";
            this.startLocation.Size = new System.Drawing.Size(176, 24);
            this.startLocation.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 17);
            this.label1.TabIndex = 21;
            this.label1.Text = "Route start:";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Info;
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.textBox1.Location = new System.Drawing.Point(0, 339);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(202, 128);
            this.textBox1.TabIndex = 20;
            this.textBox1.TabStop = false;
            this.textBox1.Text = "This application calculates a route between two locations, plots the route on a m" +
                "ap and displays driving directions.";
            // 
            // directions
            // 
            this.directions.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.directions.FullRowSelect = true;
            this.directions.Location = new System.Drawing.Point(0, 371);
            this.directions.MultiSelect = false;
            this.directions.Name = "directions";
            this.directions.Size = new System.Drawing.Size(677, 128);
            this.directions.TabIndex = 16;
            this.directions.UseCompatibleStateImageBehavior = false;
            this.directions.View = System.Windows.Forms.View.Details;
            this.directions.SelectedIndexChanged += new System.EventHandler(this.directions_SelectedIndexChanged);
            // 
            // splitter1
            // 
            this.splitter1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter1.Location = new System.Drawing.Point(0, 367);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(677, 4);
            this.splitter1.TabIndex = 17;
            this.splitter1.TabStop = false;
            // 
            // map1
            // 
            this.map1.BackColor = System.Drawing.Color.White;
            this.map1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.map1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.map1.FontQuality = ActualMap.FontQuality.ClearType;
            this.map1.Location = new System.Drawing.Point(0, 32);
            this.map1.MapTool = ActualMap.Windows.MapTool.Pan;
            this.map1.Name = "map1";
            this.map1.PixelPerInch = 96;
            this.map1.ScaleBar.BarUnit = ActualMap.UnitSystem.Imperial;
            this.map1.ScaleBar.FeetString = "ft";
            this.map1.ScaleBar.Font.Alignment = ActualMap.TextAlign.Left;
            this.map1.ScaleBar.Font.Bold = false;
            this.map1.ScaleBar.Font.Charset = 1;
            this.map1.ScaleBar.Font.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.map1.ScaleBar.Font.Italic = false;
            this.map1.ScaleBar.Font.Name = "Arial";
            this.map1.ScaleBar.Font.Outline = false;
            this.map1.ScaleBar.Font.OutlineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Font.Size = 12;
            this.map1.ScaleBar.Font.StrikeThrough = false;
            this.map1.ScaleBar.Font.Underline = false;
            this.map1.ScaleBar.KilometersString = "km";
            this.map1.ScaleBar.MaxWidth = 0;
            this.map1.ScaleBar.MetersString = "m";
            this.map1.ScaleBar.MilesString = "mi";
            this.map1.ScaleBar.Position = ActualMap.ScaleBarPosition.BottomRight;
            this.map1.ScaleBar.Symbol.Bitmap = "";
            this.map1.ScaleBar.Symbol.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Symbol.FillStyle = ActualMap.FillStyle.Solid;
            this.map1.ScaleBar.Symbol.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Symbol.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.map1.ScaleBar.Symbol.LineStyle = ActualMap.LineStyle.Solid;
            this.map1.ScaleBar.Symbol.PointStyle = ActualMap.PointStyle.Circle;
            this.map1.ScaleBar.Symbol.Rotation = 0;
            this.map1.ScaleBar.Symbol.Size = 1;
            this.map1.ScaleBar.Symbol.TransparentColor = System.Drawing.Color.Empty;
            this.map1.ScaleBar.Visible = false;
            this.map1.Size = new System.Drawing.Size(677, 335);
            this.map1.SmoothingMode = ActualMap.SmoothingMode.AntiAlias;
            this.map1.TabIndex = 18;
            this.map1.ToolShape.FillColor = System.Drawing.Color.Transparent;
            this.map1.ToolShape.LineColor = System.Drawing.Color.Red;
            this.map1.ToolShape.VertexColor = System.Drawing.Color.Red;
            this.map1.ToolShape.VirtualVertexColor = System.Drawing.Color.Green;
            // 
            // Route
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(879, 499);
            this.Controls.Add(this.map1);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.directions);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.toolBar);
            this.Name = "Route";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "Route";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

		private System.Windows.Forms.ToolBarButton zoomFull;
		private System.Windows.Forms.ToolBarButton sep;
		private System.Windows.Forms.ImageList toolImages;
		private System.Windows.Forms.ToolBarButton zoomInTool;
		private System.Windows.Forms.ToolBarButton zoomOutTool;
        private System.Windows.Forms.ToolBarButton panTool;
        private System.Windows.Forms.ToolBar toolBar;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private TextBox textBox1;
        private RadioButton btnKilometers;
        private RadioButton btnMiles;
        private Button findRoute;
        private ComboBox endLocation;
        private Label label2;
        private ComboBox startLocation;
        private Label label1;
        private Label label4;
        private RadioButton btnShortest;
        private RadioButton btnQuickest;
        private GroupBox groupBox2;
        private GroupBox groupBox1;
        private ListView directions;
        private Splitter splitter1;
        private Map map1;

    }
}