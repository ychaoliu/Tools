using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using ActualMap;
using ActualMap.Windows;

namespace SampleApps
{
    partial class RouteTutorial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RouteTutorial));
            this.toolBar = new System.Windows.Forms.ToolBar();
            this.sep = new System.Windows.Forms.ToolBarButton();
            this.zoomFull = new System.Windows.Forms.ToolBarButton();
            this.zoomInTool = new System.Windows.Forms.ToolBarButton();
            this.zoomOutTool = new System.Windows.Forms.ToolBarButton();
            this.panTool = new System.Windows.Forms.ToolBarButton();
            this.toolImages = new System.Windows.Forms.ImageList(this.components);
            this.listView1 = new System.Windows.Forms.ListView();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.map1 = new ActualMap.Windows.Map();
            this.SuspendLayout();
            // 
            // toolBar
            // 
            this.toolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
            this.toolBar.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
            this.sep,
            this.zoomFull,
            this.zoomInTool,
            this.zoomOutTool,
            this.panTool});
            this.toolBar.ButtonSize = new System.Drawing.Size(23, 21);
            this.toolBar.DropDownArrows = true;
            this.toolBar.ImageList = this.toolImages;
            this.toolBar.Location = new System.Drawing.Point(0, 0);
            this.toolBar.Name = "toolBar";
            this.toolBar.ShowToolTips = true;
            this.toolBar.Size = new System.Drawing.Size(879, 32);
            this.toolBar.TabIndex = 1;
            this.toolBar.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.toolBar_ButtonClick);
            // 
            // sep
            // 
            this.sep.Name = "sep";
            this.sep.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
            // 
            // zoomFull
            // 
            this.zoomFull.ImageIndex = 10;
            this.zoomFull.Name = "zoomFull";
            this.zoomFull.ToolTipText = "Zoom Full";
            // 
            // zoomInTool
            // 
            this.zoomInTool.ImageIndex = 11;
            this.zoomInTool.Name = "zoomInTool";
            this.zoomInTool.Pushed = true;
            this.zoomInTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.zoomInTool.Tag = "";
            this.zoomInTool.ToolTipText = "Zoom In";
            // 
            // zoomOutTool
            // 
            this.zoomOutTool.ImageIndex = 12;
            this.zoomOutTool.Name = "zoomOutTool";
            this.zoomOutTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.zoomOutTool.ToolTipText = "Zoom Out";
            // 
            // panTool
            // 
            this.panTool.ImageIndex = 5;
            this.panTool.Name = "panTool";
            this.panTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.panTool.ToolTipText = "Pan";
            // 
            // toolImages
            // 
            this.toolImages.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("toolImages.ImageStream")));
            this.toolImages.TransparentColor = System.Drawing.Color.Transparent;
            this.toolImages.Images.SetKeyName(0, "");
            this.toolImages.Images.SetKeyName(1, "");
            this.toolImages.Images.SetKeyName(2, "");
            this.toolImages.Images.SetKeyName(3, "");
            this.toolImages.Images.SetKeyName(4, "");
            this.toolImages.Images.SetKeyName(5, "");
            this.toolImages.Images.SetKeyName(6, "");
            this.toolImages.Images.SetKeyName(7, "");
            this.toolImages.Images.SetKeyName(8, "");
            this.toolImages.Images.SetKeyName(9, "");
            this.toolImages.Images.SetKeyName(10, "");
            this.toolImages.Images.SetKeyName(11, "");
            this.toolImages.Images.SetKeyName(12, "");
            this.toolImages.Images.SetKeyName(13, "clear.gif");
            // 
            // listView1
            // 
            this.listView1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.listView1.FullRowSelect = true;
            this.listView1.Location = new System.Drawing.Point(0, 388);
            this.listView1.MultiSelect = false;
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(879, 111);
            this.listView1.TabIndex = 16;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // splitter1
            // 
            this.splitter1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter1.Location = new System.Drawing.Point(0, 385);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(879, 3);
            this.splitter1.TabIndex = 17;
            this.splitter1.TabStop = false;
            // 
            // map1
            // 
            this.map1.BackColor = System.Drawing.Color.White;
            this.map1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.map1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.map1.FontQuality = ActualMap.FontQuality.ClearType;
            this.map1.Location = new System.Drawing.Point(0, 32);
            this.map1.MapTool = ActualMap.Windows.MapTool.ZoomIn;
            this.map1.MapUnit = ActualMap.MeasureUnit.Degree;
            this.map1.Name = "map1";
            this.map1.PixelPerInch = 96;
            this.map1.ScaleBar.BarUnit = ActualMap.UnitSystem.Imperial;
            this.map1.ScaleBar.FeetString = "ft";
            this.map1.ScaleBar.Font.Alignment = ActualMap.TextAlign.Left;
            this.map1.ScaleBar.Font.Bold = false;
            this.map1.ScaleBar.Font.Charset = 1;
            this.map1.ScaleBar.Font.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.map1.ScaleBar.Font.Italic = false;
            this.map1.ScaleBar.Font.Name = "Arial";
            this.map1.ScaleBar.Font.Outline = false;
            this.map1.ScaleBar.Font.OutlineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Font.Size = 12;
            this.map1.ScaleBar.Font.StrikeThrough = false;
            this.map1.ScaleBar.Font.Underline = false;
            this.map1.ScaleBar.KilometersString = "km";
            this.map1.ScaleBar.MaxWidth = 0;
            this.map1.ScaleBar.MetersString = "m";
            this.map1.ScaleBar.MilesString = "mi";
            this.map1.ScaleBar.Position = ActualMap.ScaleBarPosition.BottomRight;
            this.map1.ScaleBar.Symbol.Bitmap = "";
            this.map1.ScaleBar.Symbol.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Symbol.FillStyle = ActualMap.FillStyle.Solid;
            this.map1.ScaleBar.Symbol.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Symbol.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.map1.ScaleBar.Symbol.LineStyle = ActualMap.LineStyle.Solid;
            this.map1.ScaleBar.Symbol.PointStyle = ActualMap.PointStyle.Circle;
            this.map1.ScaleBar.Symbol.Size = 1;
            this.map1.ScaleBar.Symbol.TransparentColor = System.Drawing.Color.Empty;
            this.map1.ScaleBar.Visible = true;
            this.map1.Size = new System.Drawing.Size(879, 353);
            this.map1.SmoothingMode = ActualMap.SmoothingMode.AntiAlias;
            this.map1.TabIndex = 18;
            this.map1.ToolShape.FillColor = System.Drawing.Color.Transparent;
            this.map1.ToolShape.LineColor = System.Drawing.Color.Red;
            // 
            // RouteTutorial
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(879, 499);
            this.Controls.Add(this.map1);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.toolBar);
            this.Name = "RouteTutorial";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "Route Tutorial";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

		private System.Windows.Forms.ToolBarButton zoomFull;
		private System.Windows.Forms.ToolBarButton sep;
		private System.Windows.Forms.ImageList toolImages;
		private System.Windows.Forms.ToolBarButton zoomInTool;
		private System.Windows.Forms.ToolBarButton zoomOutTool;
        private System.Windows.Forms.ToolBarButton panTool;
        private System.Windows.Forms.ToolBar toolBar;
        private ListView listView1;
        private Splitter splitter1;
        private Map map1;

    }
}