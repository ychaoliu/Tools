using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using ActualMap;
using ActualMap.Windows;

namespace SampleApps
{
    partial class WorldMap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WorldMap));
            this.toolBar = new System.Windows.Forms.ToolBar();
            this.sep = new System.Windows.Forms.ToolBarButton();
            this.zoomFull = new System.Windows.Forms.ToolBarButton();
            this.zoomInTool = new System.Windows.Forms.ToolBarButton();
            this.zoomOutTool = new System.Windows.Forms.ToolBarButton();
            this.panTool = new System.Windows.Forms.ToolBarButton();
            this.centerTool = new System.Windows.Forms.ToolBarButton();
            this.distanceTool = new System.Windows.Forms.ToolBarButton();
            this.infoTool = new System.Windows.Forms.ToolBarButton();
            this.toolBarButton1 = new System.Windows.Forms.ToolBarButton();
            this.clearShapes = new System.Windows.Forms.ToolBarButton();
            this.toolImages = new System.Windows.Forms.ImageList(this.components);
            this.statusBar1 = new System.Windows.Forms.StatusBar();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.dataGrid = new System.Windows.Forms.DataGrid();
            this.splitter3 = new System.Windows.Forms.Splitter();
            this.map1 = new ActualMap.Windows.Map();
            this.printPreview = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument = new System.Drawing.Printing.PrintDocument();
            this.mainMenu1 = new System.Windows.Forms.MainMenu(this.components);
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.menuItem2 = new System.Windows.Forms.MenuItem();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // toolBar
            // 
            this.toolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
            this.toolBar.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
            this.sep,
            this.zoomFull,
            this.zoomInTool,
            this.zoomOutTool,
            this.panTool,
            this.centerTool,
            this.distanceTool,
            this.infoTool,
            this.toolBarButton1,
            this.clearShapes});
            this.toolBar.ButtonSize = new System.Drawing.Size(23, 21);
            this.toolBar.DropDownArrows = true;
            this.toolBar.ImageList = this.toolImages;
            this.toolBar.Location = new System.Drawing.Point(0, 0);
            this.toolBar.Name = "toolBar";
            this.toolBar.ShowToolTips = true;
            this.toolBar.Size = new System.Drawing.Size(879, 32);
            this.toolBar.TabIndex = 1;
            this.toolBar.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.toolBar_ButtonClick);
            // 
            // sep
            // 
            this.sep.Name = "sep";
            this.sep.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
            // 
            // zoomFull
            // 
            this.zoomFull.ImageIndex = 10;
            this.zoomFull.Name = "zoomFull";
            this.zoomFull.ToolTipText = "Zoom Full";
            // 
            // zoomInTool
            // 
            this.zoomInTool.ImageIndex = 11;
            this.zoomInTool.Name = "zoomInTool";
            this.zoomInTool.Pushed = true;
            this.zoomInTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.zoomInTool.Tag = "";
            this.zoomInTool.ToolTipText = "Zoom In";
            // 
            // zoomOutTool
            // 
            this.zoomOutTool.ImageIndex = 12;
            this.zoomOutTool.Name = "zoomOutTool";
            this.zoomOutTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.zoomOutTool.ToolTipText = "Zoom Out";
            // 
            // panTool
            // 
            this.panTool.ImageIndex = 5;
            this.panTool.Name = "panTool";
            this.panTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.panTool.ToolTipText = "Pan";
            // 
            // centerTool
            // 
            this.centerTool.ImageIndex = 0;
            this.centerTool.Name = "centerTool";
            this.centerTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.centerTool.ToolTipText = "Center Map";
            // 
            // distanceTool
            // 
            this.distanceTool.ImageIndex = 2;
            this.distanceTool.Name = "distanceTool";
            this.distanceTool.ToolTipText = "Measure Distance";
            // 
            // infoTool
            // 
            this.infoTool.ImageIndex = 3;
            this.infoTool.Name = "infoTool";
            this.infoTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.infoTool.ToolTipText = "Identify";
            // 
            // toolBarButton1
            // 
            this.toolBarButton1.Name = "toolBarButton1";
            this.toolBarButton1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
            // 
            // clearShapes
            // 
            this.clearShapes.ImageIndex = 13;
            this.clearShapes.Name = "clearShapes";
            this.clearShapes.ToolTipText = "Clear Shapes";
            // 
            // toolImages
            // 
            this.toolImages.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("toolImages.ImageStream")));
            this.toolImages.TransparentColor = System.Drawing.Color.Transparent;
            this.toolImages.Images.SetKeyName(0, "");
            this.toolImages.Images.SetKeyName(1, "");
            this.toolImages.Images.SetKeyName(2, "");
            this.toolImages.Images.SetKeyName(3, "");
            this.toolImages.Images.SetKeyName(4, "");
            this.toolImages.Images.SetKeyName(5, "");
            this.toolImages.Images.SetKeyName(6, "");
            this.toolImages.Images.SetKeyName(7, "");
            this.toolImages.Images.SetKeyName(8, "");
            this.toolImages.Images.SetKeyName(9, "");
            this.toolImages.Images.SetKeyName(10, "");
            this.toolImages.Images.SetKeyName(11, "");
            this.toolImages.Images.SetKeyName(12, "");
            this.toolImages.Images.SetKeyName(13, "clear.gif");
            // 
            // statusBar1
            // 
            this.statusBar1.Location = new System.Drawing.Point(0, 473);
            this.statusBar1.Name = "statusBar1";
            this.statusBar1.Size = new System.Drawing.Size(879, 26);
            this.statusBar1.TabIndex = 10;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(677, 32);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(202, 441);
            this.panel1.TabIndex = 11;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(202, 441);
            this.panel2.TabIndex = 2;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Info;
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.textBox1.Location = new System.Drawing.Point(0, 313);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(202, 128);
            this.textBox1.TabIndex = 20;
            this.textBox1.TabStop = false;
            this.textBox1.Text = "This sample uses a raster image as a background image layer for the map.";
            // 
            // splitter1
            // 
            this.splitter1.Dock = System.Windows.Forms.DockStyle.Right;
            this.splitter1.Location = new System.Drawing.Point(674, 32);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 441);
            this.splitter1.TabIndex = 12;
            this.splitter1.TabStop = false;
            // 
            // dataGrid
            // 
            this.dataGrid.DataMember = "";
            this.dataGrid.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dataGrid.Location = new System.Drawing.Point(0, 345);
            this.dataGrid.Name = "dataGrid";
            this.dataGrid.RowHeadersVisible = false;
            this.dataGrid.Size = new System.Drawing.Size(674, 128);
            this.dataGrid.TabIndex = 13;
            // 
            // splitter3
            // 
            this.splitter3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter3.Location = new System.Drawing.Point(0, 342);
            this.splitter3.Name = "splitter3";
            this.splitter3.Size = new System.Drawing.Size(674, 3);
            this.splitter3.TabIndex = 14;
            this.splitter3.TabStop = false;
            // 
            // map1
            // 
            this.map1.BackColor = System.Drawing.Color.White;
            this.map1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.map1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.map1.FontQuality = ActualMap.FontQuality.ClearType;
            this.map1.Location = new System.Drawing.Point(0, 32);
            this.map1.MapTool = ActualMap.Windows.MapTool.ZoomIn;
            this.map1.MapUnit = ActualMap.MeasureUnit.Degree;
            this.map1.Name = "map1";
            this.map1.PixelPerInch = 96;
            this.map1.ScaleBar.BarUnit = ActualMap.UnitSystem.Imperial;
            this.map1.ScaleBar.FeetString = "ft";
            this.map1.ScaleBar.Font.Alignment = ActualMap.TextAlign.Left;
            this.map1.ScaleBar.Font.Bold = false;
            this.map1.ScaleBar.Font.Charset = 1;
            this.map1.ScaleBar.Font.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.map1.ScaleBar.Font.Italic = false;
            this.map1.ScaleBar.Font.Name = "Arial";
            this.map1.ScaleBar.Font.Outline = false;
            this.map1.ScaleBar.Font.OutlineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Font.Size = 12;
            this.map1.ScaleBar.Font.StrikeThrough = false;
            this.map1.ScaleBar.Font.Underline = false;
            this.map1.ScaleBar.KilometersString = "km";
            this.map1.ScaleBar.MaxWidth = 0;
            this.map1.ScaleBar.MetersString = "m";
            this.map1.ScaleBar.MilesString = "mi";
            this.map1.ScaleBar.Position = ActualMap.ScaleBarPosition.BottomRight;
            this.map1.ScaleBar.Symbol.Bitmap = "";
            this.map1.ScaleBar.Symbol.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Symbol.FillStyle = ActualMap.FillStyle.Solid;
            this.map1.ScaleBar.Symbol.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Symbol.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.map1.ScaleBar.Symbol.LineStyle = ActualMap.LineStyle.Solid;
            this.map1.ScaleBar.Symbol.PointStyle = ActualMap.PointStyle.Circle;
            this.map1.ScaleBar.Symbol.Rotation = 0;
            this.map1.ScaleBar.Symbol.Size = 1;
            this.map1.ScaleBar.Symbol.TransparentColor = System.Drawing.Color.Empty;
            this.map1.ScaleBar.Visible = true;
            this.map1.Size = new System.Drawing.Size(674, 310);
            this.map1.SmoothingMode = ActualMap.SmoothingMode.None;
            this.map1.TabIndex = 15;
            this.map1.ToolShape.FillColor = System.Drawing.Color.Silver;
            this.map1.ToolShape.LineColor = System.Drawing.Color.Red;
            this.map1.DistanceToolMove += new ActualMap.Windows.DistanceToolEventHandler(this.map1_DistanceToolMove);
            this.map1.DistanceToolFinished += new ActualMap.Windows.DistanceToolEventHandler(this.map1_DistanceToolFinished);
            this.map1.InfoTool += new ActualMap.Windows.InfoToolEventHandler(this.map1_InfoTool);
            // 
            // printPreview
            // 
            this.printPreview.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreview.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreview.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreview.Document = this.printDocument;
            this.printPreview.Enabled = true;
            this.printPreview.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreview.Icon")));
            this.printPreview.Name = "printPreview";
            this.printPreview.Visible = false;
            // 
            // printDocument
            // 
            this.printDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument_PrintPage);
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem1});
            // 
            // menuItem1
            // 
            this.menuItem1.Index = 0;
            this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem2});
            this.menuItem1.Text = "File";
            // 
            // menuItem2
            // 
            this.menuItem2.Index = 0;
            this.menuItem2.Text = "Print Map...";
            this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
            // 
            // WorldMap
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(879, 499);
            this.Controls.Add(this.map1);
            this.Controls.Add(this.splitter3);
            this.Controls.Add(this.dataGrid);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusBar1);
            this.Controls.Add(this.toolBar);
            this.Menu = this.mainMenu1;
            this.Name = "WorldMap";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "World Map";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

		private System.Windows.Forms.ToolBarButton zoomFull;
		private System.Windows.Forms.ToolBarButton sep;
		private System.Windows.Forms.ImageList toolImages;
		private System.Windows.Forms.ToolBarButton zoomInTool;
		private System.Windows.Forms.ToolBarButton zoomOutTool;
		private System.Windows.Forms.ToolBarButton panTool;
		private System.Windows.Forms.ToolBarButton centerTool;
        private System.Windows.Forms.ToolBarButton distanceTool;
		private System.Windows.Forms.ToolBar toolBar;
        private System.Windows.Forms.ToolBarButton infoTool;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Splitter splitter1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Splitter splitter3;
		private ActualMap.Windows.Map map1;
		private System.Windows.Forms.DataGrid dataGrid;
		private System.Windows.Forms.PrintPreviewDialog printPreview;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
        private System.Drawing.Printing.PrintDocument printDocument;
        private TextBox textBox1;
        private ToolBarButton toolBarButton1;
        private ToolBarButton clearShapes;

    }
}