using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ActualMap;
using ActualMap.Data;
using ActualMap.Windows;

namespace SampleApps
{
    public partial class MapTutorial : Form
    {
        public MapTutorial()
        {
            InitializeComponent();
        }

		private void Form1_Load(object sender, System.EventArgs e)
		{
            AddMapLayers();
            AddDatabase();
		}

		private void AddMapLayers()
		{
            Layer layer;
			
            string MapDir = Application.StartupPath + @"\..\..\MAPS\USA\";

            // add States layer
            layer = map1.AddLayer(MapDir + "States.shp");

            layer.LabelField = "STATE_ABBR";
            layer.ShowLabels = true;
            layer.LabelFont.Name = "Verdana";
            layer.LabelFont.Size = 12;
            layer.LabelFont.Bold = true;
            layer.LabelStyle = LabelStyle.PolygonCenter;

            RenderStates(layer);

            // add Roads layer
            layer = map1.AddLayer(MapDir + "Roads.shp");

            layer.Symbol.LineColor = Color.Red;
            layer.Symbol.Size = 2;

            layer.LabelField = "NUMBER";
            layer.ShowLabels = true;
            layer.LabelFont.Size = 12;

            RenderRoads(layer);

            // add Capitals layer
            layer = map1.AddLayer(MapDir + "Capitals.shp");

            layer.Symbol.PointStyle = PointStyle.CircleWithLargeCenter;
            layer.Symbol.Size = 10;
            layer.Symbol.FillColor = Color.FromArgb(255, 255, 0);

            layer.LabelField = "CITY_NAME";
            layer.ShowLabels = true;
            layer.LabelFont.Name = "Arial";
            layer.LabelFont.Bold = true;
            layer.LabelFont.Size = 14;
            layer.LabelFont.Outline = true;
            layer.LabelFont.OutlineColor = Color.FromArgb(255, 255, 0);
		}

        void RenderRoads(ActualMap.Layer RoadLayer)
        {
            FeatureRenderer renderer;
            Feature feature;

            renderer = RoadLayer.Renderer;
            renderer.Field = "CLASS";

            feature = renderer.Add();
            feature.Value = "Interstate";
            feature.Symbol.LineColor = Color.Red;
            feature.Symbol.Size = 2;

            feature = renderer.Add();
            feature.Value = "US Highway";
            feature.Symbol.LineColor = Color.Blue;
            feature.Symbol.Size = 2;

            feature = renderer.Add();
            feature.Value = "State Highway";
            feature.Symbol.LineColor = Color.Green;
            feature.Symbol.Size = 2;
        }

        void RenderStates(ActualMap.Layer StateLayer)
        {
            FeatureRenderer renderer;
            Feature feature;

            renderer = StateLayer.Renderer;

            feature = renderer.Add();
            feature.Expression = "POPULATION < 1000000";
            feature.Symbol.FillColor = Color.LightYellow;

            feature = renderer.Add();
            feature.Expression = "POPULATION < 5000000";
            feature.Symbol.FillColor = Color.Yellow;

            feature = renderer.Add();
            feature.Expression = "POPULATION < 10000000";
            feature.Symbol.FillColor = Color.Pink;

            feature = renderer.Add();
            feature.Expression = "POPULATION >= 10000000";
            feature.Symbol.FillColor = Color.Red;
        }

        void AddDatabase()
        {
            string dataFile = Application.StartupPath + @"\..\..\DATA\airports.mdb";
            string connectionString = "PROVIDER=Microsoft.Jet.OLEDB.4.0;DATA Source=" + dataFile;

            PointDataLayer pointData = new PointDataLayer("System.Data.OleDb", connectionString, "airports", "LONGITUDE", "LATITUDE");

	        Layer dbLayer = map1.AddLayer(pointData);
            
            if (dbLayer == null)
            {
                MessageBox.Show("Cannot add airports.mdb database.");
                return;
            }

            dbLayer.Name = "Airports";
            dbLayer.Symbol.PointStyle = PointStyle.Circle;
            dbLayer.Symbol.FillColor = Color.Silver;

            dbLayer.LabelField = "DESCRIP";
            dbLayer.LabelFont.Name = "Arial";
            dbLayer.LabelFont.Size = 12;
        }
        
		private void map1_InfoTool(object sender, ActualMap.Windows.InfoToolEventArgs e)
		{
            map1.Callouts.Clear();

            ActualMap.Recordset records = map1.Identify(e.InfoPoint, 5);

            if (!records.EOF)
            {
                dataGridView1.DataSource = records;

                Callout callout = map1.Callouts.Add();
                callout.X = e.InfoPoint.X;
                callout.Y = e.InfoPoint.Y;
                callout.Font.Size = 16;

                if (records.Layer.LabelField.Length > 0)
                    callout.Text = records[records.Layer.LabelField].ToString();
                else
                    callout.Text = records[0].ToString();

                map1.Refresh();
            }
        }

        private void zoomFull_Click(object sender, EventArgs e)
        {
            map1.ZoomFull();
            map1.Refresh();
        }

        private void zoomInTool_Click(object sender, EventArgs e)
        {
            map1.MapTool = MapTool.ZoomIn;
            CheckButton(zoomInTool);            
        }

        private void zoomOutTool_Click(object sender, EventArgs e)
        {
            map1.MapTool = MapTool.ZoomOut;
            CheckButton(zoomOutTool);
        }

        private void panTool_Click(object sender, EventArgs e)
        {
            map1.MapTool = MapTool.Pan;
            CheckButton(panTool);
        }

        private void infoTool_Click(object sender, EventArgs e)
        {
            map1.MapTool = MapTool.Info;
            CheckButton(infoTool);
        }

        private void CheckButton(ToolStripButton button)
        {
            zoomInTool.Checked = false;
            zoomOutTool.Checked = false;
            panTool.Checked = false;
            infoTool.Checked = false;
            button.Checked = true;
        }
	}
}