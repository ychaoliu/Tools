using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ActualMap;
using ActualMap.Windows;

namespace SampleApps
{
    public partial class CommonCoordSystem : Form
    {
        public CommonCoordSystem()
        {
            InitializeComponent();
        }

		private void Form1_Load(object sender, System.EventArgs e)
		{
            AddMapLayers();
            map1.CoordinateSystem = new ActualMap.CoordSystem(CoordSystemCode.PCS_WorldWinkelI);
            map1.ZoomFull();
		}

		private void AddMapLayers()
		{
            Layer layer;

            string LayerFolder = Application.StartupPath + @"\..\..\MAPS\PROJECTED\";

            // world
            layer = map1.AddLayer(LayerFolder + "world.shp");
            layer.ShowLabels = true;
            layer.LabelField = "NAME";
            layer.LabelFont.Name = "Verdana";
            layer.LabelFont.Size = 12;
            layer.LabelStyle = LabelStyle.PolygonCenter;
            layer.Opacity = 0.6;

            // lakes
            layer = map1.AddLayer(LayerFolder + "lakes.shp");
            layer.ShowLabels = true;
            layer.LabelField = "NAME";
            layer.LabelFont.Size = 10;
            layer.LabelFont.Outline = true;
            layer.Symbol.FillColor = Color.Blue;
            layer.Symbol.LineColor = layer.Symbol.FillColor;
            layer.LabelStyle = LabelStyle.PolygonCenter;

            // capitals
            layer = map1.AddLayer(LayerFolder + "capitals.shp");
            layer.ShowLabels = true;
            layer.LabelField = "NAME";
            layer.LabelFont.Bold = true;
            layer.LabelFont.Size = 11;
            layer.LabelFont.Outline = true;
            layer.Symbol.PointStyle = PointStyle.CircleWithLargeCenter;
            layer.Symbol.Size = 8;
            layer.Symbol.FillColor = Color.White;
		}

		private void toolBar_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
            if (e.Button.Style == ToolBarButtonStyle.ToggleButton) 
			{
				foreach(ToolBarButton b in toolBar.Buttons) b.Pushed = false;
				e.Button.Pushed = true;
			}

			if (e.Button == zoomFull)
			{
				map1.ZoomFull();
				map1.Refresh();
			}
			else if (e.Button == zoomInTool)	map1.MapTool = MapTool.ZoomIn;
			else if (e.Button == zoomOutTool)	map1.MapTool = MapTool.ZoomOut;
			else if (e.Button == panTool)		map1.MapTool = MapTool.Pan;
		}
	}
}