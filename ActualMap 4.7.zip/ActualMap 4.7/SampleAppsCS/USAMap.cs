using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ActualMap;
using ActualMap.Windows;

namespace SampleApps
{
    public partial class USAMap : Form
    {
        const double CITY = 1000000;			// MapScale = 1000000
        const double COUNTY = 2500000;		// MapScale = 2500000
        const double STATE = 7400000;		// MapScale = 7400000
        const double SUBREGION = 15000000;	// MapScale = 15000000
        const double REGION = 30000000;		// MapScale = 30000000
        const double COUNTRY = 75000000;		// full extent

        public USAMap()
        {
            InitializeComponent();
        }

		private void Form1_Load(object sender, System.EventArgs e)
		{
            AddMapLayers();

            // fill the states combobox
            Layer layer = map1.FindLayer("states");
            if (layer != null)
            {
                Recordset records = layer.Recordset;
                while (!records.EOF)
                {
                    statesList.Items.Add(records["STATE_NAME"]);
                    records.MoveNext();
                }
            }
		}

		private void AddMapLayers()
		{
            Layer layer;
            Feature feature;
            FeatureRenderer renderer;
			
            string LayerFolder = Application.StartupPath + @"\..\..\MAPS\USA\";
            string SymbolFolder = Application.StartupPath + @"\..\..\SYMBOLS\";

            //- STATES -------------------------------------------
            layer = map1.AddLayer(LayerFolder + "states.shp");

            layer.LabelField = "STATE_ABBR";
            layer.ShowLabels = true;
            layer.LabelFont.Name = "Verdana";
            layer.LabelFont.Size = 12;
            layer.LabelFont.Bold = true;
            layer.LabelStyle = LabelStyle.PolygonCenter;

            //- ROADS -------------------------------------------
            layer = map1.AddLayer(LayerFolder + "roads.shp");

            // default symbol
            layer.LabelField = "NUMBER";
            layer.ShowLabels = true;
            layer.DuplicateLabels = false;
            layer.LabelFont.Size = 12;
            layer.Symbol.LineColor = Color.FromArgb(255, 0, 0);
            layer.Symbol.Size = 1;

            renderer = layer.Renderer;
            renderer.Field = "CLASS";

            // Interstate
            feature = renderer.Add();
            feature.MinScale = SUBREGION;
            feature.LabelStyle = LabelStyle.Shield;
            feature.Value = "Interstate";
            feature.ShieldSymbol.PointStyle = PointStyle.Bitmap;
            feature.ShieldSymbol.Bitmap = SymbolFolder + "interstate_highway.bmp";
            feature.ShieldSymbol.Size = 20;
            feature.ShieldSymbol.TransparentColor = Color.FromArgb(255, 255, 255);
            feature.Symbol.LineStyle = LineStyle.Solid;
            feature.Symbol.Size = 1;
            feature.Symbol.LineColor = Color.FromArgb(205, 120, 45);
            feature.LabelFont.Color = Color.FromArgb(255, 255, 255);

            feature = feature.Clone();
            feature.MinScale = COUNTY;
            feature.Symbol.LineStyle = LineStyle.Road;
            feature.Symbol.Size = 3;
            feature.Symbol.LineColor = Color.FromArgb(205, 120, 45);
            feature.Symbol.InnerColor = Color.FromArgb(249, 208, 137);
            renderer.Add(feature);

            feature = feature.Clone();
            feature.MinScale = -1;
            feature.Symbol.LineStyle = LineStyle.DualRoad;
            feature.Symbol.Size = 5;
            renderer.Add(feature);

            // US Highway
            feature = renderer.Add();
            feature.MinScale = SUBREGION;
            feature.LabelStyle = LabelStyle.Shield;
            feature.Value = "US Highway";
            feature.ShieldSymbol.PointStyle = PointStyle.Bitmap;
            feature.ShieldSymbol.Bitmap = SymbolFolder + "us_highway.bmp";
            feature.ShieldSymbol.Size = 20;
            feature.ShieldSymbol.TransparentColor = Color.White;
            feature.Symbol.LineStyle = LineStyle.Solid;
            feature.Symbol.Size = 1;
            feature.Symbol.LineColor = Color.FromArgb(205, 120, 45);

            feature = feature.Clone();
            feature.MinScale = COUNTY;
            feature.Symbol.LineStyle = LineStyle.Road;
            feature.Symbol.Size = 3;
            feature.Symbol.LineColor = Color.FromArgb(205, 120, 45);
            feature.Symbol.InnerColor = Color.FromArgb(254, 244, 131);
            renderer.Add(feature);

            feature = feature.Clone();
            feature.MinScale = -1;
            feature.Symbol.LineStyle = LineStyle.DualRoad;
            feature.Symbol.Size = 5;
            renderer.Add(feature);

            // State Highway
            feature = renderer.Add();
            feature.MinScale = SUBREGION;
            feature.LabelStyle = LabelStyle.Shield;
            feature.Value = "State Highway";
            feature.ShieldSymbol.PointStyle = PointStyle.Bitmap;
            feature.ShieldSymbol.Bitmap = SymbolFolder + "state_highway.bmp";
            feature.ShieldSymbol.Size = 20;
            feature.ShieldSymbol.TransparentColor = Color.White;
            feature.Symbol.LineStyle = LineStyle.Solid;
            feature.Symbol.Size = 1;
            feature.Symbol.LineColor = Color.FromArgb(205, 120, 45);

            feature = feature.Clone();
            feature.MinScale = COUNTY;
            feature.Symbol.LineStyle = LineStyle.Road;
            feature.Symbol.Size = 3;
            feature.Symbol.LineColor = Color.FromArgb(205, 120, 45);
            feature.Symbol.InnerColor = Color.FromArgb(255, 255, 204);
            renderer.Add(feature);

            feature = feature.Clone();
            feature.MinScale = -1;
            feature.Symbol.LineStyle = LineStyle.Road;
            feature.Symbol.Size = 5;
            renderer.Add(feature);

            //- CITIES --------------------------------------------
            layer = map1.AddLayer(LayerFolder + "cities.shp");

            layer.LabelField = "CITY_NAME";
            layer.ShowLabels = true;
            layer.UseDefaultSymbol = false;

            renderer = layer.Renderer;

            feature = renderer.Add();
            feature.Expression = "CAPITAL = \"Y\"";
            feature.Symbol.PointStyle = PointStyle.CircleWithLargeCenter;
            feature.Symbol.Size = 10;
            feature.Symbol.FillColor = Color.FromArgb(255, 255, 0);
            feature.LabelFont.Name = "Arial";
            feature.LabelFont.Bold = true;
            feature.LabelFont.Size = 14;
            feature.LabelFont.Outline = true;
            feature.LabelFont.OutlineColor = Color.FromArgb(255, 255, 0);

            feature = renderer.Add();
            feature.MaxScale = SUBREGION;
            feature.Expression = "POP > 500000";
            feature.Symbol.PointStyle = PointStyle.SquareWithLargeCenter;
            feature.Symbol.Size = 10;
            feature.Symbol.FillColor = Color.FromArgb(255, 255, 255);
            feature.LabelFont.Name = "Arial";
            feature.LabelFont.Bold = true;
            feature.LabelFont.Size = 13;
            feature.LabelFont.Outline = true;

            feature = renderer.Add();
            feature.MaxScale = SUBREGION;
            feature.Expression = "POP > 250000";
            feature.Symbol.PointStyle = PointStyle.CircleWithSmallCenter;
            feature.Symbol.Size = 10;
            feature.Symbol.FillColor = Color.FromArgb(255, 255, 255);
            feature.LabelFont.Name = "Arial";
            feature.LabelFont.Bold = true;
            feature.LabelFont.Size = 13;
            feature.LabelFont.Outline = true;

            feature = renderer.Add();
            feature.MaxScale = SUBREGION;
            feature.Expression = "POP > 150000";
            feature.Symbol.PointStyle = PointStyle.SquareWithSmallCenter;
            feature.Symbol.Size = 8;
            feature.Symbol.FillColor = Color.FromArgb(255, 255, 255);
            feature.LabelFont.Size = 12;

            feature = renderer.Add();
            feature.MaxScale = COUNTY;
            feature.Expression = "POP > 50000";
            feature.Symbol.PointStyle = PointStyle.Square;
            feature.Symbol.Size = 6;
            feature.Symbol.FillColor = Color.FromArgb(255, 255, 255);
            feature.LabelFont.Size = 12;

            feature = renderer.Add();
            feature.MaxScale = CITY;
            feature.Expression = "POP <= 50000";
            feature.Symbol.PointStyle = PointStyle.Circle;
            feature.Symbol.Size = 6;
            feature.Symbol.FillColor = Color.FromArgb(255, 255, 255);
            feature.LabelFont.Size = 12;
		}

		private void toolBar_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
            if (e.Button.Style == ToolBarButtonStyle.ToggleButton) 
			{
				foreach(ToolBarButton b in toolBar.Buttons) b.Pushed = false;
				e.Button.Pushed = true;
			}

            map1.Cursor = Cursors.Default;

			if (e.Button == zoomFull)
			{
				map1.ZoomFull();
				map1.Refresh();
			}
            if (e.Button == clearShapes)
            {
                map1.MapShapes.Clear();
                map1.Callouts.Clear();
                dataGrid.DataSource = null;
                dataGrid.CaptionText = String.Empty;
                map1.Refresh();
            }
			else if (e.Button == zoomInTool)	map1.MapTool = MapTool.ZoomIn;
			else if (e.Button == zoomOutTool)	map1.MapTool = MapTool.ZoomOut;
            else if (e.Button == panTool)
            {
                map1.MapTool = MapTool.Pan;
                map1.Cursor = Cursors.SizeAll;
            }
            else if (e.Button == centerTool) map1.MapTool = MapTool.Center;
            else if (e.Button == distanceTool) map1.MapTool = MapTool.Distance;
            else if (e.Button == infoTool) map1.MapTool = MapTool.Info;
		}

		private void map1_InfoTool(object sender, ActualMap.Windows.InfoToolEventArgs e)
		{
            map1.Callouts.Clear();

            ActualMap.Recordset records = map1.Identify(e.InfoPoint, 5);

            if (!records.EOF)
            {
                dataGrid.DataSource = records;
                dataGrid.CaptionText = records.Layer.Name;

                Callout callout = map1.Callouts.Add();
                callout.X = e.InfoPoint.X;
                callout.Y = e.InfoPoint.Y;
                callout.Text = GetCalloutText(records);
                callout.Font.Size = 16;

                map1.Refresh();
            }			
		}

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			printPreview.ShowDialog();
		}

		private void printDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			Bitmap mapImage = map1.GetBitmap(700, 600);
			e.Graphics.DrawImageUnscaled(mapImage, 50, 50);
		}

        private String GetCalloutText(ActualMap.Recordset rs)
        {
            int index = rs.Fields.GetFieldIndex("NAME");
            if (index < 0) index = rs.Fields.GetFieldIndex(rs.Layer.LabelField);
            if (index < 0) index = 0;
            return rs[index].ToString();
        }

        private void map1_DistanceToolMove(object sender, DistanceToolEventArgs e)
        {
            double distanceInMapUnits = e.Distance;
            double distanceInMiles = Math.Round(map1.ConvertDistance(distanceInMapUnits, map1.MapUnit, MeasureUnit.Mile), 3);
            double distanceInKilometers = Math.Round(map1.ConvertDistance(distanceInMapUnits, map1.MapUnit, MeasureUnit.Kilometer), 3);
            
            statusBar1.Text = distanceInMiles.ToString() + " mi  |  " +
                            distanceInKilometers.ToString() + " km";
        }

        private void map1_DistanceToolFinished(object sender, DistanceToolEventArgs e)
        {
            statusBar1.Text = String.Empty;
        }

        private void statesList_SelectedIndexChanged(object sender, EventArgs e)
        {
            Recordset state;
            state = map1["states"].SearchExpression("STATE_NAME = \"" + statesList.SelectedItem + "\"");
            if (!state.EOF)
            {
                map1.Extent = state.RecordExtent;

                // select the state shape with a red outline
                map1.MapShapes.Clear();
                MapShape shape = map1.MapShapes.Add(state.Shape);
                Symbol s = new Symbol();
                s.FillStyle = FillStyle.Invisible;
                s.LineColor = Color.Red;
                s.Size = 3;
                shape.Symbol = s;

                map1.Refresh();
            }
        }
	}
}