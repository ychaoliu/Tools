using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using ActualMap;
using ActualMap.Windows;

namespace SampleApps
{
    partial class WMSBrowser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WMSBrowser));
            this.toolBar = new System.Windows.Forms.ToolBar();
            this.sep = new System.Windows.Forms.ToolBarButton();
            this.zoomFull = new System.Windows.Forms.ToolBarButton();
            this.zoomInTool = new System.Windows.Forms.ToolBarButton();
            this.zoomOutTool = new System.Windows.Forms.ToolBarButton();
            this.panTool = new System.Windows.Forms.ToolBarButton();
            this.toolBarButton1 = new System.Windows.Forms.ToolBarButton();
            this.infoTool = new System.Windows.Forms.ToolBarButton();
            this.clearShapes = new System.Windows.Forms.ToolBarButton();
            this.toolImages = new System.Windows.Forms.ImageList(this.components);
            this.statusBar1 = new System.Windows.Forms.StatusBar();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.wmsLayers = new System.Windows.Forms.ComboBox();
            this.wmsTitle = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.layerName = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.layerStyles = new System.Windows.Forms.ComboBox();
            this.layerAbstract = new System.Windows.Forms.Label();
            this.layerTitle = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.splitter3 = new System.Windows.Forms.Splitter();
            this.printPreview = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument = new System.Drawing.Printing.PrintDocument();
            this.mainMenu1 = new System.Windows.Forms.MainMenu(this.components);
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.menuItem2 = new System.Windows.Forms.MenuItem();
            this.url = new System.Windows.Forms.TextBox();
            this.map1 = new ActualMap.Windows.Map();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolBar
            // 
            this.toolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
            this.toolBar.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
            this.sep,
            this.zoomFull,
            this.zoomInTool,
            this.zoomOutTool,
            this.panTool,
            this.toolBarButton1,
            this.infoTool,
            this.clearShapes});
            this.toolBar.ButtonSize = new System.Drawing.Size(23, 21);
            this.toolBar.DropDownArrows = true;
            this.toolBar.ImageList = this.toolImages;
            this.toolBar.Location = new System.Drawing.Point(0, 0);
            this.toolBar.Name = "toolBar";
            this.toolBar.ShowToolTips = true;
            this.toolBar.Size = new System.Drawing.Size(1040, 32);
            this.toolBar.TabIndex = 0;
            this.toolBar.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.toolBar_ButtonClick);
            // 
            // sep
            // 
            this.sep.Name = "sep";
            this.sep.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
            // 
            // zoomFull
            // 
            this.zoomFull.ImageIndex = 10;
            this.zoomFull.Name = "zoomFull";
            this.zoomFull.ToolTipText = "Zoom Full";
            // 
            // zoomInTool
            // 
            this.zoomInTool.ImageIndex = 11;
            this.zoomInTool.Name = "zoomInTool";
            this.zoomInTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.zoomInTool.Tag = "";
            this.zoomInTool.ToolTipText = "Zoom In";
            // 
            // zoomOutTool
            // 
            this.zoomOutTool.ImageIndex = 12;
            this.zoomOutTool.Name = "zoomOutTool";
            this.zoomOutTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.zoomOutTool.ToolTipText = "Zoom Out";
            // 
            // panTool
            // 
            this.panTool.ImageIndex = 5;
            this.panTool.Name = "panTool";
            this.panTool.Pushed = true;
            this.panTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.panTool.ToolTipText = "Pan";
            // 
            // toolBarButton1
            // 
            this.toolBarButton1.Name = "toolBarButton1";
            this.toolBarButton1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
            // 
            // infoTool
            // 
            this.infoTool.ImageIndex = 3;
            this.infoTool.Name = "infoTool";
            this.infoTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.infoTool.ToolTipText = "Identify";
            // 
            // clearShapes
            // 
            this.clearShapes.ImageIndex = 13;
            this.clearShapes.Name = "clearShapes";
            this.clearShapes.ToolTipText = "Clear callouts";
            // 
            // toolImages
            // 
            this.toolImages.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("toolImages.ImageStream")));
            this.toolImages.TransparentColor = System.Drawing.Color.Transparent;
            this.toolImages.Images.SetKeyName(0, "");
            this.toolImages.Images.SetKeyName(1, "");
            this.toolImages.Images.SetKeyName(2, "");
            this.toolImages.Images.SetKeyName(3, "");
            this.toolImages.Images.SetKeyName(4, "");
            this.toolImages.Images.SetKeyName(5, "");
            this.toolImages.Images.SetKeyName(6, "");
            this.toolImages.Images.SetKeyName(7, "");
            this.toolImages.Images.SetKeyName(8, "");
            this.toolImages.Images.SetKeyName(9, "");
            this.toolImages.Images.SetKeyName(10, "");
            this.toolImages.Images.SetKeyName(11, "");
            this.toolImages.Images.SetKeyName(12, "");
            this.toolImages.Images.SetKeyName(13, "clear.gif");
            // 
            // statusBar1
            // 
            this.statusBar1.Location = new System.Drawing.Point(0, 523);
            this.statusBar1.Name = "statusBar1";
            this.statusBar1.Size = new System.Drawing.Size(1040, 26);
            this.statusBar1.TabIndex = 3;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(838, 32);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(202, 491);
            this.panel1.TabIndex = 11;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.wmsLayers);
            this.panel2.Controls.Add(this.wmsTitle);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(202, 491);
            this.panel2.TabIndex = 2;
            // 
            // wmsLayers
            // 
            this.wmsLayers.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.wmsLayers.FormattingEnabled = true;
            this.wmsLayers.Location = new System.Drawing.Point(57, 226);
            this.wmsLayers.Name = "wmsLayers";
            this.wmsLayers.Size = new System.Drawing.Size(133, 24);
            this.wmsLayers.TabIndex = 1;
            this.wmsLayers.SelectionChangeCommitted += new System.EventHandler(this.wmsLayers_SelectionChangeCommitted);
            // 
            // wmsTitle
            // 
            this.wmsTitle.Location = new System.Drawing.Point(54, 158);
            this.wmsTitle.Name = "wmsTitle";
            this.wmsTitle.Size = new System.Drawing.Size(130, 63);
            this.wmsTitle.TabIndex = 28;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.layerName);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.layerStyles);
            this.groupBox1.Controls.Add(this.layerAbstract);
            this.groupBox1.Controls.Add(this.layerTitle);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(9, 256);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(181, 227);
            this.groupBox1.TabIndex = 27;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Layer Properties:";
            // 
            // layerName
            // 
            this.layerName.Location = new System.Drawing.Point(52, 21);
            this.layerName.Name = "layerName";
            this.layerName.Size = new System.Drawing.Size(123, 20);
            this.layerName.TabIndex = 33;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 21);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 16);
            this.label7.TabIndex = 32;
            this.label7.Text = "Name:";
            // 
            // layerStyles
            // 
            this.layerStyles.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.layerStyles.FormattingEnabled = true;
            this.layerStyles.Location = new System.Drawing.Point(48, 194);
            this.layerStyles.Name = "layerStyles";
            this.layerStyles.Size = new System.Drawing.Size(127, 24);
            this.layerStyles.TabIndex = 0;
            this.layerStyles.SelectionChangeCommitted += new System.EventHandler(this.layerStyles_SelectionChangeCommitted);
            // 
            // layerAbstract
            // 
            this.layerAbstract.Location = new System.Drawing.Point(72, 119);
            this.layerAbstract.Name = "layerAbstract";
            this.layerAbstract.Size = new System.Drawing.Size(103, 67);
            this.layerAbstract.TabIndex = 31;
            // 
            // layerTitle
            // 
            this.layerTitle.Location = new System.Drawing.Point(49, 49);
            this.layerTitle.Name = "layerTitle";
            this.layerTitle.Size = new System.Drawing.Size(126, 68);
            this.layerTitle.TabIndex = 30;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 49);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 16);
            this.label5.TabIndex = 25;
            this.label5.Text = "Title:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 119);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 16);
            this.label6.TabIndex = 26;
            this.label6.Text = "Abstract:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 197);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 16);
            this.label4.TabIndex = 24;
            this.label4.Text = "Style:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 229);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 16);
            this.label3.TabIndex = 23;
            this.label3.Text = "Layer:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 158);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 16);
            this.label2.TabIndex = 22;
            this.label2.Text = "Title:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.488F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(6, 135);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 16);
            this.label1.TabIndex = 21;
            this.label1.Text = "WMS Service Capabilities";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Info;
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.textBox1.Location = new System.Drawing.Point(0, 0);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(202, 130);
            this.textBox1.TabIndex = 0;
            this.textBox1.TabStop = false;
            this.textBox1.Text = "Lets you browse the layers of a Web Map Service. Enter a URL to a service and hit" +
                " the \'Enter\' button.\r\nExample: http://ows.terrestris.de/osm/service";
            // 
            // splitter1
            // 
            this.splitter1.Dock = System.Windows.Forms.DockStyle.Right;
            this.splitter1.Location = new System.Drawing.Point(835, 32);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 491);
            this.splitter1.TabIndex = 12;
            this.splitter1.TabStop = false;
            // 
            // splitter3
            // 
            this.splitter3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter3.Location = new System.Drawing.Point(0, 520);
            this.splitter3.Name = "splitter3";
            this.splitter3.Size = new System.Drawing.Size(835, 3);
            this.splitter3.TabIndex = 14;
            this.splitter3.TabStop = false;
            // 
            // printPreview
            // 
            this.printPreview.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreview.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreview.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreview.Document = this.printDocument;
            this.printPreview.Enabled = true;
            this.printPreview.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreview.Icon")));
            this.printPreview.Name = "printPreview";
            this.printPreview.Visible = false;
            // 
            // printDocument
            // 
            this.printDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument_PrintPage);
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem1});
            // 
            // menuItem1
            // 
            this.menuItem1.Index = 0;
            this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem2});
            this.menuItem1.Text = "File";
            // 
            // menuItem2
            // 
            this.menuItem2.Index = 0;
            this.menuItem2.Text = "Print Map...";
            this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
            // 
            // url
            // 
            this.url.Dock = System.Windows.Forms.DockStyle.Top;
            this.url.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.url.Location = new System.Drawing.Point(0, 32);
            this.url.Name = "url";
            this.url.Size = new System.Drawing.Size(835, 27);
            this.url.TabIndex = 15;
            this.url.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.url_KeyPress);
            // 
            // map1
            // 
            this.map1.BackColor = System.Drawing.Color.White;
            this.map1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.map1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.map1.FontQuality = ActualMap.FontQuality.ClearType;
            this.map1.Location = new System.Drawing.Point(0, 59);
            this.map1.MapTool = ActualMap.Windows.MapTool.Pan;
            this.map1.Name = "map1";
            this.map1.PixelPerInch = 96;
            this.map1.ScaleBar.BarUnit = ActualMap.UnitSystem.Imperial;
            this.map1.ScaleBar.FeetString = "ft";
            this.map1.ScaleBar.Font.Alignment = ActualMap.TextAlign.Left;
            this.map1.ScaleBar.Font.Bold = false;
            this.map1.ScaleBar.Font.Charset = 1;
            this.map1.ScaleBar.Font.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.map1.ScaleBar.Font.Italic = false;
            this.map1.ScaleBar.Font.Name = "Arial";
            this.map1.ScaleBar.Font.Outline = false;
            this.map1.ScaleBar.Font.OutlineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Font.Quality = ActualMap.FontQuality.Default;
            this.map1.ScaleBar.Font.Size = 12;
            this.map1.ScaleBar.Font.StrikeThrough = false;
            this.map1.ScaleBar.Font.Underline = false;
            this.map1.ScaleBar.KilometersString = "km";
            this.map1.ScaleBar.MaxWidth = 0;
            this.map1.ScaleBar.MetersString = "m";
            this.map1.ScaleBar.MilesString = "mi";
            this.map1.ScaleBar.Position = ActualMap.ScaleBarPosition.BottomRight;
            this.map1.ScaleBar.Symbol.Bitmap = "";
            this.map1.ScaleBar.Symbol.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Symbol.FillStyle = ActualMap.FillStyle.Solid;
            this.map1.ScaleBar.Symbol.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Symbol.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.map1.ScaleBar.Symbol.LineStyle = ActualMap.LineStyle.Solid;
            this.map1.ScaleBar.Symbol.PointStyle = ActualMap.PointStyle.Circle;
            this.map1.ScaleBar.Symbol.Rotation = 0;
            this.map1.ScaleBar.Symbol.Size = 1;
            this.map1.ScaleBar.Symbol.TransparentColor = System.Drawing.Color.Empty;
            this.map1.ScaleBar.Visible = true;
            this.map1.Size = new System.Drawing.Size(835, 461);
            this.map1.SmoothingMode = ActualMap.SmoothingMode.AntiAlias;
            this.map1.TabIndex = 16;
            this.map1.ToolShape.FillColor = System.Drawing.Color.LightGray;
            this.map1.ToolShape.LineColor = System.Drawing.Color.Red;
            this.map1.ToolShape.Opacity = 0.5;
            this.map1.ToolShape.VertexColor = System.Drawing.Color.Red;
            this.map1.ToolShape.VirtualVertexColor = System.Drawing.Color.Green;
            this.map1.AfterMapDraw += new ActualMap.Windows.MapDrawEventHandler(this.map1_AfterMapDraw);
            this.map1.BeforeMapDraw += new ActualMap.Windows.MapDrawEventHandler(this.map1_BeforeMapDraw);
            this.map1.InfoTool += new ActualMap.Windows.InfoToolEventHandler(this.map1_InfoTool);
            // 
            // WMSBrowser
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1040, 549);
            this.Controls.Add(this.map1);
            this.Controls.Add(this.url);
            this.Controls.Add(this.splitter3);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusBar1);
            this.Controls.Add(this.toolBar);
            this.Menu = this.mainMenu1;
            this.Name = "WMSBrowser";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "WMS Browser";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

		private System.Windows.Forms.ToolBarButton zoomFull;
		private System.Windows.Forms.ToolBarButton sep;
		private System.Windows.Forms.ImageList toolImages;
		private System.Windows.Forms.ToolBarButton zoomInTool;
		private System.Windows.Forms.ToolBarButton zoomOutTool;
        private System.Windows.Forms.ToolBarButton panTool;
		private System.Windows.Forms.ToolBar toolBar;
        private System.Windows.Forms.ToolBarButton infoTool;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Splitter splitter1;
		private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Splitter splitter3;
		private System.Windows.Forms.PrintPreviewDialog printPreview;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
        private System.Drawing.Printing.PrintDocument printDocument;
        private TextBox textBox1;
        private ToolBarButton toolBarButton1;
        private Label label1;
        private Label wmsTitle;
        private GroupBox groupBox1;
        private Label label5;
        private Label label6;
        private Label label4;
        private Label label3;
        private Label label2;
        private ComboBox wmsLayers;
        private ComboBox layerStyles;
        private Label layerAbstract;
        private Label layerTitle;
        private Label layerName;
        private Label label7;
        private ToolBarButton clearShapes;
        private TextBox url;
        private Map map1;

    }
}