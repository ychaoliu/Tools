using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using ActualMap;
using ActualMap.Windows;

namespace SampleApps
{
    partial class ShapeEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ShapeEditor));
            this.statusBar1 = new System.Windows.Forms.StatusBar();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.shapePanel = new System.Windows.Forms.Panel();
            this.remove = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.save = new System.Windows.Forms.Button();
            this.shapeTitle = new System.Windows.Forms.TextBox();
            this.operation = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.infoTool = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.drawTool = new System.Windows.Forms.ToolStripButton();
            this.editTool = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.panTool = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.map1 = new ActualMap.Windows.Map();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.shapePanel.SuspendLayout();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusBar1
            // 
            this.statusBar1.Location = new System.Drawing.Point(0, 556);
            this.statusBar1.Name = "statusBar1";
            this.statusBar1.Size = new System.Drawing.Size(976, 26);
            this.statusBar1.TabIndex = 10;
            // 
            // splitter1
            // 
            this.splitter1.Dock = System.Windows.Forms.DockStyle.Right;
            this.splitter1.Location = new System.Drawing.Point(716, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 556);
            this.splitter1.TabIndex = 12;
            this.splitter1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(719, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(257, 556);
            this.panel1.TabIndex = 11;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.shapePanel);
            this.panel3.Controls.Add(this.textBox1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(257, 556);
            this.panel3.TabIndex = 2;
            // 
            // shapePanel
            // 
            this.shapePanel.Controls.Add(this.remove);
            this.shapePanel.Controls.Add(this.cancel);
            this.shapePanel.Controls.Add(this.save);
            this.shapePanel.Controls.Add(this.shapeTitle);
            this.shapePanel.Controls.Add(this.operation);
            this.shapePanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.shapePanel.Location = new System.Drawing.Point(0, 266);
            this.shapePanel.Name = "shapePanel";
            this.shapePanel.Size = new System.Drawing.Size(257, 290);
            this.shapePanel.TabIndex = 21;
            // 
            // remove
            // 
            this.remove.Location = new System.Drawing.Point(118, 99);
            this.remove.Name = "remove";
            this.remove.Size = new System.Drawing.Size(75, 23);
            this.remove.TabIndex = 34;
            this.remove.Text = "Remove";
            this.remove.UseVisualStyleBackColor = true;
            this.remove.Click += new System.EventHandler(this.remove_Click);
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(118, 59);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(75, 23);
            this.cancel.TabIndex = 33;
            this.cancel.Text = "Cancel";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // save
            // 
            this.save.Location = new System.Drawing.Point(12, 59);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(75, 23);
            this.save.TabIndex = 32;
            this.save.Text = "Save";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // shapeTitle
            // 
            this.shapeTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.shapeTitle.Location = new System.Drawing.Point(9, 26);
            this.shapeTitle.Name = "shapeTitle";
            this.shapeTitle.Size = new System.Drawing.Size(184, 22);
            this.shapeTitle.TabIndex = 29;
            this.shapeTitle.Text = "Title";
            // 
            // operation
            // 
            this.operation.AutoSize = true;
            this.operation.Location = new System.Drawing.Point(9, 6);
            this.operation.Name = "operation";
            this.operation.Size = new System.Drawing.Size(80, 17);
            this.operation.TabIndex = 28;
            this.operation.Text = "Add shape:";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Info;
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.textBox1.Location = new System.Drawing.Point(0, 0);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(257, 266);
            this.textBox1.TabIndex = 20;
            this.textBox1.TabStop = false;
            this.textBox1.Text = resources.GetString("textBox1.Text");
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Controls.Add(this.map1);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(716, 529);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(716, 556);
            this.toolStripContainer1.TabIndex = 16;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // toolStripContainer1.TopToolStripPanel
            // 
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip1);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.infoTool,
            this.toolStripSeparator1,
            this.drawTool,
            this.editTool,
            this.toolStripSeparator2,
            this.panTool,
            this.toolStripButton1,
            this.toolStripSeparator3,
            this.toolStripButton2,
            this.toolStripSeparator4,
            this.toolStripButton3});
            this.toolStrip1.Location = new System.Drawing.Point(3, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(321, 27);
            this.toolStrip1.TabIndex = 0;
            // 
            // infoTool
            // 
            this.infoTool.CheckOnClick = true;
            this.infoTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.infoTool.Image = ((System.Drawing.Image)(resources.GetObject("infoTool.Image")));
            this.infoTool.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.infoTool.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.infoTool.Name = "infoTool";
            this.infoTool.Size = new System.Drawing.Size(25, 24);
            this.infoTool.Text = "Select";
            this.infoTool.Click += new System.EventHandler(this.infoTool_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // drawTool
            // 
            this.drawTool.CheckOnClick = true;
            this.drawTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.drawTool.Image = ((System.Drawing.Image)(resources.GetObject("drawTool.Image")));
            this.drawTool.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.drawTool.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.drawTool.Name = "drawTool";
            this.drawTool.Size = new System.Drawing.Size(25, 24);
            this.drawTool.Text = "DrawShape";
            this.drawTool.Click += new System.EventHandler(this.drawTool_Click);
            // 
            // editTool
            // 
            this.editTool.CheckOnClick = true;
            this.editTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.editTool.Image = ((System.Drawing.Image)(resources.GetObject("editTool.Image")));
            this.editTool.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.editTool.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.editTool.Name = "editTool";
            this.editTool.Size = new System.Drawing.Size(25, 24);
            this.editTool.Text = "EditShape";
            this.editTool.Click += new System.EventHandler(this.editTool_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // panTool
            // 
            this.panTool.Checked = true;
            this.panTool.CheckOnClick = true;
            this.panTool.CheckState = System.Windows.Forms.CheckState.Checked;
            this.panTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.panTool.Image = ((System.Drawing.Image)(resources.GetObject("panTool.Image")));
            this.panTool.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.panTool.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.panTool.Name = "panTool";
            this.panTool.Size = new System.Drawing.Size(25, 24);
            this.panTool.Text = "Pan";
            this.panTool.Click += new System.EventHandler(this.panTool_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(25, 24);
            this.toolStripButton1.Text = "Full Extent";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // map1
            // 
            this.map1.BackColor = System.Drawing.Color.White;
            this.map1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.map1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.map1.FontQuality = ActualMap.FontQuality.ClearType;
            this.map1.Location = new System.Drawing.Point(0, 0);
            this.map1.MapTool = ActualMap.Windows.MapTool.Info;
            this.map1.Name = "map1";
            this.map1.PixelPerInch = 96;
            this.map1.ScaleBar.BarUnit = ActualMap.UnitSystem.Imperial;
            this.map1.ScaleBar.FeetString = "ft";
            this.map1.ScaleBar.Font.Alignment = ActualMap.TextAlign.Left;
            this.map1.ScaleBar.Font.Bold = false;
            this.map1.ScaleBar.Font.Charset = 1;
            this.map1.ScaleBar.Font.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.map1.ScaleBar.Font.Italic = false;
            this.map1.ScaleBar.Font.Name = "Arial";
            this.map1.ScaleBar.Font.Outline = false;
            this.map1.ScaleBar.Font.OutlineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Font.Size = 12;
            this.map1.ScaleBar.Font.StrikeThrough = false;
            this.map1.ScaleBar.Font.Underline = false;
            this.map1.ScaleBar.KilometersString = "km";
            this.map1.ScaleBar.MaxWidth = 0;
            this.map1.ScaleBar.MetersString = "m";
            this.map1.ScaleBar.MilesString = "mi";
            this.map1.ScaleBar.Position = ActualMap.ScaleBarPosition.BottomRight;
            this.map1.ScaleBar.Symbol.Bitmap = "";
            this.map1.ScaleBar.Symbol.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Symbol.FillStyle = ActualMap.FillStyle.Solid;
            this.map1.ScaleBar.Symbol.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.map1.ScaleBar.Symbol.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.map1.ScaleBar.Symbol.LineStyle = ActualMap.LineStyle.Solid;
            this.map1.ScaleBar.Symbol.PointStyle = ActualMap.PointStyle.Circle;
            this.map1.ScaleBar.Symbol.Rotation = 0;
            this.map1.ScaleBar.Symbol.Size = 1;
            this.map1.ScaleBar.Symbol.TransparentColor = System.Drawing.Color.Empty;
            this.map1.ScaleBar.Visible = true;
            this.map1.Size = new System.Drawing.Size(716, 529);
            this.map1.SmoothingMode = ActualMap.SmoothingMode.AntiAlias;
            this.map1.TabIndex = 16;
            this.map1.ToolShape.FillColor = System.Drawing.Color.LightGray;
            this.map1.ToolShape.LineColor = System.Drawing.Color.Red;
            this.map1.ToolShape.LineWidth = 1;
            this.map1.ToolShape.VertexColor = System.Drawing.Color.Red;
            this.map1.ToolShape.VertexSize = 10;
            this.map1.ToolShape.VirtualVertexColor = System.Drawing.Color.Green;
            this.map1.InfoTool += new ActualMap.Windows.InfoToolEventHandler(this.map1_InfoTool);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(113, 24);
            this.toolStripButton2.Text = "Remove Vertex";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(47, 24);
            this.toolStripButton3.Text = "Clear";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 27);
            // 
            // ShapeEditor
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(976, 582);
            this.Controls.Add(this.toolStripContainer1);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusBar1);
            this.Name = "ShapeEditor";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "Shape Editor";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.shapePanel.ResumeLayout(false);
            this.shapePanel.PerformLayout();
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.StatusBar statusBar1;
        private System.Windows.Forms.Splitter splitter1;
        private Panel panel1;
        private Panel panel3;
        private Panel shapePanel;
        private Button remove;
        private Button cancel;
        private Button save;
        private TextBox shapeTitle;
        private Label operation;
        private TextBox textBox1;
        private ToolStripContainer toolStripContainer1;
        private Map map1;
        private ToolStrip toolStrip1;
        private ToolStripButton infoTool;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripButton panTool;
        private ToolStripButton editTool;
        private ToolStripButton drawTool;
        private ToolStripSeparator toolStripSeparator2;
        private ToolStripButton toolStripButton1;
        private ToolStripSeparator toolStripSeparator3;
        private ToolStripButton toolStripButton2;
        private ToolStripButton toolStripButton3;
        private ToolStripSeparator toolStripSeparator4;

    }
}