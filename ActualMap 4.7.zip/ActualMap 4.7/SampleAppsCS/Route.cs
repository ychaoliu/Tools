using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.IO;
using System.Windows.Forms;
using ActualMap;
using ActualMap.Windows;

namespace SampleApps
{
    public partial class Route : Form
    {
        ActualMap.Route _route;

        public Route()
        {
            InitializeComponent();
        }

		private void Form1_Load(object sender, System.EventArgs e)
		{
            AddMapLayers();

            ActualMap.Recordset rs = map1["locations"].Recordset;
            while (!rs.EOF)
            {
                startLocation.Items.Add(rs["NAME"]);
                endLocation.Items.Add(rs["NAME"]);
                rs.MoveNext();
            }           
            startLocation.SelectedIndex = 1;
            endLocation.SelectedIndex = 3;
		}

        private void AddMapLayers()
        {
            Layer layer;

            string LayerFolder = Application.StartupPath + @"\..\..\MAPS\ROUTING\";

            layer = map1.AddLayer(LayerFolder + "climits.shp");
            layer.Symbol.Size = 1;
            layer.Symbol.LineColor = Color.FromArgb(199, 172, 116);
            layer.Symbol.FillColor = Color.FromArgb(242, 236, 223);

            layer = map1.AddLayer(LayerFolder + "roads.shp");
            layer.LabelField = "FNAME";
            layer.LabelFont.Size = 10;
            layer.ShowLabels = true;
            layer.Symbol.LineStyle = LineStyle.Road;
            layer.Symbol.LineColor = Color.FromArgb(171, 158, 137);
            layer.Symbol.InnerColor = Color.White;
            layer.Symbol.Size = 3;

            layer = map1.AddLayer(LayerFolder + "locations.shp");
            layer.LabelField = "NAME";
            layer.LabelFont.Size = 12;
            layer.LabelFont.Outline = true;
            layer.ShowLabels = true;
            layer.Symbol.Size = 8;
            layer.Symbol.PointStyle = PointStyle.Triangle;
            layer.Symbol.LineColor = Color.White;
            layer.Symbol.FillColor = Color.FromArgb(0, 0, 200);

            map1.ZoomFull();
        }

        private void findRoute_Click(object sender, EventArgs e)
        {
            ActualMap.Point start, end;
            string roadNetworkFolder = Application.StartupPath + @"\..\..\MAPS\ROUTING\";

            // find coordinates of start and end locations
            start = GetLocationCoordinate(startLocation.SelectedItem.ToString());
            if (start == null) return;
            end = GetLocationCoordinate(endLocation.SelectedItem.ToString());
            if (end == null) return;

            if (start.Equals(end))
            {
                MessageBox.Show("Locations are equal.");
                return;
            }

            // load the road network 
            ActualMap.Network roadNetwork = new ActualMap.Network();

            if (!roadNetwork.Open(roadNetworkFolder + "roads.shp", roadNetworkFolder + "roads.rtn"))
            {
                MessageBox.Show("Cannot load road network: " + roadNetworkFolder + "roads.rtn");
                return;
            }

            // create a Route object
            ActualMap.Route route = roadNetwork.CreateRoute();

            // set the properties of the Route object
            if (btnMiles.Checked)
                route.DistanceUnit = MeasureUnit.Mile;
            else
                route.DistanceUnit = MeasureUnit.Kilometer;

            if (btnQuickest.Checked)
                route.RouteType = RouteType.Quickest;
            else
                route.RouteType = RouteType.Shortest;

            route.MaxDistance = 0.5;
            route.CurrentDate = DateTime.Now;

            // find a route between two points
            if (route.FindRoute(start.X, start.Y, end.X, end.Y))
            {
                // remove previous route layers
                ClearRouteLayer();

                // merge the Segment objects of the Route to Street objects, 
                // the Street objects will be used to generate driving directions
                route.MergeSegments("ADDRESS");

                // add the route to the map
                AddRouteLayer(route);

                // generate driving directions
                GenerateDrivingDirections(route);

                // set the map extent to the route extent
                map1.Extent = route.Extent;

                map1.Refresh();

                _route = route;
            }
            else
            {
                route.Dispose();
                MessageBox.Show("Route not found.");
            }		
        }

        ActualMap.Point GetLocationCoordinate(string locationName)
        {
            ActualMap.Recordset rs;

            rs = map1["locations"].SearchExpression("NAME = \"" + locationName.Trim() + "\"");

            if (rs.EOF)
            {
                MessageBox.Show("Location not found.");
                return null;
            }

            return rs.Shape.GetPoint(0);
        }

        void AddRouteLayer(ActualMap.Route route)
        {
            ActualMap.Layer routeLayer = map1.AddLayer(route);

            routeLayer.Name = "RouteLayer";
            routeLayer.Symbol.LineColor = Color.FromArgb(198, 86, 245);
            routeLayer.Symbol.Size = 9;
            routeLayer.Opacity = 0.3;

            ActualMap.DynamicLayer routeMarkers = new ActualMap.DynamicLayer();

            // add a start marker
            ActualMap.MapShape startMarker = routeMarkers.Add(route.StartPoint, "Start");
            startMarker.Symbol.Size = 10;
            startMarker.Symbol.FillColor = Color.FromArgb(0, 160, 0);
            startMarker.Symbol.LineColor = Color.White;
            startMarker.Font.Name = "Verdana";
            startMarker.Font.Size = 14;
            startMarker.Font.Bold = true;
            startMarker.Font.Color = Color.FromArgb(0, 160, 0);
            startMarker.Font.Outline = true;

            // add an end marker
            ActualMap.MapShape endMarker = routeMarkers.Add(route.EndPoint, "End");
            endMarker.Symbol.FillColor = Color.FromArgb(230, 0, 0);
            endMarker.Symbol.LineColor = Color.White;
            endMarker.Font.Name = "Verdana";
            endMarker.Font.Size = 14;
            endMarker.Font.Bold = true;
            endMarker.Font.Color = Color.FromArgb(230, 0, 0);
            endMarker.Font.Outline = true;

            // add street markers
            for (int street = 1; street < route.Streets.Count; street++)
            {
                routeMarkers.Add(route.Streets[street].Start, Convert.ToString(street));
            }

            ActualMap.Layer markerLayer = map1.AddLayer(routeMarkers);
            markerLayer.Name = "RouteLayerMarkers";
            markerLayer.LabelField = "LABEL";
            markerLayer.ShowLabels = true;

            // set attributes of the street markers as the default symbol/font of the marker layer
            markerLayer.LabelFont.Name = "Verdana";
            markerLayer.LabelFont.Size = 14;
            markerLayer.LabelFont.Bold = true;
            markerLayer.LabelFont.Color = Color.SteelBlue;
            markerLayer.LabelFont.Outline = true;
            markerLayer.Symbol.FillColor = Color.SteelBlue;
            markerLayer.Symbol.LineColor = Color.White;
            markerLayer.Symbol.Size = 8;
        }

        void GenerateDrivingDirections(ActualMap.Route route)
        {
            Streets streets = route.Streets;
            if (streets.Count == 0) return;

            string units;

            if (route.DistanceUnit == MeasureUnit.Mile)
                units = "miles";
            else
                units = "kilometers";

            string direction, distance;

            directions.Columns.Add("Directions", 350);
            directions.Columns.Add("Distance (" + units + ")", 90);

            direction = "Start out going " + streets[0].Direction.ToString() + " on " + streets[0].Name;

            if (streets.Count > 1)
                direction += " towards " + streets[1].Name;

            distance = Convert.ToString(Math.Round(streets[0].Distance, 2));

            directions.Items.Add(new ListViewItem(new String[] { direction, distance } ));

            for (int i = 1; i < streets.Count; i++)
            {
                Street street = streets[i];

                direction = i + ". ";

                if (street.TurnAngle > 30)
                    direction += "Turn LEFT onto " + street.Name;
                else if (street.TurnAngle < -30)
                    direction += "Turn RIGHT onto " + street.Name;
                else
                    direction += "Road name changes to " + street.Name;

                direction += " (" + street.Direction.ToString() + ")";

                distance = Convert.ToString(Math.Round(street.Distance, 2));

                directions.Items.Add(new ListViewItem(new String[] { direction, distance }));
            }

            direction = "Arrive " + streets[streets.Count - 1].Name;

            directions.Items.Add(new ListViewItem(new String[] { direction, "" }));            

            direction = "Total Estimated Time: " + Convert.ToString(Math.Round(route.RouteTime / 60.0, 1)) + " minutes";

            directions.Items.Add(new ListViewItem(new String[] { direction, "" }));

            direction = "Total Distance: " + Convert.ToString(Math.Round(route.RouteDistance, 2)) + " " + units;

            directions.Items.Add(new ListViewItem(new String[] { direction, "" }));
        }

        void ClearRouteLayer()
        {
            int index = map1.GetLayerIndex("RouteLayer");
            if (index >= 0)
                map1.RemoveLayer(index);
            index = map1.GetLayerIndex("RouteLayerMarkers");
            if (index >= 0)
                map1.RemoveLayer(index);

            directions.Columns.Clear();
            directions.Items.Clear();

            _route = null;
        }

        private void directions_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_route == null || directions.SelectedIndices.Count == 0) return;           

            int index = directions.SelectedIndices[0];

            if (index < _route.Streets.Count)
            {
                Street street = _route.Streets[index];
                map1.Extent = street.Shape.Extent;
                map1.Refresh();
            }
        }

        private void toolBar_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
        {
            if (e.Button.Style == ToolBarButtonStyle.ToggleButton)
            {
                foreach (ToolBarButton b in toolBar.Buttons) b.Pushed = false;
                e.Button.Pushed = true;
            }

            if (e.Button == zoomFull)
            {
                map1.ZoomFull();
                map1.Refresh();
            }
            else if (e.Button == zoomInTool) map1.MapTool = MapTool.ZoomIn;
            else if (e.Button == zoomOutTool) map1.MapTool = MapTool.ZoomOut;
            else if (e.Button == panTool) map1.MapTool = MapTool.Pan;
        }
	}
}