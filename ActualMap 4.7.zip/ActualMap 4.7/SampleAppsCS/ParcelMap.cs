using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using ActualMap;
using ActualMap.Windows;


namespace SampleApps
{
    public partial class ParcelMap : Form
    {
        public ParcelMap()
        {
            InitializeComponent();
        }

		private void Form1_Load(object sender, System.EventArgs e)
		{
            // map units of the parcels.shp, streets.shp and aerialphoto.tif files are feet
            map1.MapUnit = MeasureUnit.Foot;

            AddMapLayers();
            UpdateLayerProperties();

            // add a relation to the parcel tax database
            AddRelation();
		}

        // adds a relation to the parcel tax database
        void AddRelation()
        {
            string DataFolder = Application.StartupPath + @"\..\..\DATA\";

            ActualMap.DataSource dataSource = new ActualMap.DataSource();

            string dataFile = DataFolder + "taxattr.mdb";

            dataSource.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + dataFile;
            dataSource.CommandText = "SELECT * From taxattr";

            // create a relation between the parcel shapefile and the 
            // database by the parcel number field
            if (!map1["parcels"].AddRelate("PARNUM", dataSource, "PARNUM"))
            {
                MessageBox.Show("Cannot add a relate to the database: " + dataFile);
            }
        }

		private void AddMapLayers()
		{
            Layer layer;
			
            string LayerFolder = Application.StartupPath + @"\..\..\MAPS\PARCELS\";

            map1.AddLayer(LayerFolder + "aerialphoto.tif");

            // parcel shapefile
            layer = map1.AddLayer(LayerFolder + "parcels.shp");

            layer.LabelField = "PARNUM";
            layer.LabelStyle = LabelStyle.PolygonCenter;
            layer.LabelFont.Size = 14;
            layer.LabelFont.Outline = true;
            layer.LabelFont.OutlineColor = Color.Black;
            layer.LabelFont.Color = Color.White;

            layer.Symbol.FillStyle = FillStyle.Invisible;
            layer.Symbol.LineColor = Color.White;

            // street shapefile
            layer = map1.AddLayer(LayerFolder + "streets.shp");

            layer.LabelField = "STREET";
            layer.LabelFont.Name = "Verdana";
            layer.LabelFont.Size = 14;
            layer.LabelFont.Outline = true;
            layer.LabelFont.OutlineColor = Color.FromArgb(255, 255, 0);

            layer.Symbol.LineStyle = LineStyle.Invisible;
        }
        
        private void map1_MapScaleChanged(object sender, MapScaleChangedEventArgs e)
        {
            // update layers depending on the new scale
            UpdateLayerProperties();
        }

        void UpdateLayerProperties()
        {
            Layer layer = map1["parcels"];
            layer.ShowLabels = (map1.ConvertDistance(map1.Extent.Width, map1.MapUnit, MeasureUnit.Mile) <= 1);

            layer = map1["streets"];
            layer.ShowLabels = (map1.ConvertDistance(map1.Extent.Width, map1.MapUnit, MeasureUnit.Mile) <= 1);
        }

		private void toolBar_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
            if (e.Button.Style == ToolBarButtonStyle.ToggleButton) 
			{
				foreach(ToolBarButton b in toolBar.Buttons) b.Pushed = false;
				e.Button.Pushed = true;
			}

			if (e.Button == zoomFull)
			{
				map1.ZoomFull();
				map1.Refresh();
			}
            if (e.Button == clearShapes)
            {
                map1.MapShapes.Clear();
                map1.Callouts.Clear();
                dataGrid.DataSource = null;
                dataGrid.CaptionText = String.Empty;
                map1.Refresh();
            }
			else if (e.Button == zoomInTool)	map1.MapTool = MapTool.ZoomIn;
			else if (e.Button == zoomOutTool)	map1.MapTool = MapTool.ZoomOut;
			else if (e.Button == panTool)		map1.MapTool = MapTool.Pan;
			else if (e.Button == centerTool)	map1.MapTool = MapTool.Center;
			else if (e.Button == distanceTool)	map1.MapTool = MapTool.Distance;
			else if (e.Button == infoTool)		map1.MapTool = MapTool.Info;
		}

		private void map1_InfoTool(object sender, ActualMap.Windows.InfoToolEventArgs e)
		{
            map1.Callouts.Clear();

            ActualMap.Recordset records = map1.Identify(e.InfoPoint, 5);

            if (!records.EOF)
            {
                dataGrid.DataSource = records;
                dataGrid.CaptionText = records.Layer.Name;

                Callout callout = map1.Callouts.Add();
                callout.X = e.InfoPoint.X;
                callout.Y = e.InfoPoint.Y;
                callout.Text = GetCalloutText(records);
                callout.Font.Size = 16;

                map1.Refresh();
            }			
		}

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			printPreview.ShowDialog();
		}

		private void printDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			Bitmap mapImage = map1.GetBitmap(700, 600);
			e.Graphics.DrawImageUnscaled(mapImage, 50, 50);
		}

        private String GetCalloutText(ActualMap.Recordset rs)
        {
            int index = rs.Fields.GetFieldIndex("NAME");
            if (index < 0) index = rs.Fields.GetFieldIndex(rs.Layer.LabelField);
            if (index < 0) index = 0;
            return rs[index].ToString();
        }

        private void map1_DistanceToolMove(object sender, DistanceToolEventArgs e)
        {
            double distanceInMapUnits = e.Distance;
            double distanceInMiles = Math.Round(map1.ConvertDistance(distanceInMapUnits, map1.MapUnit, MeasureUnit.Mile), 3);
            double distanceInKilometers = Math.Round(map1.ConvertDistance(distanceInMapUnits, map1.MapUnit, MeasureUnit.Kilometer), 3);
            
            statusBar1.Text = distanceInMiles.ToString() + " mi  |  " +
                            distanceInKilometers.ToString() + " km";
        }

        private void map1_DistanceToolFinished(object sender, DistanceToolEventArgs e)
        {
            statusBar1.Text = String.Empty;
        }

        private void btnAddress_Click(object sender, EventArgs e)
        {
            string simpleAddrPattern = @"^(?<num>\d+)\W+(?<street>.+)";

            string address = txtAddress.Text.Trim();

            if (!Regex.IsMatch(address, simpleAddrPattern))
            {
                MessageBox.Show("Invalid address format.");
                return;
            }

            Match m = Regex.Match(address, simpleAddrPattern);

            string houseNum = m.Groups["num"].Value;
            string streetName = m.Groups["street"].Value;

            // strip extra spaces
            streetName = Regex.Replace(streetName, @"\s+", " ");

            string addrExpr = "LIKE(STREET,\"" + streetName + "\") ";

            // search within street numbers range
            if (houseNum.Length > 0)
            {
                addrExpr = addrExpr + "AND ((FRADDL < TOADDL AND (FRADDL <= " + houseNum + " AND " + houseNum + "<= TOADDL)) OR ";
                addrExpr = addrExpr + "(FRADDL > TOADDL AND (FRADDL >= " + houseNum + " AND " + houseNum + " >= TOADDL)) OR ";
                addrExpr = addrExpr + "(FRADDR < TOADDR AND (FRADDR <= " + houseNum + " AND " + houseNum + " <= TOADDR)) OR ";
                addrExpr = addrExpr + "(FRADDR > TOADDR AND (FRADDR >= " + houseNum + " AND " + houseNum + " >= TOADDR)))";
            }

            ActualMap.Recordset records = map1["streets"].SearchExpression(addrExpr);

            if (!records.EOF)
            {
                map1.Extent = records.RecordExtent;
                map1.Refresh();
            }
            else
                MessageBox.Show("Address not found.");
        }

        private void btnParcel_Click(object sender, EventArgs e)
        {
            string expr = "PARNUM = \"" + txtParcel.Text.Trim() + "\"";

            ActualMap.Recordset rs = map1["parcels"].SearchExpression(expr);

            if (rs.EOF)
            {
                MessageBox.Show("Parcel number not found.");
                return;
            }

            map1.Callouts.Clear();

            dataGrid.DataSource = rs;
            dataGrid.CaptionText = rs.Layer.Name.ToUpper();

            Callout callout = map1.Callouts.Add();
            ActualMap.Point center = rs.Shape.Centroid;
            callout.X = center.X;
            callout.Y = center.Y;
            callout.Text = rs["PARNUM"] + "\n" + rs["OWNERNAME"];
            callout.Font.Size = 16;

            map1.Extent = rs.RecordExtent;

            map1.Refresh();
        }

        private void btnOwner_Click(object sender, EventArgs e)
        {
            string expr = "LIKE(OWNERNAME,\"" + txtOwner.Text.Trim() + "*\")";

            ActualMap.Recordset rs = map1["parcels"].SearchExpression(expr);

            if (rs.EOF)
            {
                MessageBox.Show("Owner not found.");
                return;
            }

            map1.Callouts.Clear();

            dataGrid.DataSource = rs;
            dataGrid.CaptionText = rs.Layer.Name.ToUpper();

            Callout callout = map1.Callouts.Add();
            ActualMap.Point center = rs.Shape.Centroid;
            callout.X = center.X;
            callout.Y = center.Y;
            callout.Text = rs["PARNUM"] + "\n" + rs["OWNERNAME"];
            callout.Font.Size = 16;

            ActualMap.Rectangle extent = rs.RecordExtent;
            extent.Inflate(extent.Width * 0.8, extent.Height * 0.8);
            map1.Extent = extent;

            map1.Refresh();
        }
	}
}