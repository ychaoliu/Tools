using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ActualMap;
using ActualMap.Windows;

namespace SampleApps
{
    public partial class DemographicMap : Form
    {
        public DemographicMap()
        {
            InitializeComponent();
        }

		private void Form1_Load(object sender, System.EventArgs e)
		{
            AddMapLayers();

            ActualMap.Fields fields = map1["USA"].Recordset.Fields;
            for (int i = 4; i < fields.Count; i++)
                thematicFields.Items.Add(fields[i].Name);

            thematicFields.SelectedIndex = 0;
            
            DoThematicMapping();                       
		}

        void DoThematicMapping()
        {
            double Delta, Prev, Curr;

            map1["USA"].Renderer.Clear();
            legend1.Clear();

            string field = thematicFields.SelectedItem.ToString();

            // calculate statistics
            ActualMap.Statistics statistics = map1["USA"].Recordset.CalculateStatistics(field);

            // calculate ranges
            Color[] colors = { Color.FromArgb(251, 234, 208), Color.FromArgb(248, 215, 165), 
								 Color.FromArgb(244, 197, 125), Color.FromArgb(240, 174, 74),
								 Color.FromArgb(236, 130, 55), Color.FromArgb(230, 100, 40) };

            Delta = (statistics.Max - statistics.Min) / colors.Length;
            Prev = statistics.Min;

            legend1.Add("No data", LayerType.Polygon, map1["USA"].Symbol);

            for (int index = 0; index < colors.Length; index++)
            {
                Curr = Prev + Delta;

                ActualMap.Feature feature = map1["USA"].Renderer.Add();
                feature.Expression = field + "<=" + Convert.ToInt32(Curr);
                feature.Symbol.FillColor = colors[index];
                feature.Symbol.LineColor = Color.White;

                legend1.Add(Convert.ToInt32(Prev) + " - " + Convert.ToInt32(Curr), LayerType.Polygon, feature.Symbol);

                Prev = Curr;
            }

            map1.Refresh();
        }

		private void AddMapLayers()
		{
            ActualMap.DataSource dataSource = new ActualMap.DataSource();
            string LayerFolder = Application.StartupPath + @"\..\..\MAPS\USA\";

            ActualMap.Layer layer = map1.AddLayer(LayerFolder + "USA.shp");

            layer.Symbol.FillColor = Color.White; // no data
            layer.ShowLabels = true;
            layer.LabelField = "STATE_ABBR";
            layer.LabelStyle = LabelStyle.PolygonCenter;

            string dataFile = Application.StartupPath + @"\..\..\DATA\demography.mdb";

            dataSource.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + dataFile;
            dataSource.CommandText = "SELECT * FROM demography";

            // create a relation between the USA shapefile and the 
            // database by the state abbreviation field
            if (!map1["USA"].AddRelate("STATE_ABBR", dataSource, "STATE_ABBR"))
            {
                MessageBox.Show("Cannot add a relate to the database: " + dataFile);
            }
		}

        private void thematicFields_SelectedIndexChanged(object sender, EventArgs e)
        {
            DoThematicMapping();
        }       
	}
}