using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ActualMap;
using ActualMap.Data;
using ActualMap.Windows;

namespace SampleApps
{
    public partial class Airports : Form
    {
        public Airports()
        {
            InitializeComponent();
        }

		private void Form1_Load(object sender, System.EventArgs e)
		{
            AddMapLayers();
            AddDatabase();
		}

        void AddDatabase()
        {
            string SymbolFolder = Application.StartupPath + @"\..\..\SYMBOLS\";            

            string dataFile = Application.StartupPath + @"\..\..\DATA\airports.mdb";
            string connectionString = "PROVIDER=Microsoft.Jet.OLEDB.4.0;DATA Source=" + dataFile;

            PointDataLayer pointData = new PointDataLayer("System.Data.OleDb", connectionString, "airports", "LONGITUDE", "LATITUDE");

            Layer dbLayer = map1.AddLayer(pointData);

            if (dbLayer == null)
            {
                MessageBox.Show("Cannot add airports.mdb database.");
                return;
            }

            dbLayer.Name = "database";
            dbLayer.Symbol.Size = 16; // default symbol size

            // render airports depenfing on the value of the AVAILABLE field
            dbLayer.Renderer.Field = "AVAILABLE";

            // available airports
            Feature feature = dbLayer.Renderer.Add();
            feature.Value = "Yes";
            feature.Symbol.Size = 16;
            feature.Symbol.PointStyle = PointStyle.Bitmap;
            feature.Symbol.Bitmap = SymbolFolder + "airport.bmp";
            feature.LabelFont.Color = Color.Green;
            feature.LabelFont.Bold = true;

            // closed airports
            feature = dbLayer.Renderer.Add();
            feature.Value = "No";
            feature.Symbol.Size = 16;
            feature.Symbol.PointStyle = PointStyle.Bitmap;
            feature.Symbol.Bitmap = SymbolFolder + "airport_closed.bmp";
            feature.LabelFont.Color = Color.Red;
            feature.LabelFont.Bold = true;
        }

		private void AddMapLayers()
		{
            Layer layer;
            Feature feature;
            FeatureRenderer renderer;
			
            string LayerFolder = Application.StartupPath + @"\..\..\MAPS\USA\";

            //- STATES -------------------------------------------
            layer = map1.AddLayer(LayerFolder + "states.shp");

            layer.LabelField = "STATE_ABBR";
            layer.ShowLabels = true;
            layer.LabelFont.Name = "Verdana";
            layer.LabelFont.Size = 12;
            layer.LabelFont.Bold = true;
            layer.LabelStyle = LabelStyle.PolygonCenter;

            //- ROADS -------------------------------------------
            layer = map1.AddLayer(LayerFolder + "roads.shp");

            // default symbol
            layer.LabelField = "NUMBER";
            layer.ShowLabels = true;
            layer.DuplicateLabels = false;
            layer.LabelFont.Size = 12;
            layer.Symbol.LineColor = Color.FromArgb(255, 0, 0);
            layer.Symbol.Size = 2;

            //- CITIES --------------------------------------------
            layer = map1.AddLayer(LayerFolder + "cities.shp");

            layer.LabelField = "CITY_NAME";
            layer.ShowLabels = true;
            
            // render state capitals only
            layer.UseDefaultSymbol = false;
            renderer = map1["cities"].Renderer;                        
            feature = renderer.Add();
            feature.Expression = "CAPITAL = \"Y\"";
            feature.Symbol.PointStyle = PointStyle.CircleWithLargeCenter;
            feature.Symbol.Size = 10;
            feature.Symbol.FillColor = Color.FromArgb(255, 255, 0);
            feature.LabelFont.Name = "Arial";
            feature.LabelFont.Bold = true;
            feature.LabelFont.Size = 14;
            feature.LabelFont.Outline = true;
            feature.LabelFont.OutlineColor = Color.FromArgb(255, 255, 0);
		}

        string SymbolFolder = Application.StartupPath + @"\..\..\SYMBOLS\";

		private void toolBar_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
            if (e.Button.Style == ToolBarButtonStyle.ToggleButton) 
			{
				foreach(ToolBarButton b in toolBar.Buttons) b.Pushed = false;
				e.Button.Pushed = true;
			}

			if (e.Button == zoomFull)
			{
				map1.ZoomFull();
				map1.Refresh();
			}
            if (e.Button == clearShapes)
            {
                map1.MapShapes.Clear();
                map1.Callouts.Clear();
                dataGrid.DataSource = null;
                dataGrid.CaptionText = String.Empty;
                map1.Refresh();
            }
			else if (e.Button == zoomInTool)	map1.MapTool = MapTool.ZoomIn;
			else if (e.Button == zoomOutTool)	map1.MapTool = MapTool.ZoomOut;
			else if (e.Button == panTool)		map1.MapTool = MapTool.Pan;
			else if (e.Button == centerTool)	map1.MapTool = MapTool.Center;
			else if (e.Button == infoTool)		map1.MapTool = MapTool.Info;
		}

		private void map1_InfoTool(object sender, ActualMap.Windows.InfoToolEventArgs e)
		{
            map1.Callouts.Clear();
            dataGrid.DataSource = null;

            ActualMap.Recordset records = map1["database"].SearchByDistance(e.InfoPoint, map1.ToMapDistance(6));

            if (!records.EOF)
            {                
                dataGrid.DataSource = records;
                dataGrid.CaptionText = records.Layer.Name;

                Callout callout = map1.Callouts.Add();
                callout.X = e.InfoPoint.X;
                callout.Y = e.InfoPoint.Y;
                callout.Text = records["DESCRIP"].ToString();
                callout.Font.Size = 16;
            }

            map1.Refresh();
		}

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			printPreview.ShowDialog();
		}

		private void printDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			Bitmap mapImage = map1.GetBitmap(700, 600);
			e.Graphics.DrawImageUnscaled(mapImage, 50, 50);
		}
	}
}