using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.IO;
using System.Windows.Forms;
using ActualMap;
using ActualMap.Windows;

namespace SampleApps
{
    public partial class RouteTutorial : Form
    {
        public RouteTutorial()
        {
            InitializeComponent();
        }

		private void Form1_Load(object sender, System.EventArgs e)
		{
            string RouteFiles = Application.StartupPath + @"\..\..\MAPS\ROUTING\";

            // create a Network Object
            ActualMap.Network roadNetwork = new ActualMap.Network();

            // load the road network
            roadNetwork.Open(RouteFiles + "streets.shp", RouteFiles + "streets.rtn");

            // create a Route Object
            ActualMap.Route route;
            route = roadNetwork.CreateRoute();

            // start/end coordinates
            double StartX, StartY, EndX, EndY;
            StartX = -71.5591; // start longitude 
            StartY = 43.1851;  // start latitude
            EndX = -71.5227;   // end longitude 
            EndY = 43.2542;    // end latitude

            // set the route optimization: quickest or shortest
            route.RouteType = RouteType.Quickest;

            // set the current date for turn restrictions
            route.CurrentDate = DateTime.Now;


            // find the route
            if (!route.FindRoute(StartX, StartY, EndX, EndY))
            {
                MessageBox.Show("Route not found.");
                return;
            }

            // merge the road segments to streets
            route.MergeSegments("NAME;TYPE");

            // add the route to the map as a layer
            ActualMap.Layer routeLayer = map1.AddLayer(route);
            routeLayer.Symbol.LineColor = Color.FromArgb(198, 86, 245);
            routeLayer.Symbol.Size = 6;

            // add the streets.shp layer to the map
            ActualMap.Layer streetLayer = map1.AddLayer(RouteFiles + "streets.shp");
            streetLayer.ShowLabels = true;
            streetLayer.LabelField = "NAME";

            // set the extent of the route as the current extent of the map
            map1.Extent = route.Extent;

            // add driving directions to listView1
            GenerateDirections(route);
        }

        void GenerateDirections(ActualMap.Route route)
        {
            Streets streets = route.Streets;
            if (streets.Count == 0) return;

            string units;

            if (route.DistanceUnit == MeasureUnit.Mile)
                units = "miles";
            else
                units = "kilometers";

            string direction, distance;

            listView1.Columns.Add("Directions", 350);
            listView1.Columns.Add("Distance (" + units + ")", 90);

            direction = "Start out going " + streets[0].Direction.ToString() + " on " + streets[0].Name;

            if (streets.Count > 1)
                direction += " towards " + streets[1].Name;

            distance = Convert.ToString(Math.Round(streets[0].Distance, 2));

            listView1.Items.Add(new ListViewItem(new String[] { direction, distance } ));

            for (int i = 1; i < streets.Count; i++)
            {
                Street street = streets[i];

                direction = i + ". ";

                if (street.TurnAngle > 30)
                    direction += "Turn LEFT onto " + street.Name;
                else if (street.TurnAngle < -30)
                    direction += "Turn RIGHT onto " + street.Name;
                else
                    direction += "Road name changes to " + street.Name;

                direction += " (" + street.Direction.ToString() + ")";

                distance = Convert.ToString(Math.Round(street.Distance, 2));

                listView1.Items.Add(new ListViewItem(new String[] { direction, distance }));
            }

            direction = "Arrive " + streets[streets.Count - 1].Name;

            listView1.Items.Add(new ListViewItem(new String[] { direction, "" }));            

            direction = "Total Estimated Time: " + Convert.ToString(Math.Round(route.RouteTime / 60.0, 1)) + " minutes";

            listView1.Items.Add(new ListViewItem(new String[] { direction, "" }));

            direction = "Total Distance: " + Convert.ToString(Math.Round(route.RouteDistance, 2)) + " " + units;

            listView1.Items.Add(new ListViewItem(new String[] { direction, "" }));
        }

        private void toolBar_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
        {
            if (e.Button.Style == ToolBarButtonStyle.ToggleButton)
            {
                foreach (ToolBarButton b in toolBar.Buttons) b.Pushed = false;
                e.Button.Pushed = true;
            }

            if (e.Button == zoomFull)
            {
                map1.ZoomFull();
                map1.Refresh();
            }
            else if (e.Button == zoomInTool) map1.MapTool = MapTool.ZoomIn;
            else if (e.Button == zoomOutTool) map1.MapTool = MapTool.ZoomOut;
            else if (e.Button == panTool) map1.MapTool = MapTool.Pan;
        }
	}
}