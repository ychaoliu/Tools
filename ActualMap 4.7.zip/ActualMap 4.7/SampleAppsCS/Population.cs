using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ActualMap;
using ActualMap.Windows;

namespace SampleApps
{
    public partial class Population : Form
    {
        public Population()
        {
            InitializeComponent();
        }

		private void Form1_Load(object sender, System.EventArgs e)
		{
            AddMapLayers();

            DoThematicMapping();

            // fill the states combobox
            Layer layer = map1.FindLayer("states");
            if (layer != null)
            {
                Recordset records = layer.Recordset;
                while (!records.EOF)
                {
                    statesList.Items.Add(records["STATE_NAME"]);
                    records.MoveNext();
                }
            }
		}

        void DoThematicMapping()
        {
            legend1.IconWidth = 30;
            legend1.IconHeight = 28;
                        
            ActualMap.Feature feature;
            ActualMap.Layer layer = map1["cities"];
            ActualMap.FeatureRenderer renderer = layer.Renderer;

            //*******************************
            feature = renderer.Add();
            feature.Expression = "POP <= 5000";
            feature.Symbol.FillColor = Color.White;
            feature.Symbol.Size = 4;

            legend1.Add("0 - 5000", layer.LayerType, feature.Symbol);

            //*******************************
            feature = renderer.Add();
            feature.Expression = "POP <= 50000";
            feature.Symbol.FillColor = Color.FromArgb(255, 255, 0);
            feature.Symbol.Size = 8;

            legend1.Add("5000 - 50000", layer.LayerType, feature.Symbol);

            //*******************************
            feature = renderer.Add();
            feature.Expression = "POP <= 250000";
            feature.Symbol.FillColor = Color.FromArgb(255, 0, 255);
            feature.Symbol.Size = 12;

            legend1.Add("50000 - 250000", layer.LayerType, feature.Symbol);

            //*******************************
            feature = renderer.Add();
            feature.Expression = "POP <= 500000";
            feature.Symbol.FillColor = Color.Blue;
            feature.Symbol.Size = 16;

            legend1.Add("250000 - 500000", layer.LayerType, feature.Symbol);

            //*******************************
            feature = renderer.Add();
            feature.Expression = "POP <= 1000000";
            feature.Symbol.FillColor = Color.FromArgb(0, 255, 255);
            feature.Symbol.Size = 20;

            legend1.Add("500000 - 1000000", layer.LayerType, feature.Symbol);

            //*******************************
            feature = renderer.Add();
            feature.Expression = "POP <= 5000000";
            feature.Symbol.FillColor = Color.Green;
            feature.Symbol.Size = 24;

            legend1.Add("1000000 - 5000000", layer.LayerType, feature.Symbol);

            //*******************************
            feature = renderer.Add();
            feature.Expression = "POP > 5000000";
            feature.Symbol.FillColor = Color.Red;
            feature.Symbol.Size = 28;

            legend1.Add("5000000 +", layer.LayerType, feature.Symbol);
        }

		private void AddMapLayers()
		{
            Layer layer;
			
            string LayerFolder = Application.StartupPath + @"\..\..\MAPS\USA\";

            //- STATES -------------------------------------------
            layer = map1.AddLayer(LayerFolder + "states.shp");

            layer.LabelField = "STATE_ABBR";
            layer.ShowLabels = true;
            layer.LabelFont.Name = "Verdana";
            layer.LabelFont.Size = 12;
            layer.LabelFont.Bold = true;
            layer.LabelStyle = LabelStyle.PolygonCenter;

            //- CITIES --------------------------------------------
            layer = map1.AddLayer(LayerFolder + "cities.shp");

            layer.LabelField = "CITY_NAME";
            layer.ShowLabels = true;
            layer.UseDefaultSymbol = false;
		}

        private void map1_MapScaleChanged(object sender, MapScaleChangedEventArgs e)
        {
            ActualMap.Layer layer = map1["cities"];
            layer.ShowLabels = map1.ConvertDistance(map1.Extent.Width, map1.MapUnit, MeasureUnit.Mile) <= 500;
        }

		private void toolBar_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
            if (e.Button.Style == ToolBarButtonStyle.ToggleButton) 
			{
				foreach(ToolBarButton b in toolBar.Buttons) b.Pushed = false;
				e.Button.Pushed = true;
			}

			if (e.Button == zoomFull)
			{
				map1.ZoomFull();
				map1.Refresh();
			}
			else if (e.Button == zoomInTool)	map1.MapTool = MapTool.ZoomIn;
			else if (e.Button == zoomOutTool)	map1.MapTool = MapTool.ZoomOut;
			else if (e.Button == panTool)		map1.MapTool = MapTool.Pan;
			else if (e.Button == infoTool)		map1.MapTool = MapTool.Info;
		}

		private void map1_InfoTool(object sender, ActualMap.Windows.InfoToolEventArgs e)
		{
            map1.Callouts.Clear();

            ActualMap.Recordset records = map1.Identify(e.InfoPoint, 5);

            if (!records.EOF)
            {
                dataGrid.DataSource = records;
                dataGrid.CaptionText = records.Layer.Name;

                Callout callout = map1.Callouts.Add();
                callout.X = e.InfoPoint.X;
                callout.Y = e.InfoPoint.Y;
                callout.Text = GetCalloutText(records);
                callout.Font.Size = 16;

                map1.Refresh();
            }			
		}

        private String GetCalloutText(ActualMap.Recordset rs)
        {
            int index = rs.Fields.GetFieldIndex("NAME");
            if (index < 0) index = rs.Fields.GetFieldIndex(rs.Layer.LabelField);
            if (index < 0) index = 0;
            return rs[index].ToString();
        }

        private void statesList_SelectedIndexChanged(object sender, EventArgs e)
        {
            Recordset state;
            state = map1["states"].SearchExpression("STATE_NAME = \"" + statesList.SelectedItem + "\"");
            if (!state.EOF)
            {
                map1.Extent = state.RecordExtent;

                // select the state shape with a red outline
                map1.MapShapes.Clear();
                MapShape shape = map1.MapShapes.Add(state.Shape);
                Symbol s = new Symbol();
                s.FillStyle = FillStyle.Invisible;
                s.LineColor = Color.Red;
                s.Size = 3;
                shape.Symbol = s;

                map1.Refresh();
            }
        }
	}
}