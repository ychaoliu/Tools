using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ActualMap;
using ActualMap.Windows;

namespace SampleApps
{
    public partial class ProjectedWorldMap : Form
    {
        public ProjectedWorldMap()
        {
            InitializeComponent();
        }

        class ListItem
        {
            public string name;
            public CoordSystemCode code;
            public ListItem(string name, CoordSystemCode code) { this.name = name; this.code = code; }
            public override string ToString() { return name; }
        };

		private void Form1_Load(object sender, System.EventArgs e)
		{
            AddMapLayers();

            coordSystemList.Items.Add(new ListItem("World Robinson", CoordSystemCode.PCS_WorldRobinson));
            coordSystemList.Items.Add(new ListItem("Plate Carree", CoordSystemCode.PCS_WorldPlateCarree));
            coordSystemList.Items.Add(new ListItem("World Equidistant Cylindrical", CoordSystemCode.PCS_WorldEquidistantCylindrical));
            coordSystemList.Items.Add(new ListItem("WorldMiller Cylindrical", CoordSystemCode.PCS_WorldMillerCylindrical));
            coordSystemList.Items.Add(new ListItem("World Mercator", CoordSystemCode.PCS_WorldMercator));
            coordSystemList.Items.Add(new ListItem("World Sinusoidal", CoordSystemCode.PCS_WorldSinusoidal));
            coordSystemList.Items.Add(new ListItem("World Mollweide", CoordSystemCode.PCS_WorldMollweide));
            coordSystemList.Items.Add(new ListItem("World Eckert I", CoordSystemCode.PCS_WorldEckertI));
            coordSystemList.Items.Add(new ListItem("World Eckert II", CoordSystemCode.PCS_WorldEckertII));
            coordSystemList.Items.Add(new ListItem("World Eckert III", CoordSystemCode.PCS_WorldEckertIII));
            coordSystemList.Items.Add(new ListItem("World Eckert IV", CoordSystemCode.PCS_WorldEckertIV));
            coordSystemList.Items.Add(new ListItem("World Eckert V", CoordSystemCode.PCS_WorldEckertV));
            coordSystemList.Items.Add(new ListItem("World Eckert VI", CoordSystemCode.PCS_WorldEckertVI));
            coordSystemList.Items.Add(new ListItem("World Gall Stereographic", CoordSystemCode.PCS_WorldGallStereographic));
            coordSystemList.Items.Add(new ListItem("World Winkel I", CoordSystemCode.PCS_WorldWinkelI));
            coordSystemList.Items.Add(new ListItem("World Winkel II", CoordSystemCode.PCS_WorldWinkelII));
            coordSystemList.Items.Add(new ListItem("World Polyconic", CoordSystemCode.PCS_WorldPolyconic));
            coordSystemList.Items.Add(new ListItem("World Quartic Authalic", CoordSystemCode.PCS_WorldQuarticAuthalic));
            coordSystemList.Items.Add(new ListItem("World Loximuthal", CoordSystemCode.PCS_WorldLoximuthal));
            coordSystemList.Items.Add(new ListItem("World Bonne", CoordSystemCode.PCS_WorldBonne));
            coordSystemList.Items.Add(new ListItem("World Vander Grinten I", CoordSystemCode.PCS_WorldVanderGrintenI));
            coordSystemList.Items.Add(new ListItem("World Two Point Equidistant", CoordSystemCode.PCS_WorldTwoPointEquidistant));

            coordSystemList.SelectedIndex = 0;
		}

		private void AddMapLayers()
		{
            Layer layer;

            string LayerFolder = Application.StartupPath + @"\..\..\MAPS\WORLD\";
                                           
            // world
            layer = map1.AddLayer(LayerFolder + "world.shp");
            layer.CoordinateSystem = CoordSystem.WGS1984;

            layer.ShowLabels = true;
            layer.LabelField = "NAME";
            layer.LabelFont.Name = "Verdana";
            layer.LabelFont.Size = 12;
            layer.LabelStyle = LabelStyle.PolygonCenter;
            layer.Opacity = 0.6;

            // lakes
            layer = map1.AddLayer(LayerFolder + "lakes.shp");
            layer.CoordinateSystem = CoordSystem.WGS1984;

            layer.ShowLabels = true;
            layer.LabelField = "NAME";
            layer.LabelFont.Size = 10;
            layer.LabelFont.Outline = true;
            layer.Symbol.FillColor = Color.Blue;
            layer.Symbol.LineColor = layer.Symbol.FillColor;
            layer.LabelStyle = LabelStyle.PolygonCenter;

            // capitals
            layer = map1.AddLayer(LayerFolder + "capitals.shp");
            layer.CoordinateSystem = CoordSystem.WGS1984;

            layer.ShowLabels = true;
            layer.LabelField = "NAME";
            layer.LabelFont.Bold = true;
            layer.LabelFont.Size = 11;
            layer.LabelFont.Outline = true;
            layer.Symbol.PointStyle = PointStyle.CircleWithLargeCenter;
            layer.Symbol.Size = 8;
            layer.Symbol.FillColor = Color.White;
		}

        private void coordSystemList_SelectedIndexChanged(object sender, EventArgs e)
        {
            ListItem item = (ListItem)coordSystemList.SelectedItem;
            map1.CoordinateSystem = new ActualMap.CoordSystem(item.code);
            map1.Refresh();
        }

	}
}