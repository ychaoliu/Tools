using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ActualMap;
using ActualMap.Windows;
using ActualMap.Web;

namespace SampleApps
{
    public partial class WMSBrowser : Form
    {
        WmsLayer wmsLayer;
        WmsCapabilities wmsCaps;

        public WMSBrowser()
        {
            InitializeComponent();
        }

		private void Form1_Load(object sender, System.EventArgs e)
		{
            url.Text = "http://webservices.nationalatlas.gov/wms/boundaries"; // see also http://nationalatlas.gov/infodocs/wms_intro.html
		}

        private void Form1_Shown(object sender, EventArgs e)
        {
            ReloadWmsLayer();
        }

        private void ReloadWmsLayer()
        {
            map1.RemoveAllLayers();
            map1.Callouts.Clear();
            Cursor = Cursors.WaitCursor;

            if (wmsCaps == null)
            {
                Clear();

                try
                {
                    wmsCaps = new WmsCapabilities(url.Text.Trim());
                    
                    if (wmsCaps.Layers.Count == 0)
                        throw new Exception("Layers not found");
                    
                    wmsLayers.DataSource = wmsCaps.Layers;
                    wmsLayers.DisplayMember = "Name";

                    wmsTitle.Text = wmsCaps.ServiceTitle;

                    UpdateLayerInfo();
                }
                catch (Exception ex)
                {
                    map1.Refresh();
                    MessageBox.Show(ex.Message, "Error");
                    return;
                }
            }

            wmsLayer = new WmsLayer(wmsCaps.MapUrl);
            
            if (layerStyles.Items.Count == 0)
                wmsLayer.AddLayer(wmsCaps.Layers[wmsLayers.SelectedIndex].Name,
                    wmsCaps.Layers[wmsLayers.SelectedIndex].GeoExtent);
            else
                wmsLayer.AddLayer(wmsCaps.Layers[wmsLayers.SelectedIndex].Name,                
                            wmsCaps.Layers[wmsLayers.SelectedIndex].GeoExtent,
                            wmsCaps.Layers[wmsLayers.SelectedIndex].Styles[layerStyles.SelectedIndex].Name);

            wmsLayer.Transparent = true;
            wmsLayer.ImageFormat = ImageFormat.Png;

            map1.AddLayer(wmsLayer);

            map1.ZoomFull();
            map1.Refresh();

            Cursor = Cursors.Default;
        }

        private void wmsLayers_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (wmsCaps == null) return;

            ReloadWmsLayer();
        }

        private void layerStyles_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (wmsCaps == null) return;

            ReloadWmsLayer();
        }

        private void map1_BeforeMapDraw(object sender, MapDrawEventArgs e)
        {
            Cursor = Cursors.WaitCursor;
        }

        private void map1_AfterMapDraw(object sender, MapDrawEventArgs e)
        {
            Cursor = Cursors.Default;
        }

        private void url_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Return)
            {
                e.Handled = true;

                if (String.IsNullOrEmpty(url.Text.Trim()))
                    return;

                wmsCaps = null;

                ReloadWmsLayer();
            }
        }

        void UpdateLayerInfo()
        {
            WmsLayerInfo info = wmsCaps.Layers[wmsLayers.SelectedIndex];

            layerName.Text = info.Name;
            layerTitle.Text = info.Title;
            layerAbstract.Text = info.Abstract;

            layerStyles.DataSource = info.Styles;
            layerStyles.DisplayMember = "name";        
        }

        // search for features in the WMS layer
        private void map1_InfoTool(object sender, ActualMap.Windows.InfoToolEventArgs e)
        {
            if (wmsCaps == null) return;

            Cursor = Cursors.WaitCursor;
            map1.Callouts.Clear();

            try
            {               
                string info = map1.GetWmsFeatureInfo(wmsCaps.MapUrl,
                    wmsCaps.Layers[wmsLayers.SelectedIndex].Name, e.InfoPoint, 1, "text/plain");

                if (info != null)
                {
                    Callout callout = map1.Callouts.Add();
                    callout.X = e.InfoPoint.X;
                    callout.Y = e.InfoPoint.Y;
                    callout.Text = info;
                    callout.Font.Size = 14;

                    map1.Refresh();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
            Cursor = Cursors.Default;
        }

        void Clear()
        {
            wmsTitle.Text = String.Empty;
            layerName.Text = String.Empty;
            layerTitle.Text = String.Empty;
            layerAbstract.Text = String.Empty;
            wmsLayers.DataSource = null;
            layerStyles.DataSource = null;        
        }
        
		private void toolBar_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
            if (e.Button.Style == ToolBarButtonStyle.ToggleButton) 
			{
				foreach(ToolBarButton b in toolBar.Buttons) b.Pushed = false;
				e.Button.Pushed = true;
			}

            map1.Cursor = Cursors.Default;

			if (e.Button == zoomFull)
			{
				map1.ZoomFull();
				map1.Refresh();
			}
            else if (e.Button == clearShapes)
            {
                map1.Callouts.Clear();
                map1.Refresh();
            }
			else if (e.Button == zoomInTool)	map1.MapTool = MapTool.ZoomIn;
			else if (e.Button == zoomOutTool)	map1.MapTool = MapTool.ZoomOut;
            else if (e.Button == panTool)
            {
                map1.MapTool = MapTool.Pan;
                map1.Cursor = Cursors.SizeAll;
            }
			else if (e.Button == infoTool)		map1.MapTool = MapTool.Info;
		}

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			printPreview.ShowDialog();
		}

		private void printDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			Bitmap mapImage = map1.GetBitmap(700, 600);
			e.Graphics.DrawImageUnscaled(mapImage, 50, 50);
		}

        private String GetCalloutText(ActualMap.Recordset rs)
        {
            int index = rs.Fields.GetFieldIndex("NAME");
            if (index < 0) index = rs.Fields.GetFieldIndex(rs.Layer.LabelField);
            if (index < 0) index = 0;
            return rs[index].ToString();
        }

	}
}