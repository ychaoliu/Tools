using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ActualMap;
using ActualMap.Windows;

namespace SampleApps
{
    public partial class StreetMap : Form
    {
        public StreetMap()
        {
            InitializeComponent();
        }

		private void Form1_Load(object sender, System.EventArgs e)
		{
            AddMapLayers();

            legend1.Populate(map1);
		}

		private void AddMapLayers()
		{
            Layer layer;
            Feature feature;
            FeatureRenderer renderer;
			
            string LayerFolder = Application.StartupPath + @"\..\..\MAPS\STREETS\";
            string SymbolFolder = Application.StartupPath + @"\..\..\SYMBOLS\";

            //- COUNTY -------------------------------------------
            layer = map1.AddLayer(LayerFolder + "County.shp");

            layer.LabelField = "NAME";
            layer.Symbol.Size = 2;
            layer.Symbol.LineColor = Color.FromArgb(199, 172, 116);
            layer.Symbol.FillColor = Color.FromArgb(242, 236, 223);

            //- PARKS --------------------------------------------
            layer = map1.AddLayer(LayerFolder + "Park.shp");

            layer.LabelField = "NAME";
            layer.ShowLabels = true;
            layer.LabelFont.Outline = true;
            layer.LabelFont.Size = 11;
            layer.LabelFont.Bold = true;
            layer.Symbol.FillColor = Color.FromArgb(143, 175, 47);
            layer.Symbol.LineColor = layer.Symbol.FillColor;
            
            //- WATER AREAS --------------------------------------
            layer = map1.AddLayer(LayerFolder + "WaterArea.shp");
            layer.MaxScale = 300000;

            layer.LabelField = "NAME";
            layer.ShowLabels = true;
            layer.LabelFont.Outline = true;
            layer.LabelFont.Size = 12;
            layer.Symbol.FillColor = Color.FromArgb(159, 159, 223);
            layer.Symbol.LineColor = layer.Symbol.FillColor;
            
            //- RIVERS -------------------------------------------
            layer = map1.AddLayer(LayerFolder + "Water.shp");
            layer.MaxScale = 300000;

            layer.LabelField = "NAME";
            layer.ShowLabels = true;
            layer.LabelFont.Size = 9;
            layer.Symbol.FillColor = Color.FromArgb(159, 159, 223);
            layer.Symbol.LineColor = layer.Symbol.FillColor;
            layer.LabelFont.Color = Color.FromArgb(0, 0, 128);
            
            //- AIRPORTS -----------------------------------------
            layer = map1.AddLayer(LayerFolder + "Airport.shp");

            layer.LabelField = "NAME";
            layer.ShowLabels = true;
            layer.LabelFont.Outline = true;
            layer.LabelFont.Size = 11;
            layer.Symbol.FillColor = Color.FromArgb(43, 147, 43);

            //- STREETS ------------------------------------------
            layer = map1.AddLayer(LayerFolder + "Street.shp");
            layer.MaxScale = 150000;

            layer.LabelField = "NAME";
            layer.LabelFont.Size = 10;
            layer.ShowLabels = true;
            layer.Symbol.LineStyle = LineStyle.Road;
            layer.Symbol.LineColor = Color.FromArgb(171, 158, 137);
            layer.Symbol.InnerColor = Color.White;

            // set different line width of the streets for different scales
            feature = new ActualMap.Feature();
            feature.MaxScale = 75000;
            feature.MinScale = 37000;
            feature.Symbol.LineStyle = LineStyle.Road;
            feature.Symbol.LineColor = Color.FromArgb(171, 158, 137);
            feature.Symbol.InnerColor = Color.White;
            feature.Symbol.Size = 3;
            layer.Renderer.Add(feature);

            feature = feature.Clone();
            feature.MaxScale = 37000;
            feature.MinScale = 16000;
            feature.Symbol.Size = 4;
            feature.LabelFont.Outline = true;
            layer.Renderer.Add(feature);

            feature = feature.Clone();
            feature.MaxScale = 16000;
            feature.MinScale = -1; // no minimum scale
            feature.Symbol.Size = 6;
            layer.Renderer.Add(feature);

            //- RAILROADS ----------------------------------------
            layer = map1.AddLayer(LayerFolder + "Railroad.shp");
            layer.MaxScale = 200000;

            layer.LabelField = "NAME";
            layer.ShowLabels = true;
            layer.LabelFont.Outline = true;
            layer.LabelFont.Size = 10;
            layer.Symbol.LineStyle = LineStyle.Railroad;

            //- INSTITUTIONS -------------------------------------
            layer = map1.AddLayer(LayerFolder + "Institution.shp");

            layer.LabelField = "NAME";
            layer.ShowLabels = true;
            layer.LabelFont.Name = "Times New Roman";
            layer.LabelFont.Outline = true;
            layer.LabelFont.Size = 12;
            layer.UseDefaultSymbol = false;

            renderer = layer.Renderer;
            renderer.Field = "FCC";

            // cemetery symbol
            feature = renderer.Add();
            feature.Value = "D82";
            feature.Symbol.PointStyle = PointStyle.Bitmap;
            feature.Symbol.Bitmap = SymbolFolder + "cemetery.bmp";
            feature.Symbol.Size = 16;
            feature.Symbol.TransparentColor = Color.White;
            feature.Description = "Cemetery";

            // school symbol
            feature = renderer.Add();
            feature.Value = "D43";
            feature.Symbol.PointStyle = PointStyle.Bitmap;
            feature.Symbol.Bitmap = SymbolFolder + "school.bmp";
            feature.Symbol.Size = 16;
            feature.Symbol.TransparentColor = Color.White;
            feature.Description = "School";

            // church symbol
            feature = renderer.Add();
            feature.Value = "D44";
            feature.Symbol.PointStyle = PointStyle.Bitmap;
            feature.Symbol.Bitmap = SymbolFolder + "church.bmp";
            feature.Symbol.Size = 16;
            feature.Symbol.TransparentColor = Color.White;
            feature.Description = "Church";

            // hospital symbol
            feature = renderer.Add();
            feature.Value = "D31";
            feature.Symbol.PointStyle = PointStyle.Bitmap;
            feature.Symbol.Bitmap = SymbolFolder + "hospital.bmp";
            feature.Symbol.Size = 16;
            feature.Symbol.TransparentColor = Color.White;
            feature.Description = "Hospital";
		}
        
        private void map1_MapScaleChanged(object sender, MapScaleChangedEventArgs e)
        {
            legend1.Populate(map1);
        }

		private void toolBar_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
            if (e.Button.Style == ToolBarButtonStyle.ToggleButton) 
			{
				foreach(ToolBarButton b in toolBar.Buttons) b.Pushed = false;
				e.Button.Pushed = true;
			}

            map1.Cursor = Cursors.Default;

			if (e.Button == zoomFull)
			{
				map1.ZoomFull();
				map1.Refresh();
			}
            if (e.Button == clearShapes)
            {
                map1.MapShapes.Clear();
                map1.Callouts.Clear();
                dataGrid.DataSource = null;
                dataGrid.CaptionText = String.Empty;
                map1.Refresh();
            }
			else if (e.Button == zoomInTool)	map1.MapTool = MapTool.ZoomIn;
			else if (e.Button == zoomOutTool)	map1.MapTool = MapTool.ZoomOut;
            else if (e.Button == panTool)
            {
                map1.MapTool = MapTool.Pan;
                map1.Cursor = Cursors.SizeAll;
            }
			else if (e.Button == centerTool)	map1.MapTool = MapTool.Center;
			else if (e.Button == distanceTool)	map1.MapTool = MapTool.Distance;
			else if (e.Button == infoTool)		map1.MapTool = MapTool.Info;

		}

		private void map1_InfoTool(object sender, ActualMap.Windows.InfoToolEventArgs e)
		{
            map1.Callouts.Clear();

            ActualMap.Recordset records = map1.Identify(e.InfoPoint, 5);

            if (!records.EOF)
            {
                dataGrid.DataSource = records;
                dataGrid.CaptionText = records.Layer.Name;

                Callout callout = map1.Callouts.Add();
                callout.X = e.InfoPoint.X;
                callout.Y = e.InfoPoint.Y;
                callout.Text = GetCalloutText(records);
                callout.Font.Size = 16;

                map1.Refresh();
            }			
		}

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			printPreview.ShowDialog();
		}

		private void printDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			Bitmap mapImage = map1.GetBitmap(700, 600);
			e.Graphics.DrawImageUnscaled(mapImage, 50, 50);
		}

        private String GetCalloutText(ActualMap.Recordset rs)
        {
            int index = rs.Fields.GetFieldIndex("NAME");
            if (index < 0) index = rs.Fields.GetFieldIndex(rs.Layer.LabelField);
            if (index < 0) index = 0;
            return rs[index].ToString();
        }

        private void map1_DistanceToolMove(object sender, DistanceToolEventArgs e)
        {
            double distanceInMapUnits = e.Distance;
            double distanceInMiles = Math.Round(map1.ConvertDistance(distanceInMapUnits, map1.MapUnit, MeasureUnit.Mile), 3);
            double distanceInKilometers = Math.Round(map1.ConvertDistance(distanceInMapUnits, map1.MapUnit, MeasureUnit.Kilometer), 3);
            
            statusBar1.Text = distanceInMiles.ToString() + " mi  |  " +
                            distanceInKilometers.ToString() + " km";
        }

        private void map1_DistanceToolFinished(object sender, DistanceToolEventArgs e)
        {
            statusBar1.Text = String.Empty;
        }
	}
}